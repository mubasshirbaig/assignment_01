const nn = `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M12.53 4.47a.75.75 0 0 1 0 1.06L8.06 10l4.47 4.47a.75.75 0 1 1-1.06 1.06L5.94 10l5.53-5.53a.75.75 0 0 1 1.06 0Z" clip-rule="evenodd"/>
</svg>
`, an = `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M7.47 4.47a.75.75 0 0 0 0 1.06L11.94 10l-4.47 4.47a.75.75 0 1 0 1.06 1.06L14.06 10 8.53 4.47a.75.75 0 0 0-1.06 0Z" clip-rule="evenodd"/>
</svg>
`, on = `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M2.25 5A.75.75 0 0 1 3 4.25h18a.75.75 0 0 1 0 1.5H3A.75.75 0 0 1 2.25 5Zm0 7a.75.75 0 0 1 .75-.75h18a.75.75 0 0 1 0 1.5H3a.75.75 0 0 1-.75-.75Zm0 7a.75.75 0 0 1 .75-.75h18a.75.75 0 0 1 0 1.5H3a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd"/>
</svg>
`, sn = `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M4.47 4.47a.75.75 0 0 1 1.06 0L12 10.94l6.47-6.47a.75.75 0 1 1 1.06 1.06L13.06 12l6.47 6.47a.75.75 0 1 1-1.06 1.06L12 13.06l-6.47 6.47a.75.75 0 0 1-1.06-1.06L10.94 12 4.47 5.53a.75.75 0 0 1 0-1.06Z" clip-rule="evenodd"/>
</svg>
`;
var Te = /* @__PURE__ */ ((t) => (t.SEARCH = "epic-wf-nav-on-search", t.SEARCH_KEYDOWN = "epic-wf-nav-search-on-keydown", t.SEARCH_ACTIVATED = "epic-wf-nav-search-activated", t.NAV_LINK_CLICK = "epic-wf-nav-link-on-click", t.PROPERTY_LOGO_CLICK = "epic-wf-prop-logo-on-click", t.LOCALE_LINK_CLICK = "epic-wf-locale-on-click", t.CTA_CLICK = "epic-wf-cta-on-click", t.ACCOUNT_LINK_CLICK = "epic-wf-account-link-on-click", t.DRAWER_TOGGLE = "epic-wf-drawer-on-toggle", t))(Te || {});
const ie = ({ hrefTemplate: t = "", domain: e = "", locale: i = "" }) => {
  if (!t)
    return "";
  const r = i?.replace(/_/g, "-");
  let n = t;
  return !e && /({|%7B)domain(}|%7D)/i.test(n) ? n = n.replace(/\/({|%7B)domain(}|%7D)/gi, e || "") : n = n.replace(/({|%7B)domain(}|%7D)/gi, e || ""), !r && /({|%7B)locale(}|%7D)/i.test(n) ? n = n.replace(/\/({|%7B)locale(}|%7D)/gi, r || "") : n = n.replace(/({|%7B)locale(}|%7D)/gi, r || ""), n;
};
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const ft = globalThis, ei = ft.ShadowRoot && (ft.ShadyCSS === void 0 || ft.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, ti = Symbol(), xi = /* @__PURE__ */ new WeakMap();
let cr = class {
  constructor(e, i, r) {
    if (this._$cssResult$ = !0, r !== ti)
      throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = e, this.t = i;
  }
  get styleSheet() {
    let e = this.o;
    const i = this.t;
    if (ei && e === void 0) {
      const r = i !== void 0 && i.length === 1;
      r && (e = xi.get(i)), e === void 0 && ((this.o = e = new CSSStyleSheet()).replaceSync(this.cssText), r && xi.set(i, e));
    }
    return e;
  }
  toString() {
    return this.cssText;
  }
};
const D = (t) => new cr(typeof t == "string" ? t : t + "", void 0, ti), F = (t, ...e) => {
  const i = t.length === 1 ? t[0] : e.reduce((r, n, o) => r + ((a) => {
    if (a._$cssResult$ === !0)
      return a.cssText;
    if (typeof a == "number")
      return a;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + a + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(n) + t[o + 1], t[0]);
  return new cr(i, t, ti);
}, ln = (t, e) => {
  if (ei)
    t.adoptedStyleSheets = e.map((i) => i instanceof CSSStyleSheet ? i : i.styleSheet);
  else
    for (const i of e) {
      const r = document.createElement("style"), n = ft.litNonce;
      n !== void 0 && r.setAttribute("nonce", n), r.textContent = i.cssText, t.appendChild(r);
    }
}, ki = ei ? (t) => t : (t) => t instanceof CSSStyleSheet ? ((e) => {
  let i = "";
  for (const r of e.cssRules)
    i += r.cssText;
  return D(i);
})(t) : t;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: dn, defineProperty: cn, getOwnPropertyDescriptor: pn, getOwnPropertyNames: un, getOwnPropertySymbols: hn, getPrototypeOf: fn } = Object, Pe = globalThis, $i = Pe.trustedTypes, mn = $i ? $i.emptyScript : "", Ai = Pe.reactiveElementPolyfillSupport, We = (t, e) => t, gt = { toAttribute(t, e) {
  switch (e) {
    case Boolean:
      t = t ? mn : null;
      break;
    case Object:
    case Array:
      t = t == null ? t : JSON.stringify(t);
  }
  return t;
}, fromAttribute(t, e) {
  let i = t;
  switch (e) {
    case Boolean:
      i = t !== null;
      break;
    case Number:
      i = t === null ? null : Number(t);
      break;
    case Object:
    case Array:
      try {
        i = JSON.parse(t);
      } catch {
        i = null;
      }
  }
  return i;
} }, ii = (t, e) => !dn(t, e), Li = { attribute: !0, type: String, converter: gt, reflect: !1, hasChanged: ii };
Symbol.metadata ?? (Symbol.metadata = Symbol("metadata")), Pe.litPropertyMetadata ?? (Pe.litPropertyMetadata = /* @__PURE__ */ new WeakMap());
let Ce = class extends HTMLElement {
  static addInitializer(e) {
    this._$Ei(), (this.l ?? (this.l = [])).push(e);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(e, i = Li) {
    if (i.state && (i.attribute = !1), this._$Ei(), this.elementProperties.set(e, i), !i.noAccessor) {
      const r = Symbol(), n = this.getPropertyDescriptor(e, r, i);
      n !== void 0 && cn(this.prototype, e, n);
    }
  }
  static getPropertyDescriptor(e, i, r) {
    const { get: n, set: o } = pn(this.prototype, e) ?? { get() {
      return this[i];
    }, set(a) {
      this[i] = a;
    } };
    return { get() {
      return n?.call(this);
    }, set(a) {
      const l = n?.call(this);
      o.call(this, a), this.requestUpdate(e, l, r);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(e) {
    return this.elementProperties.get(e) ?? Li;
  }
  static _$Ei() {
    if (this.hasOwnProperty(We("elementProperties")))
      return;
    const e = fn(this);
    e.finalize(), e.l !== void 0 && (this.l = [...e.l]), this.elementProperties = new Map(e.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(We("finalized")))
      return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(We("properties"))) {
      const i = this.properties, r = [...un(i), ...hn(i)];
      for (const n of r)
        this.createProperty(n, i[n]);
    }
    const e = this[Symbol.metadata];
    if (e !== null) {
      const i = litPropertyMetadata.get(e);
      if (i !== void 0)
        for (const [r, n] of i)
          this.elementProperties.set(r, n);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [i, r] of this.elementProperties) {
      const n = this._$Eu(i, r);
      n !== void 0 && this._$Eh.set(n, i);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(e) {
    const i = [];
    if (Array.isArray(e)) {
      const r = new Set(e.flat(1 / 0).reverse());
      for (const n of r)
        i.unshift(ki(n));
    } else
      e !== void 0 && i.push(ki(e));
    return i;
  }
  static _$Eu(e, i) {
    const r = i.attribute;
    return r === !1 ? void 0 : typeof r == "string" ? r : typeof e == "string" ? e.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    var e;
    this._$Eg = new Promise((i) => this.enableUpdating = i), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), (e = this.constructor.l) == null || e.forEach((i) => i(this));
  }
  addController(e) {
    var i;
    (this._$ES ?? (this._$ES = [])).push(e), this.renderRoot !== void 0 && this.isConnected && ((i = e.hostConnected) == null || i.call(e));
  }
  removeController(e) {
    var i;
    (i = this._$ES) == null || i.splice(this._$ES.indexOf(e) >>> 0, 1);
  }
  _$E_() {
    const e = /* @__PURE__ */ new Map(), i = this.constructor.elementProperties;
    for (const r of i.keys())
      this.hasOwnProperty(r) && (e.set(r, this[r]), delete this[r]);
    e.size > 0 && (this._$Ep = e);
  }
  createRenderRoot() {
    const e = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return ln(e, this.constructor.elementStyles), e;
  }
  connectedCallback() {
    var e;
    this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (e = this._$ES) == null || e.forEach((i) => {
      var r;
      return (r = i.hostConnected) == null ? void 0 : r.call(i);
    });
  }
  enableUpdating(e) {
  }
  disconnectedCallback() {
    var e;
    (e = this._$ES) == null || e.forEach((i) => {
      var r;
      return (r = i.hostDisconnected) == null ? void 0 : r.call(i);
    });
  }
  attributeChangedCallback(e, i, r) {
    this._$AK(e, r);
  }
  _$EO(e, i) {
    var r;
    const n = this.constructor.elementProperties.get(e), o = this.constructor._$Eu(e, n);
    if (o !== void 0 && n.reflect === !0) {
      const a = (((r = n.converter) == null ? void 0 : r.toAttribute) !== void 0 ? n.converter : gt).toAttribute(i, n.type);
      this._$Em = e, a == null ? this.removeAttribute(o) : this.setAttribute(o, a), this._$Em = null;
    }
  }
  _$AK(e, i) {
    var r;
    const n = this.constructor, o = n._$Eh.get(e);
    if (o !== void 0 && this._$Em !== o) {
      const a = n.getPropertyOptions(o), l = typeof a.converter == "function" ? { fromAttribute: a.converter } : ((r = a.converter) == null ? void 0 : r.fromAttribute) !== void 0 ? a.converter : gt;
      this._$Em = o, this[o] = l.fromAttribute(i, a.type), this._$Em = null;
    }
  }
  requestUpdate(e, i, r, n = !1, o) {
    if (e !== void 0) {
      if (r ?? (r = this.constructor.getPropertyOptions(e)), !(r.hasChanged ?? ii)(n ? o : this[e], i))
        return;
      this.C(e, i, r);
    }
    this.isUpdatePending === !1 && (this._$Eg = this._$EP());
  }
  C(e, i, r) {
    this._$AL.has(e) || this._$AL.set(e, i), r.reflect === !0 && this._$Em !== e && (this._$Ej ?? (this._$Ej = /* @__PURE__ */ new Set())).add(e);
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$Eg;
    } catch (i) {
      Promise.reject(i);
    }
    const e = this.scheduleUpdate();
    return e != null && await e, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var e;
    if (!this.isUpdatePending)
      return;
    if (!this.hasUpdated) {
      if (this._$Ep) {
        for (const [o, a] of this._$Ep)
          this[o] = a;
        this._$Ep = void 0;
      }
      const n = this.constructor.elementProperties;
      if (n.size > 0)
        for (const [o, a] of n)
          a.wrapped !== !0 || this._$AL.has(o) || this[o] === void 0 || this.C(o, this[o], a);
    }
    let i = !1;
    const r = this._$AL;
    try {
      i = this.shouldUpdate(r), i ? (this.willUpdate(r), (e = this._$ES) == null || e.forEach((n) => {
        var o;
        return (o = n.hostUpdate) == null ? void 0 : o.call(n);
      }), this.update(r)) : this._$ET();
    } catch (n) {
      throw i = !1, this._$ET(), n;
    }
    i && this._$AE(r);
  }
  willUpdate(e) {
  }
  _$AE(e) {
    var i;
    (i = this._$ES) == null || i.forEach((r) => {
      var n;
      return (n = r.hostUpdated) == null ? void 0 : n.call(r);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(e)), this.updated(e);
  }
  _$ET() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$Eg;
  }
  shouldUpdate(e) {
    return !0;
  }
  update(e) {
    this._$Ej && (this._$Ej = this._$Ej.forEach((i) => this._$EO(i, this[i]))), this._$ET();
  }
  updated(e) {
  }
  firstUpdated(e) {
  }
};
Ce.elementStyles = [], Ce.shadowRootOptions = { mode: "open" }, Ce[We("elementProperties")] = /* @__PURE__ */ new Map(), Ce[We("finalized")] = /* @__PURE__ */ new Map(), Ai?.({ ReactiveElement: Ce }), (Pe.reactiveElementVersions ?? (Pe.reactiveElementVersions = [])).push("2.0.0");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const vt = globalThis, bt = vt.trustedTypes, Si = bt ? bt.createPolicy("lit-html", { createHTML: (t) => t }) : void 0, pr = "$lit$", se = `lit$${(Math.random() + "").slice(9)}$`, ur = "?" + se, gn = `<${ur}>`, xe = document, et = () => xe.createComment(""), tt = (t) => t === null || typeof t != "object" && typeof t != "function", hr = Array.isArray, vn = (t) => hr(t) || typeof t?.[Symbol.iterator] == "function", zt = `[ 	
\f\r]`, Be = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Ei = /-->/g, Ti = />/g, me = RegExp(`>|${zt}(?:([^\\s"'>=/]+)(${zt}*=${zt}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Ci = /'/g, Oi = /"/g, fr = /^(?:script|style|textarea|title)$/i, mr = (t) => (e, ...i) => ({ _$litType$: t, strings: e, values: i }), b = mr(1), bn = mr(2), de = Symbol.for("lit-noChange"), T = Symbol.for("lit-nothing"), Mi = /* @__PURE__ */ new WeakMap(), be = xe.createTreeWalker(xe, 129);
function gr(t, e) {
  if (!Array.isArray(t) || !t.hasOwnProperty("raw"))
    throw Error("invalid template strings array");
  return Si !== void 0 ? Si.createHTML(e) : e;
}
const _n = (t, e) => {
  const i = t.length - 1, r = [];
  let n, o = e === 2 ? "<svg>" : "", a = Be;
  for (let l = 0; l < i; l++) {
    const s = t[l];
    let d, h, u = -1, k = 0;
    for (; k < s.length && (a.lastIndex = k, h = a.exec(s), h !== null); )
      k = a.lastIndex, a === Be ? h[1] === "!--" ? a = Ei : h[1] !== void 0 ? a = Ti : h[2] !== void 0 ? (fr.test(h[2]) && (n = RegExp("</" + h[2], "g")), a = me) : h[3] !== void 0 && (a = me) : a === me ? h[0] === ">" ? (a = n ?? Be, u = -1) : h[1] === void 0 ? u = -2 : (u = a.lastIndex - h[2].length, d = h[1], a = h[3] === void 0 ? me : h[3] === '"' ? Oi : Ci) : a === Oi || a === Ci ? a = me : a === Ei || a === Ti ? a = Be : (a = me, n = void 0);
    const x = a === me && t[l + 1].startsWith("/>") ? " " : "";
    o += a === Be ? s + gn : u >= 0 ? (r.push(d), s.slice(0, u) + pr + s.slice(u) + se + x) : s + se + (u === -2 ? l : x);
  }
  return [gr(t, o + (t[i] || "<?>") + (e === 2 ? "</svg>" : "")), r];
};
let Ht = class vr {
  constructor({ strings: e, _$litType$: i }, r) {
    let n;
    this.parts = [];
    let o = 0, a = 0;
    const l = e.length - 1, s = this.parts, [d, h] = _n(e, i);
    if (this.el = vr.createElement(d, r), be.currentNode = this.el.content, i === 2) {
      const u = this.el.content.firstChild;
      u.replaceWith(...u.childNodes);
    }
    for (; (n = be.nextNode()) !== null && s.length < l; ) {
      if (n.nodeType === 1) {
        if (n.hasAttributes())
          for (const u of n.getAttributeNames())
            if (u.endsWith(pr)) {
              const k = h[a++], x = n.getAttribute(u).split(se), V = /([.?@])?(.*)/.exec(k);
              s.push({ type: 1, index: o, name: V[2], strings: x, ctor: V[1] === "." ? wn : V[1] === "?" ? xn : V[1] === "@" ? kn : Et }), n.removeAttribute(u);
            } else
              u.startsWith(se) && (s.push({ type: 6, index: o }), n.removeAttribute(u));
        if (fr.test(n.tagName)) {
          const u = n.textContent.split(se), k = u.length - 1;
          if (k > 0) {
            n.textContent = bt ? bt.emptyScript : "";
            for (let x = 0; x < k; x++)
              n.append(u[x], et()), be.nextNode(), s.push({ type: 2, index: ++o });
            n.append(u[k], et());
          }
        }
      } else if (n.nodeType === 8)
        if (n.data === ur)
          s.push({ type: 2, index: o });
        else {
          let u = -1;
          for (; (u = n.data.indexOf(se, u + 1)) !== -1; )
            s.push({ type: 7, index: o }), u += se.length - 1;
        }
      o++;
    }
  }
  static createElement(e, i) {
    const r = xe.createElement("template");
    return r.innerHTML = e, r;
  }
};
function Ne(t, e, i = t, r) {
  var n, o;
  if (e === de)
    return e;
  let a = r !== void 0 ? (n = i._$Co) == null ? void 0 : n[r] : i._$Cl;
  const l = tt(e) ? void 0 : e._$litDirective$;
  return a?.constructor !== l && ((o = a?._$AO) == null || o.call(a, !1), l === void 0 ? a = void 0 : (a = new l(t), a._$AT(t, i, r)), r !== void 0 ? (i._$Co ?? (i._$Co = []))[r] = a : i._$Cl = a), a !== void 0 && (e = Ne(t, a._$AS(t, e.values), a, r)), e;
}
let yn = class {
  constructor(e, i) {
    this._$AV = [], this._$AN = void 0, this._$AD = e, this._$AM = i;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(e) {
    const { el: { content: i }, parts: r } = this._$AD, n = (e?.creationScope ?? xe).importNode(i, !0);
    be.currentNode = n;
    let o = be.nextNode(), a = 0, l = 0, s = r[0];
    for (; s !== void 0; ) {
      if (a === s.index) {
        let d;
        s.type === 2 ? d = new ri(o, o.nextSibling, this, e) : s.type === 1 ? d = new s.ctor(o, s.name, s.strings, this, e) : s.type === 6 && (d = new $n(o, this, e)), this._$AV.push(d), s = r[++l];
      }
      a !== s?.index && (o = be.nextNode(), a++);
    }
    return be.currentNode = xe, n;
  }
  p(e) {
    let i = 0;
    for (const r of this._$AV)
      r !== void 0 && (r.strings !== void 0 ? (r._$AI(e, r, i), i += r.strings.length - 2) : r._$AI(e[i])), i++;
  }
}, ri = class br {
  get _$AU() {
    var e;
    return ((e = this._$AM) == null ? void 0 : e._$AU) ?? this._$Cv;
  }
  constructor(e, i, r, n) {
    this.type = 2, this._$AH = T, this._$AN = void 0, this._$AA = e, this._$AB = i, this._$AM = r, this.options = n, this._$Cv = n?.isConnected ?? !0;
  }
  get parentNode() {
    let e = this._$AA.parentNode;
    const i = this._$AM;
    return i !== void 0 && e?.nodeType === 11 && (e = i.parentNode), e;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(e, i = this) {
    e = Ne(this, e, i), tt(e) ? e === T || e == null || e === "" ? (this._$AH !== T && this._$AR(), this._$AH = T) : e !== this._$AH && e !== de && this._(e) : e._$litType$ !== void 0 ? this.g(e) : e.nodeType !== void 0 ? this.$(e) : vn(e) ? this.T(e) : this._(e);
  }
  k(e) {
    return this._$AA.parentNode.insertBefore(e, this._$AB);
  }
  $(e) {
    this._$AH !== e && (this._$AR(), this._$AH = this.k(e));
  }
  _(e) {
    this._$AH !== T && tt(this._$AH) ? this._$AA.nextSibling.data = e : this.$(xe.createTextNode(e)), this._$AH = e;
  }
  g(e) {
    var i;
    const { values: r, _$litType$: n } = e, o = typeof n == "number" ? this._$AC(e) : (n.el === void 0 && (n.el = Ht.createElement(gr(n.h, n.h[0]), this.options)), n);
    if (((i = this._$AH) == null ? void 0 : i._$AD) === o)
      this._$AH.p(r);
    else {
      const a = new yn(o, this), l = a.u(this.options);
      a.p(r), this.$(l), this._$AH = a;
    }
  }
  _$AC(e) {
    let i = Mi.get(e.strings);
    return i === void 0 && Mi.set(e.strings, i = new Ht(e)), i;
  }
  T(e) {
    hr(this._$AH) || (this._$AH = [], this._$AR());
    const i = this._$AH;
    let r, n = 0;
    for (const o of e)
      n === i.length ? i.push(r = new br(this.k(et()), this.k(et()), this, this.options)) : r = i[n], r._$AI(o), n++;
    n < i.length && (this._$AR(r && r._$AB.nextSibling, n), i.length = n);
  }
  _$AR(e = this._$AA.nextSibling, i) {
    var r;
    for ((r = this._$AP) == null ? void 0 : r.call(this, !1, !0, i); e && e !== this._$AB; ) {
      const n = e.nextSibling;
      e.remove(), e = n;
    }
  }
  setConnected(e) {
    var i;
    this._$AM === void 0 && (this._$Cv = e, (i = this._$AP) == null || i.call(this, e));
  }
}, Et = class {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(e, i, r, n, o) {
    this.type = 1, this._$AH = T, this._$AN = void 0, this.element = e, this.name = i, this._$AM = n, this.options = o, r.length > 2 || r[0] !== "" || r[1] !== "" ? (this._$AH = Array(r.length - 1).fill(new String()), this.strings = r) : this._$AH = T;
  }
  _$AI(e, i = this, r, n) {
    const o = this.strings;
    let a = !1;
    if (o === void 0)
      e = Ne(this, e, i, 0), a = !tt(e) || e !== this._$AH && e !== de, a && (this._$AH = e);
    else {
      const l = e;
      let s, d;
      for (e = o[0], s = 0; s < o.length - 1; s++)
        d = Ne(this, l[r + s], i, s), d === de && (d = this._$AH[s]), a || (a = !tt(d) || d !== this._$AH[s]), d === T ? e = T : e !== T && (e += (d ?? "") + o[s + 1]), this._$AH[s] = d;
    }
    a && !n && this.j(e);
  }
  j(e) {
    e === T ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
  }
}, wn = class extends Et {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(e) {
    this.element[this.name] = e === T ? void 0 : e;
  }
}, xn = class extends Et {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(e) {
    this.element.toggleAttribute(this.name, !!e && e !== T);
  }
}, kn = class extends Et {
  constructor(e, i, r, n, o) {
    super(e, i, r, n, o), this.type = 5;
  }
  _$AI(e, i = this) {
    if ((e = Ne(this, e, i, 0) ?? T) === de)
      return;
    const r = this._$AH, n = e === T && r !== T || e.capture !== r.capture || e.once !== r.once || e.passive !== r.passive, o = e !== T && (r === T || n);
    n && this.element.removeEventListener(this.name, this, r), o && this.element.addEventListener(this.name, this, e), this._$AH = e;
  }
  handleEvent(e) {
    var i;
    typeof this._$AH == "function" ? this._$AH.call(((i = this.options) == null ? void 0 : i.host) ?? this.element, e) : this._$AH.handleEvent(e);
  }
}, $n = class {
  constructor(e, i, r) {
    this.element = e, this.type = 6, this._$AN = void 0, this._$AM = i, this.options = r;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(e) {
    Ne(this, e);
  }
};
const Pi = vt.litHtmlPolyfillSupport;
Pi?.(Ht, ri), (vt.litHtmlVersions ?? (vt.litHtmlVersions = [])).push("3.0.0");
const An = (t, e, i) => {
  const r = i?.renderBefore ?? e;
  let n = r._$litPart$;
  if (n === void 0) {
    const o = i?.renderBefore ?? null;
    r._$litPart$ = n = new ri(e.insertBefore(et(), o), o, void 0, i ?? {});
  }
  return n._$AI(t), n;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let R = class extends Ce {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var e;
    const i = super.createRenderRoot();
    return (e = this.renderOptions).renderBefore ?? (e.renderBefore = i.firstChild), i;
  }
  update(e) {
    const i = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(e), this._$Do = An(i, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var e;
    super.connectedCallback(), (e = this._$Do) == null || e.setConnected(!0);
  }
  disconnectedCallback() {
    var e;
    super.disconnectedCallback(), (e = this._$Do) == null || e.setConnected(!1);
  }
  render() {
    return de;
  }
};
var Ni;
R._$litElement$ = !0, R.finalized = !0, (Ni = globalThis.litElementHydrateSupport) == null || Ni.call(globalThis, { LitElement: R });
const zi = globalThis.litElementPolyfillSupport;
zi?.({ LitElement: R });
(globalThis.litElementVersions ?? (globalThis.litElementVersions = [])).push("4.0.0");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const j = (t) => (e, i) => {
  i !== void 0 ? i.addInitializer(() => {
    customElements.define(t, e);
  }) : customElements.define(t, e);
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Ln = { attribute: !0, type: String, converter: gt, reflect: !1, hasChanged: ii }, Sn = (t = Ln, e, i) => {
  const { kind: r, metadata: n } = i;
  let o = globalThis.litPropertyMetadata.get(n);
  if (o === void 0 && globalThis.litPropertyMetadata.set(n, o = /* @__PURE__ */ new Map()), o.set(i.name, t), r === "accessor") {
    const { name: a } = i;
    return { set(l) {
      const s = e.get.call(this);
      e.set.call(this, l), this.requestUpdate(a, s, t);
    }, init(l) {
      return l !== void 0 && this.C(a, void 0, t), l;
    } };
  }
  if (r === "setter") {
    const { name: a } = i;
    return function(l) {
      const s = this[a];
      e.call(this, l), this.requestUpdate(a, s, t);
    };
  }
  throw Error("Unsupported decorator location: " + r);
};
function f(t) {
  return (e, i) => typeof i == "object" ? Sn(t, e, i) : ((r, n, o) => {
    const a = n.hasOwnProperty(o);
    return n.constructor.createProperty(o, a ? { ...r, wrapped: !0 } : r), a ? Object.getOwnPropertyDescriptor(n, o) : void 0;
  })(t, e, i);
}
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const O = (t) => t ?? T;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const _r = { ATTRIBUTE: 1, CHILD: 2, PROPERTY: 3, BOOLEAN_ATTRIBUTE: 4, EVENT: 5, ELEMENT: 6 }, yr = (t) => (...e) => ({ _$litDirective$: t, values: e });
class wr {
  constructor(e) {
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AT(e, i, r) {
    this._$Ct = e, this._$AM = i, this._$Ci = r;
  }
  _$AS(e, i) {
    return this.update(e, i);
  }
  update(e, i) {
    return this.render(...i);
  }
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let Ut = class extends wr {
  constructor(e) {
    if (super(e), this.et = T, e.type !== _r.CHILD)
      throw Error(this.constructor.directiveName + "() can only be used in child bindings");
  }
  render(e) {
    if (e === T || e == null)
      return this.vt = void 0, this.et = e;
    if (e === de)
      return e;
    if (typeof e != "string")
      throw Error(this.constructor.directiveName + "() called with a non-string value");
    if (e === this.et)
      return this.vt;
    this.et = e;
    const i = [e];
    return i.raw = i, this.vt = { _$litType$: this.constructor.resultType, strings: i, values: [] };
  }
};
Ut.directiveName = "unsafeHTML", Ut.resultType = 1;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let Vt = class extends Ut {
};
Vt.directiveName = "unsafeSVG", Vt.resultType = 2;
const K = yr(Vt), U = (t, e) => !!(t && t === "true"), X = (t) => t && typeof t == "string" ? JSON.parse(t) : t, xr = (t) => t && typeof t == "string" ? +t : t;
var Kt = /* @__PURE__ */ ((t) => (t.NAV_FLYOUT_TOGGLE = "epic-wf-nav-flyout-toggle", t.NAV_MAIN_LINK_KEY_DOWN = "epic-wf-nav-main-link-key-down", t.DRAWER_TOGGLE = "toggle", t))(Kt || {});
const En = `:host{display:flex;fill:var(--color-text-primary, #ffffff)}
`;
var Tn = Object.defineProperty, Cn = Object.getOwnPropertyDescriptor, On = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? Cn(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && Tn(e, i, n), n;
};
let qt = class extends R {
  render() {
    return b`
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" fill-rule="evenodd" height="32" width="32">
				<path
					d="M12.349 21l-.39.982h.773L12.349 21zm2.29-10.224V7.909c0-.457-.21-.668-.648-.668h-.713v4.204h.713c.438 0 .648-.212.648-.668zm11.698-9.019H5.36c-1.702 0-2.328.627-2.328 2.328v20.526l.025.537c.038.372.047.732.392 1.14a7.23 7.23 0 0 0 .387.302l.533.248 10.329 4.327c.537.245.76.342 1.15.333h.003c.39.008.613-.088 1.15-.333l10.329-4.327.533-.248.387-.302c.345-.41.353-.77.392-1.14a5.28 5.28 0 0 0 .025-.537V4.086c0-1.702-.628-2.328-2.328-2.328h-.002zm-9.181 3.952h1.735v11.404h-1.735V5.709zm.117 14.181h1.01v3.45h-.952v-1.982l-.882 1.35h-.02l-.877-1.34v1.972h-.937v-3.45h1.01l.823 1.337.823-1.337zm-5.73-14.181h2.723c1.41 0 2.108.7 2.108 2.118v3.03c0 1.417-.697 2.118-2.108 2.118h-.988v4.139h-1.735V5.709zm-4.729 0h3.859v1.58H8.549v3.225h2.043v1.58H8.549v3.438h2.157v1.58H6.814V5.709zm3.317 17.169c-.365.3-.873.532-1.498.532-1.075 0-1.878-.74-1.878-1.785v-.01c0-1.005.788-1.795 1.858-1.795.607 0 1.035.187 1.4.503l-.562.675c-.247-.207-.493-.325-.833-.325-.498 0-.882.418-.882.947v.01a.91.91 0 0 0 .937.957c.232 0 .41-.05.552-.143v-.418h-.68v-.7h1.587v1.553zm1.765-3.012h.922l1.468 3.475h-1.025l-.252-.617h-1.332l-.247.617h-1.005l1.468-3.475h.002zm3.874 9.231l-4.862-1.672h9.931l-5.069 1.672zm5.947-5.755h-2.8v-3.45h2.775v.813h-1.828v.523h1.657v.755h-1.657v.547h1.854v.813-.002zm-1.907-8.249V7.729c0-1.417.697-2.118 2.108-2.118h.843c1.41 0 2.092.685 2.092 2.102v2.33h-1.702V7.811c0-.457-.212-.668-.648-.668h-.292c-.453 0-.665.212-.665.668v7.2c0 .457.212.668.665.668h.325c.438 0 .648-.212.648-.668v-2.573h1.702v2.655c0 1.417-.697 2.119-2.108 2.119h-.86c-1.41 0-2.108-.7-2.108-2.119zm5.165 7.184c0 .705-.557 1.123-1.395 1.123-.612 0-1.193-.192-1.617-.572l.532-.637a1.77 1.77 0 0 0 1.118.413c.257 0 .395-.088.395-.237v-.01c0-.143-.113-.222-.582-.33-.735-.168-1.302-.375-1.302-1.085v-.01c0-.642.508-1.105 1.337-1.105.587 0 1.045.158 1.42.458l-.478.675c-.315-.222-.66-.34-.967-.34-.232 0-.345.098-.345.222v.01c0 .158.118.227.597.335.793.173 1.287.428 1.287 1.075v.01.003z"
				/>
			</svg>
		`;
  }
};
qt.styles = F`
		${D(En)}
	`;
qt = On([
  j("epic-wf-shield")
], qt);
const Mn = `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M15.53 7.47a.75.75 0 0 0-1.06 0L10 11.94 5.53 7.47a.75.75 0 0 0-1.06 1.06L10 14.06l5.53-5.53a.75.75 0 0 0 0-1.06Z" clip-rule="evenodd"/>
</svg>
`, ae = {
  en: "en-US"
}, Ii = { en: "en-US", "zh-TW": "zh-Hant" }, It = {
  ue: ae,
  fn: ae,
  fg: ae,
  rl: {},
  egs: Ii,
  sketch: {},
  artstation: {},
  fab: ae,
  createfn: {},
  tm: ae,
  //TODO remove reality
  reality: ae,
  realityscan: ae,
  realitycapture: {},
  eos: ae,
  devportal: Ii,
  superawesome: {},
  edc: {
    ar: "ar-ar",
    de: "de-de",
    en: "en-us",
    "en-US": "en-us",
    "es-ES": "es-es",
    "es-MX": "es-mx",
    fr: "fr-fr",
    it: "it-it",
    ja: "ja-jp",
    ko: "ko-kr",
    pl: "pl-pl",
    "pt-BR": "pt-br",
    ru: "ru-ru",
    tr: "tr-tr",
    "zh-CN": "zh-cn"
  }
}, ee = {
  ue: ["en", "de", "es-ES", "fr", "ja", "ko", "pt-BR", "zh-CN"],
  tm: ["en", "ja", "ko", "zh-CN"],
  fn: ["en", "ar", "de", "es-ES", "es-MX", "fr", "it", "ja", "ko", "pl", "pt-BR", "ru", "tr"],
  egs: ["en", "ar", "de", "es-ES", "es-MX", "fr", "it", "ja", "ko", "pl", "pt-BR", "ru", "th", "tr", "zh-CN", "zh-TW"]
}, He = ["en"], Pn = {
  ue: ee.ue,
  fn: ee.fn,
  fg: ["en", "de", "es-ES", "es-MX", "fr", "it", "ja", "ko", "pl", "pt-BR", "ru", "zh-CN"],
  rl: ["en", "de", "fr", "pt-BR", "it", "es-MX", "es-ES"],
  egs: ee.egs,
  sketch: He,
  artstation: He,
  fab: ee.ue,
  createfn: ee.fn,
  tm: ee.tm,
  //TODO remove reality
  reality: He,
  realityscan: ee.ue,
  realitycapture: He,
  eos: ee.tm,
  devportal: ee.egs,
  superawesome: He,
  edc: ["en", "de", "es-ES", "es-MX", "fr", "it", "ja", "ko", "pl", "pt-BR", "ru", "tr", "zh-CN"]
}, Nn = `.visually-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin-block:-1px;margin-inline:-1px;overflow:hidden;padding:0;position:absolute;width:1px}svg{fill:currentColor}svg[viewBox="0 0 24 24"]{inline-size:1.5rem;block-size:1.5rem}svg[viewBox="0 0 20 20"]{inline-size:1.25rem;block-size:1.25rem}svg{color:var(--color-text-secondary, #aaaaae)}.nav-flyout-toggle{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:transparent;border:0;color:inherit;font-family:inherit;font-size:inherit;padding:0;text-decoration:none;-webkit-user-select:none;user-select:none;align-items:center;display:flex;gap:.5rem}.nav-flyout-toggle>*{pointer-events:none}.nav-flyout-toggle:not([disabled]){cursor:pointer}.nav-flyout-toggle svg{transition:transform var(--easing-duration, .2s) var(--easing, ease-out),color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1))}.nav-flyout-toggle:hover svg{transform:translateY(.125rem)}.nav-flyout-toggle.is-open svg{transform:rotate(180deg)}.nav-flyout-toggle:hover svg,.nav-flyout-toggle.is-open svg{color:var(--color-text-link-secondary-default, #e6e6ea)}.nav-flyout-toggle .icon{display:flex}.nav-flyout-menu{list-style:none;margin:0;padding:0;align-items:flex-start;background:var(--color-background-elevated-high-default, #202024);border-radius:1rem;color:var(--color-text-primary, #e6e6ea);display:inline-flex;flex-direction:column;flex-wrap:nowrap;gap:2.5rem;inset-block-start:5.5rem;inset-inline:1rem;padding-block:2.5rem;padding-inline:2.5rem;position:absolute;max-height:calc(100dvh - 11rem);overscroll-behavior:contain;overflow-y:scroll;overflow-x:hidden;scrollbar-width:none;-ms-overflow-style:none}.nav-flyout-menu::-webkit-scrollbar{display:none}@media (min-width: 768px){.nav-flyout-menu{box-shadow:0 32px 16px #0000001a,0 16px 8px #0000001a,0 8px 4px #0000001a,0 4px 2px #0000001a,0 2px 1px #0000001a;flex-wrap:wrap}}@media (min-width: 768px){.nav-flyout-menu{max-height:37.5rem;width:33.125rem}}.nav-flyout-menu:not(.is-open){display:none}.nav-flyout-menu__section{width:13.125rem}.nav-flyout-menu__section[data-flyout-section="2"]{width:17.5rem}.nav-flyout-menu__headline{font-family:Inter Tight,sans-serif;font-style:normal;font-weight:700;line-height:150%;font-size:1.25rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--color-text-primary, #e6e6ea);display:flex;margin-block-end:.625rem;padding-inline-start:.375rem}.nav-flyout-menu__list{list-style:none;margin:0;padding:0}.nav-flyout-menu__list-item a{transition:background var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1));align-items:center;border-radius:.5rem;box-sizing:border-box;color:var(--color-text-primary, #e6e6ea);display:flex;gap:.75rem;height:2.5rem;margin-inline:-.25rem;padding-block:.25rem;padding-inline:.625rem;text-decoration:none;-webkit-user-select:none;user-select:none;width:calc(100% + .5rem)}.nav-flyout-menu__list-item a:hover{background:var(--color-background-elevated-high-hover, #404044)}.nav-flyout-menu__list-item a .logo{background-color:var(--color-text-primary, #e6e6ea);background-position:center;flex-shrink:0;height:1.25rem;width:1.25rem;mask-position:center;mask-repeat:no-repeat;mask-size:cover;-webkit-mask-position:center;-webkit-mask-repeat:no-repeat;-webkit-mask-size:cover}.nav-flyout-menu__list-item a .label{font-family:Inter,sans-serif;font-style:normal;font-weight:400;line-height:150%;font-size:.875rem;letter-spacing:.02em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
`, zn = (t) => {
  if (!t)
    return "";
  const e = new URL(t);
  return e.searchParams.delete("locale"), e.searchParams.delete("lang"), e.toString();
}, In = (t, e) => {
  if (!t || !e || typeof e != "string")
    return !1;
  const i = e.replace(/_/g, "-").toLowerCase();
  return i ? (Pn[t] || []).map((r) => r.replace(/_/g, "-").toLowerCase()).includes(i) : !1;
};
var Rn = Object.defineProperty, Dn = Object.getOwnPropertyDescriptor, dt = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? Dn(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && Rn(e, i, n), n;
};
let ke = class extends R {
  constructor() {
    super(...arguments), this.open = !1, this.buttonLabel = "Epic Ecosystem", this.disabled = !1, this.sections = new Array();
  }
  _getMappedHygraphLocale(e, i) {
    if (It && e && It[e]) {
      const r = It[e];
      if (r && typeof r[i] < "u")
        return r[i];
    }
    return i;
  }
  _click(e) {
    this.dispatchEvent(new CustomEvent(Kt.NAV_FLYOUT_TOGGLE));
  }
  _keydown(e) {
    e.key === "Escape" && this.open === !0 && (this.open = !1, this.dispatchEvent(new CustomEvent(Kt.NAV_FLYOUT_TOGGLE)));
  }
  render() {
    return b`
			<button
				?disabled=${this.disabled}
				@click=${this._click}
				@keydown=${this._keydown}
				aria-controls="nav-flyout-menu"
				aria-expanded=${this.open}
				aria-haspopup="true"
				aria-label=${this.buttonLabel}
				class="nav-flyout-toggle ${this.open ? "is-open" : ""}"
				id="nav-flyout-toggle"
			>
				<epic-wf-shield aria-hidden="true"></epic-wf-shield>
				${this.disabled ? null : b`<span aria-hidden="true" class="icon">${K(Mn)}</span>`}
			</button>
			<ul
				aria-labelledby="nav-flyout-toggle"
				class="nav-flyout-menu ${this.open ? "is-open" : ""}"
				id="nav-flyout-menu"
				role="menu"
			>
				${this.sections.map((e, i) => {
      const r = e?.items || [];
      return b`
						<li class="nav-flyout-menu__section" data-flyout-section=${i} role="none">
							<span id="${O(e.headline)}" class="nav-flyout-menu__headline">
								${O(e.headline)}
							</span>
							<ul aria-labelledby="${O(e.headline)}" class="nav-flyout-menu__list" role="menu">
								${r.map((n) => {
        var o;
        const a = (o = n.logo) == null ? void 0 : o.url, l = `
										mask-image: url(${a});
										-webkit-mask-image: url(${a});
									`, s = ie({
          hrefTemplate: n?.hrefTemplate,
          locale: this._getMappedHygraphLocale(n.key, n.locale)
        });
        let d = s;
        return In(n.key, n.locale) || (d = zn(s)), b`
										<li class="nav-flyout-menu__list-item" role="none">
											<a href=${d} role="menuitem">
												<div class="logo" style="${l}"></div>
												<span class="label">${O(n.label)}</span>
											</a>
										</li>
									`;
      })}
							</ul>
						</li>
					`;
    })}
			</ul>
		`;
  }
};
ke.styles = F`
		${D(Nn)}
	`;
dt([
  f({ type: Boolean, converter: U })
], ke.prototype, "open", 2);
dt([
  f()
], ke.prototype, "buttonLabel", 2);
dt([
  f({ type: Boolean, converter: U })
], ke.prototype, "disabled", 2);
dt([
  f({ type: Array })
], ke.prototype, "sections", 2);
ke = dt([
  j("epic-wf-nav-flyout-menu")
], ke);
const kr = `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M12.53 4.47a.75.75 0 0 1 0 1.06L8.06 10l4.47 4.47a.75.75 0 1 1-1.06 1.06L5.94 10l5.53-5.53a.75.75 0 0 1 1.06 0Z" clip-rule="evenodd"/>
</svg>
`, $r = `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M7.47 4.47a.75.75 0 0 0 0 1.06L11.94 10l-4.47 4.47a.75.75 0 1 0 1.06 1.06L14.06 10 8.53 4.47a.75.75 0 0 0-1.06 0Z" clip-rule="evenodd"/>
</svg>
`;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function ni(t) {
  return f({ ...t, state: !0, attribute: !1 });
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Ri = (t, e, i) => (i.configurable = !0, i.enumerable = !0, Reflect.decorate && typeof e != "object" && Object.defineProperty(t, e, i), i);
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function jn(t, e) {
  return (i, r, n) => {
    const o = (a) => {
      var l;
      return ((l = a.renderRoot) == null ? void 0 : l.querySelector(t)) ?? null;
    };
    if (e) {
      const { get: a, set: l } = typeof r == "object" ? i : n ?? (() => {
        const s = Symbol();
        return { get() {
          return this[s];
        }, set(d) {
          this[s] = d;
        } };
      })();
      return Ri(i, r, { get() {
        if (e) {
          let s = a.call(this);
          return s === void 0 && (s = o(this), l.call(this, s)), s;
        }
        return o(this);
      } });
    }
    return Ri(i, r, { get() {
      return o(this);
    } });
  };
}
const ye = (t) => t?.pointerType === "touch", Fn = `:host{width:15.5rem}.condensed-menu{list-style:none;margin:0;padding:0;position:relative;width:100%}.condensed-menu.has-open-menu:first-child .condensed-menu__link{border-start-end-radius:0}.condensed-menu.has-open-menu:last-child .condensed-menu__link{border-end-end-radius:0}.condensed-menu__item epic-wf-subnav-item-menu{inset-block-start:0;inset-inline-start:100%;position:absolute}.condensed-menu__item:not([active=true]) epic-wf-simple-menu,.condensed-menu__item:not([active=true]) epic-wf-subnav-item-menu{opacity:0;pointer-events:none;visibility:hidden}.condensed-menu__item:first-child .condensed-menu__link{border-start-start-radius:1rem;border-start-end-radius:1rem}.condensed-menu__item:last-child .condensed-menu__link{border-end-start-radius:1rem;border-end-end-radius:1rem}.condensed-menu__link{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:transparent;border:0;color:inherit;font-family:inherit;font-size:inherit;padding:0;text-decoration:none;-webkit-user-select:none;user-select:none;align-items:center;background:var(--color-background-elevated-high-default, #202024);border-bottom:1px solid var(--color-border-subtle, #303034);box-sizing:border-box;color:var(--color-text-secondary, #aaaaae);display:flex;flex-direction:row;flex-wrap:nowrap;justify-content:space-between;padding-block:1.375rem;padding-inline:1.5rem;text-align:start;transition:background var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1)),opacity var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1));width:15.5rem}.condensed-menu__link>*{pointer-events:none}.condensed-menu__link:not([disabled]){cursor:pointer}.condensed-menu__link:hover{background:var(--color-background-elevated-low, #18181c);color:var(--color-text-primary, #e6e6ea)}.condensed-menu__link:hover svg{transform:translate(calc(.125rem * var(--transform-direction)))}.condensed-menu__link .label{font-family:Inter,sans-serif;font-style:normal;font-weight:400;line-height:150%;font-size:.875rem;letter-spacing:.02em;flex-grow:1}.condensed-menu__link .icon-wrapper{display:flex}.condensed-menu__link svg{transition:transform var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1));fill:var(--color-text-secondary, #aaaaae);flex-shrink:0;height:1.25rem;width:1.25rem}
`, Bn = `*,*:before,*:after{box-sizing:border-box}.subnav{align-items:stretch;background:var(--color-background-elevated-high-default, #202024);border-radius:1rem;box-sizing:border-box;column-gap:1rem;display:flex;flex-direction:column;padding-block:2rem;padding-inline:2rem;row-gap:2rem;scrollbar-color:dark}@media (max-width: 1279.9px){.subnav{max-height:calc(100vh - 9rem);overflow-y:auto;padding:1.5rem;position:relative;z-index:10}@supports (height: 100dvh){.subnav{max-height:calc(100dvh - 9rem)}}}@media (min-width: 1280px){.subnav{box-shadow:0 32px 16px #0000001a,0 16px 8px #0000001a,0 8px 4px #0000001a,0 4px 2px #0000001a,0 2px 1px #0000001a}}.subnav--condensed{border-start-start-radius:0;width:21.375rem}.subnav--condensed:before{content:"";height:100%;inset-block-end:0;inset-block-start:0;inset-inline-start:0;position:absolute;transform:translate(-100%);width:18.75rem;z-index:-1}@media (min-width: 768px){.subnav:not(.subnav--condensed){flex-direction:row;gap:2.5rem;padding-block:2.5rem;padding-inline:2.5rem}}@media (min-width: 1280px){.subnav:not(.subnav--condensed){width:67.5rem}}@media (min-width: 1488px){.subnav:not(.subnav--condensed){max-width:83.125rem;min-width:67.5rem;width:fit-content}}.subnav__col{column-gap:2.5rem;display:flex;flex-direction:column;row-gap:1.5rem}@media (min-width: 1280px){.subnav__col{flex-grow:1;flex-shrink:0;flex-direction:row}}.subnav--condensed .subnav__col{flex-direction:column}@media (min-width: 768px){.subnav:not(.subnav--condensed) .subnav__col{max-width:13.125rem}}@media (min-width: 1280px){.subnav:not(.subnav--condensed) .subnav__col{max-width:28.75rem}}.subnav__title-description{align-items:flex-start;color:var(--color-text-primary, #e6e6ea);display:block;display:flex;flex-direction:column;gap:.75rem}@media (min-width: 1280px){.subnav__title-description{flex:1}}.subnav__title-description h3,.subnav__title-description p{margin-block:0;margin-inline:0}.subnav__title-description h3{font-family:Inter Tight,sans-serif;font-style:normal;font-weight:700;line-height:150%;font-size:1.5rem;line-height:1.75rem}.subnav__title-description p{font-family:Inter,sans-serif;font-style:normal;font-weight:400;line-height:150%;font-size:.875rem;letter-spacing:.02em}.subnav__hr{background-color:var(--color-border-subtle, #303034);border:none;flex-shrink:0;height:.125rem;margin-block:-.0625rem;margin-inline:0;width:100%}@media (min-width: 768px){.subnav__hr{height:auto;margin-inline:-.0625rem;width:.125rem}}.subnav--condensed .subnav__hr{height:.125rem;margin-block:-.0625rem;margin-inline:0;width:100%}.subnav__links{display:flex;flex-direction:column;gap:.5rem}@media (min-width: 1280px){.subnav__links{flex:1}}@media (min-width: 768px){.subnav:not(.subnav--condensed) .subnav__links{max-width:13.125rem}}.subnav__cards{display:grid;gap:2rem 2.5rem}@media (min-width: 1280px){.subnav__cards{grid-auto-flow:column;grid-template-columns:1fr 1fr;grid-template-rows:auto auto}}@media (min-width: 1280px){.subnav__cards--more{grid-template-rows:auto auto auto}}@media (min-width: 1488px){.subnav__cards--more{grid-template-columns:1fr 1fr 1fr;grid-template-rows:auto auto}}@media (min-width: 768px){.subnav:not(.subnav--condensed) .subnav__cards{max-width:15.625rem}}@media (min-width: 1280px){.subnav:not(.subnav--condensed) .subnav__cards{max-width:none}}@media (min-width: 1280px){.subnav epic-wf-subnav-item-logocard{display:flex;max-width:13.125rem}}
`, Hn = `.visually-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin-block:-1px;margin-inline:-1px;overflow:hidden;padding:0;position:absolute;width:1px}:host{display:block;position:relative;width:100%}.main-link{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:transparent;border:0;color:inherit;font-family:inherit;font-size:inherit;padding:0;transition:color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1)),background-color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1));-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;--link-block-padding: .25rem;--link-inline-padding: 1rem;align-items:center;border-radius:.5rem;box-sizing:border-box;color:var(--color-text-secondary, #aaaaae);display:flex;justify-content:space-between;margin-block:calc(var(--link-block-padding) * -1);margin-inline:calc(var(--link-inline-padding) * -1);min-height:2rem;padding-block:var(--link-block-padding);padding-inline:var(--link-inline-padding);position:relative;text-decoration:none;-webkit-user-select:none;user-select:none;z-index:3}.main-link>*{pointer-events:none}.main-link:not([disabled]){cursor:pointer}.main-link:hover,.main-link.active{background-color:var(--color-background-elevated-high-hover, #404044);color:var(--color-text-primary, #e6e6ea)}.main-link .label{font-family:Inter,sans-serif;font-style:normal;font-weight:400;line-height:150%;font-size:.875rem;letter-spacing:.02em;flex-grow:1}@media (max-width: 1279.9px){.main-link{background-color:var(--color-background-elevated-default, #202024);color:var(--color-text-primary, #e6e6ea);border-radius:.75rem;margin:0;padding-block:1rem;padding-inline:1rem;text-align:start;width:100%}}@media (max-width: 1279.9px){.main-link:hover{background-color:var(--color-background-elevated-hover, #404044)}}.main-link .label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.main-link .icon-wrapper{display:flex}.main-link svg{transition:transform var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1));fill:var(--color-text-secondary, #aaaaae);flex-shrink:0;height:1.25rem;width:1.25rem}@media (min-width: 1280px){.main-link svg{display:none}}@media (max-width: 1279.9px){.main-link svg{fill:var(--color-text-primary, #e6e6ea)}}
`;
var Un = Object.defineProperty, Vn = Object.getOwnPropertyDescriptor, Y = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? Vn(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && Un(e, i, n), n;
};
let M = class extends R {
  constructor() {
    super(...arguments), this.hrefTemplate = "", this.locale = "", this.domain = "", this.key = "", this.label = "", this.owner = "", this.rtl = !1, this.active = !1, this.forceActiveStyle = !1, this.hasMenu = !1;
  }
  render() {
    const e = ie({ domain: this.domain, hrefTemplate: this.hrefTemplate, locale: this.locale });
    if (this.label) {
      if (!this.hasMenu && !e)
        return console.debug("main-link needs an href attribute and/or associated with a menu!"), b``;
    } else
      return console.debug("main-link label attribute is missing!"), b``;
    const i = b`<span aria-hidden="true" class="icon-wrapper">
			${this.rtl ? K(kr) : K($r)}
		</span>`;
    return e ? b`
				<a
					aria-expanded="${O(
      this.hasMenu && this.active ? !0 : this.hasMenu && !this.active ? !1 : void 0
    )}"
					class="main-link ${this.forceActiveStyle || this.active ? "active" : ""}"
					href=${e}
					role=${O(this.hasMenu && e ? "button" : void 0)}
				>
					<span class="label">${this.label}</span>
					${this.hasMenu ? i : ""}
				</a>
				<slot></slot>
			` : b`
			<button aria-expanded="${this.active}" class="main-link ${this.forceActiveStyle || this.active ? "active" : ""}">
				<span class="label">${this.label}</span>
				${this.hasMenu ? i : ""}
			</button>
			<slot></slot>
		`;
  }
};
M.styles = F`
		${D(Hn)}
	`;
Y([
  f()
], M.prototype, "hrefTemplate", 2);
Y([
  f()
], M.prototype, "locale", 2);
Y([
  f()
], M.prototype, "domain", 2);
Y([
  f()
], M.prototype, "key", 2);
Y([
  f()
], M.prototype, "label", 2);
Y([
  f()
], M.prototype, "owner", 2);
Y([
  f({ type: Boolean })
], M.prototype, "rtl", 2);
Y([
  f({ type: Boolean, converter: U })
], M.prototype, "active", 2);
Y([
  f({ type: Boolean, converter: U })
], M.prototype, "forceActiveStyle", 2);
Y([
  f({ type: Boolean, converter: U })
], M.prototype, "hasMenu", 2);
M = Y([
  j("epic-wf-main-link")
], M);
const ai = `.visually-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin-block:-1px;margin-inline:-1px;overflow:hidden;padding:0;position:absolute;width:1px}:root{display:block;position:relative}.subnav-link{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:transparent;border:0;color:inherit;font-family:inherit;font-size:inherit;padding:0;transition:color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1)),background-color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1));-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;--link-block-padding: .25rem;--link-inline-padding: 1rem;align-items:center;border-radius:.5rem;box-sizing:border-box;color:var(--color-text-secondary, #aaaaae);display:flex;justify-content:space-between;margin-block:calc(var(--link-block-padding) * -1);margin-inline:calc(var(--link-inline-padding) * -1);min-height:2rem;padding-block:var(--link-block-padding);padding-inline:var(--link-inline-padding);position:relative;text-decoration:none;-webkit-user-select:none;user-select:none;z-index:3;--link-inline-padding: .5rem}.subnav-link>*{pointer-events:none}.subnav-link:not([disabled]){cursor:pointer}.subnav-link:hover,.subnav-link.active{background-color:var(--color-background-elevated-high-hover, #404044);color:var(--color-text-primary, #e6e6ea)}.subnav-link .label{font-family:Inter,sans-serif;font-style:normal;font-weight:400;line-height:150%;font-size:.875rem;letter-spacing:.02em;flex-grow:1}.subnav-link__content{align-items:start;display:flex;flex-direction:column;flex-grow:1}.subnav-link .label{font-family:Inter,sans-serif;font-style:normal;font-weight:400;line-height:165%;font-size:1rem;color:var(--color-fill-primary-default, #26bbff)}.subnav-link__description{font-family:Inter,sans-serif;font-style:normal;font-weight:400;line-height:150%;font-size:.75rem;letter-spacing:.02em;color:var(--color-text-secondary, #aaaaae);margin:0}.subnav-link--logocard{--link-block-padding: .5rem;--link-inline-padding: .75rem;align-items:start;gap:1rem}.subnav-link--logocard .label{font-family:Inter Tight,sans-serif;font-style:normal;font-weight:700;line-height:150%;font-size:1rem;color:var(--color-text-primary, #e6e6ea)}.subnav-link__logo{background-color:var(--color-text-primary, #e6e6ea);flex-shrink:0;height:1.5rem;width:1.5rem}
`;
var Kn = Object.defineProperty, qn = Object.getOwnPropertyDescriptor, Wn = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? qn(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && Kn(e, i, n), n;
};
let Wt = class extends M {
  render() {
    const e = ie({ domain: this.domain, hrefTemplate: this.hrefTemplate, locale: this.locale });
    return b`<a class="subnav-link" href=${e}>
			<div class="subnav-link__content"><span class="label">${this.label}</span></div>
		</a>`;
  }
};
Wt.styles = F`
		${D(ai)}
	`;
Wt = Wn([
  j("epic-wf-subnav-item-basic-link")
], Wt);
var Zn = Object.defineProperty, Yn = Object.getOwnPropertyDescriptor, Ar = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? Yn(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && Zn(e, i, n), n;
};
let _t = class extends M {
  constructor() {
    super(...arguments), this.description = "";
  }
  render() {
    const t = ie({ domain: this.domain, hrefTemplate: this.hrefTemplate, locale: this.locale });
    return b`
			<a class="subnav-link" href=${t}>
				<div class="subnav-link__content">
					<span class="label">${this.label}</span>
					<p class="subnav-link__description">${this.description}</p>
				</div>
			</a>
		`;
  }
};
_t.styles = F`
		${D(ai)}
	`;
Ar([
  f()
], _t.prototype, "description", 2);
_t = Ar([
  j("epic-wf-subnav-item-desc-link")
], _t);
var Gn = Object.defineProperty, Qn = Object.getOwnPropertyDescriptor, he = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? Qn(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && Gn(e, i, n), n;
};
let Q = class extends R {
  constructor() {
    super(...arguments), this.condensed = !1, this.itemTitle = "", this.description = "", this.domain = "", this.links = new Array(), this.descLinks = new Array(), this.cardLinks = new Array();
  }
  /**
   * Set by parent in order to keep a reference from the parent Navigation class
   */
  onLinkClick(e, i) {
  }
  /**
   * Set by parent in order to keep a reference from the parent Navigation class
   */
  getMappedHygraphLocale(e) {
    return e;
  }
  render() {
    const e = this.cardLinks && this.cardLinks.length > 0, i = this.cardLinks.length > 0 || this.descLinks.length > 0;
    let r;
    return e ? r = b`
				<div class="subnav__cards ${this.cardLinks.length > 4 ? "subnav__cards--more" : null}">
					${this.cardLinks.map(
      (n) => b`
								<epic-wf-subnav-item-logocard
									@click=${(o) => {
        this.onLinkClick(o, n);
      }}
									label=${n.label || ""}
									hrefTemplate=${n.hrefTemplate || ""}
									locale=${this.getMappedHygraphLocale(n?.locale || "")}
									description=${O(n.description || "")}
									.logo=${n.logo || {}}
									logoAlt=${n.logoAlt || ""}
									owner=${O(n?.owner || "")}
									key=${O(n?.key || "")}
									domain=${(this == null ? void 0 : this.domain) || ""}
								></epic-wf-subnav-item-logocard>
							`
    ).splice(0, 6)}
				</div>
			` : r = b`
				<div class="subnav__links">
					${this.descLinks.map(
      (n) => b`
								<epic-wf-subnav-item-desc-link
									@click=${(o) => {
        this.onLinkClick(o, n);
      }}
									label=${n.label || ""}
									hrefTemplate=${n.hrefTemplate || ""}
									locale=${this.getMappedHygraphLocale(n?.locale || "")}
									description=${O(n.description || "")}
									owner=${O(n?.owner || "")}
									key=${O(n?.key || "")}
									domain=${(this == null ? void 0 : this.domain) || ""}
								></epic-wf-subnav-item-desc-link>
							`
    )}
				</div>
			`, b`
			<div class="subnav ${this.condensed ? "subnav--condensed" : ""}">
				<div class="subnav__col">
					<div class="subnav__title-description">
						<h3>${this.itemTitle}</h3>
						<p>${this.description}</p>
					</div>
					<div class="subnav__links">
						${this.links.map(
      (n) => b`
									<epic-wf-subnav-item-basic-link
										@click=${(o) => {
        this.onLinkClick(o, n);
      }}
										label=${n.label || ""}
										hrefTemplate=${n.hrefTemplate || ""}
										locale=${this.getMappedHygraphLocale(n?.locale || "")}
										owner=${O(n?.owner || "")}
										key=${O(n?.key || "")}
										domain=${(this == null ? void 0 : this.domain) || ""}
									></epic-wf-subnav-item-basic-link>
								`
    )}
					</div>
				</div>
				${i ? b`
							<hr class="subnav__hr" />
							${r}
					  ` : null}
			</div>
		`;
  }
};
Q.styles = F`
		${D(Bn)}
	`;
he([
  f({ type: Boolean })
], Q.prototype, "condensed", 2);
he([
  f()
], Q.prototype, "itemTitle", 2);
he([
  f()
], Q.prototype, "description", 2);
he([
  f()
], Q.prototype, "domain", 2);
he([
  f({ type: Array })
], Q.prototype, "links", 2);
he([
  f({ type: Array })
], Q.prototype, "descLinks", 2);
he([
  f({ type: Array })
], Q.prototype, "cardLinks", 2);
Q = he([
  j("epic-wf-subnav-item-menu")
], Q);
var Xn = Object.defineProperty, Jn = Object.getOwnPropertyDescriptor, Le = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? Jn(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && Xn(e, i, n), n;
};
let te = class extends R {
  constructor() {
    super(...arguments), this.mainLinks = new Array(), this.rtl = !1, this.hasOpenMenu = !1, this.active = -1, this.domain = "", this.locale = "";
  }
  closeMenu() {
    this.active = -1, this.hasOpenMenu = !1;
  }
  handleAnchorClick(e, i, r) {
    var n, o;
    i != null && i.menu && (o = (n = i?.menu) == null ? void 0 : n.links) != null && o.length ? (e.preventDefault(), this.handleButtonClick(e, r)) : this.onLinkClick(e, i);
  }
  handleKeyDown(e, i) {
    (e.code === "Enter" || e.code === "Space") && (e.preventDefault(), this.handleButtonClick(e, i));
  }
  handleButtonClick(e, i) {
    const r = this.active;
    this.active = r === i ? -1 : i, this.hasOpenMenu = r !== i, this.onSubmenu(e, this.hasOpenMenu, this.closeMenu.bind(this));
  }
  handlePointerEnter(e, i, r) {
    ye(e) || (this.active = i, r && (this.hasOpenMenu = !0), this.onSubmenu(e, this.hasOpenMenu, this.closeMenu.bind(this)));
  }
  handlePointerLeave(e) {
    ye(e) || (this.active = -1, this.hasOpenMenu = !1, this.onSubmenu(e, this.hasOpenMenu, this.closeMenu.bind(this)));
  }
  /**
   * Set by parent in order for the parent Navigation class to react
   */
  onSubmenu(e, i, r) {
  }
  /**
   * Set by parent in order to keep a reference from the parent Navigation class
   */
  onLinkClick(e, i) {
  }
  /**
   * Set by parent in order to keep a reference from the parent Navigation class
   */
  getMappedHygraphLocale(e) {
    return e;
  }
  render() {
    return b`
			<ul class="condensed-menu ${this.hasOpenMenu ? "has-open-menu" : null}">
				${this.mainLinks.map((e, i) => {
      var r, n;
      if (!e || !e.label)
        return;
      const o = !!(e != null && e.menu && (n = (r = e?.menu) == null ? void 0 : r.links) != null && n.length), a = o ? e.menu : null, l = b`
						<span aria-hidden="true" class="icon-wrapper">
							${this.rtl ? K(kr) : K($r)}
						</span>
					`, s = e.hrefTemplate ? b`
								<a
									@click=${(d) => this.handleAnchorClick(d, e, i)}
									@keydown=${o ? (d) => this.handleKeyDown(d, i) : null}
									@pointerenter=${(d) => this.handlePointerEnter(d, i, o)}
									aria-expanded="${this.active === i ? "true" : "false"}"
									class="condensed-menu__link"
									data-key=${O(e.key || "")}
									href=${ie({
        hrefTemplate: e.hrefTemplate,
        domain: this.domain,
        locale: this.locale
      })}
								>
									<span class="label">${e.label}</span>
									${o ? l : ""}
								</a>
						  ` : b`
								<button
									@click=${(d) => this.handleButtonClick(d, i)}
									@pointerenter=${(d) => this.handlePointerEnter(d, i, o)}
									aria-expanded="${this.active === i ? "true" : "false"}"
									label=${e.label}
									class="condensed-menu__link"
									data-key=${O(e.key || "")}
								>
									<span class="label">${e.label}</span>
									${l}
								</button>
						  `;
      return b`
						<li
							@pointerleave=${this.handlePointerLeave}
							active=${this.active === i}
							class="condensed-menu__item ${o ? "has-submenu" : ""}"
							label=${e.label}
						>
							${o ? b`${s}
										<epic-wf-subnav-item-menu
											?condensed=${!0}
											.cardLinks=${a?.cardLinks || []}
											.descLinks=${a?.descLinks || []}
											.links=${a?.links || []}
											.onLinkClick=${this.onLinkClick}
											.getMappedHygraphLocale=${this.getMappedHygraphLocale}
											description=${a?.description || ""}
											itemTitle=${a?.itemTitle || ""}
											domain=${(this == null ? void 0 : this.domain) || ""}
										>
										</epic-wf-subnav-item-menu> ` : e.hrefTemplate ? s : null}
						</li>
					`;
    })}
			</ul>
		`;
  }
};
te.styles = F`
		${D(Fn)}
	`;
Le([
  f({ type: Array })
], te.prototype, "mainLinks", 2);
Le([
  f({ type: Boolean })
], te.prototype, "rtl", 2);
Le([
  ni()
], te.prototype, "hasOpenMenu", 2);
Le([
  ni()
], te.prototype, "active", 2);
Le([
  f()
], te.prototype, "domain", 2);
Le([
  f()
], te.prototype, "locale", 2);
te = Le([
  j("epic-wf-condensed-menu")
], te);
const ea = `.visually-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin-block:-1px;margin-inline:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.cta-button{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:transparent;border:0;color:inherit;font-family:inherit;font-size:inherit;padding:0;transition:color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1)),background-color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1));-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;--link-block-padding: .25rem;--link-inline-padding: 1rem;align-items:center;border-radius:.5rem;box-sizing:border-box;color:var(--color-text-secondary, #aaaaae);display:flex;justify-content:space-between;margin-block:calc(var(--link-block-padding) * -1);margin-inline:calc(var(--link-inline-padding) * -1);min-height:2rem;padding-block:var(--link-block-padding);padding-inline:var(--link-inline-padding);position:relative;text-decoration:none;-webkit-user-select:none;user-select:none;z-index:3;--link-inline-padding: .75rem;background:var(--color-fill-primary-default, #26bbff);margin:0;text-align:center}.cta-button>*{pointer-events:none}.cta-button:not([disabled]){cursor:pointer}.cta-button:hover,.cta-button.active{background-color:var(--color-background-elevated-high-hover, #404044);color:var(--color-text-primary, #e6e6ea)}.cta-button .label{font-family:Inter,sans-serif;font-style:normal;font-weight:400;line-height:150%;font-size:.875rem;letter-spacing:.02em;flex-grow:1}@media (max-width: 1279.9px){.cta-button{--link-block-padding: 1rem;--link-inline-padding: 1rem;flex:1;max-width:21.375rem}}.cta-button:hover{background:var(--color-fill-primary-hover, #61cdff)}.cta-button .label{font-family:Inter,sans-serif;font-style:normal;font-weight:500;line-height:100%;letter-spacing:.02em;font-size:.875rem;color:var(--color-text-on-accent, #101014)}
`;
var ta = Object.defineProperty, ia = Object.getOwnPropertyDescriptor, Ie = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? ia(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && ta(e, i, n), n;
};
let ce = class extends R {
  constructor() {
    super(...arguments), this.label = "", this.href = "", this.domain = "", this.locale = "", this.target = "";
  }
  render() {
    if (!this.href || !this.label)
      return b``;
    const t = ie({ domain: this.domain, hrefTemplate: this.href, locale: this.locale });
    return b`
			<a class="cta-button" href=${t} .target=${this.target}>
				<span class="label">${this.label}</span>
			</a>
		`;
  }
};
ce.styles = F`
		${D(ea)}
	`;
Ie([
  f()
], ce.prototype, "label", 2);
Ie([
  f()
], ce.prototype, "href", 2);
Ie([
  f()
], ce.prototype, "domain", 2);
Ie([
  f()
], ce.prototype, "locale", 2);
Ie([
  f()
], ce.prototype, "target", 2);
ce = Ie([
  j("epic-wf-cta-button")
], ce);
const ra = `:host{display:inline-flex;height:2rem;width:2rem}:host svg{transition:fill var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1));--avatar-background: var(--color-border-subtle, #303034);fill:var(--color-text-secondary, #aaaaae);flex-grow:1}:host svg circle{fill:var(--color-fill-avatar-circle, #a9d34f);stroke:var(--color-background-default, #101014)}:host svg:hover{fill:var(--color-text-link-secondary-default, #e6e6ea)}
`;
var na = Object.defineProperty, aa = Object.getOwnPropertyDescriptor, Lr = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? aa(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && na(e, i, n), n;
};
let yt = class extends R {
  constructor() {
    super(...arguments), this.isLoggedIn = !1;
  }
  render() {
    const t = this.isLoggedIn ? bn`<circle cx="28" cy="28" r="5" stroke-width="2" />` : "";
    return b`
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
				<rect width="32" height="32" fill="var(--avatar-background)" rx="16" />
				${t}
				<path
					fill-rule="evenodd"
					d="M16 9.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5ZM12.25 12a3.75 3.75 0 1 1 7.5 0 3.75 3.75 0 0 1-7.5 0Zm.39 6.75a1.25 1.25 0 0 0-1.226 1.005l-.678 3.392a.75.75 0 1 1-1.471-.294l.678-3.392a2.75 2.75 0 0 1 2.697-2.211h6.72a2.75 2.75 0 0 1 2.697 2.21l.679 3.393a.75.75 0 0 1-1.471.294l-.679-3.392a1.25 1.25 0 0 0-1.226-1.005h-6.72Z"
					clip-rule="evenodd"
				/>
			</svg>
		`;
  }
};
yt.styles = F`
		${D(ra)}
	`;
Lr([
  f({ type: Boolean, converter: U })
], yt.prototype, "isLoggedIn", 2);
yt = Lr([
  j("epic-wf-avatar-icon")
], yt);
var oa = Object.defineProperty, sa = Object.getOwnPropertyDescriptor, la = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? sa(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && oa(e, i, n), n;
};
let Di = class extends R {
  render() {
    return b`<svg
			xmlns="http://www.w3.org/2000/svg"
			viewBox="0 0 2 32"
			height="32"
			width="2"
			fill="var(--color-border-subtle, #303034)"
		>
			<path d="M0 0h2v32H0z" />
		</svg>`;
  }
};
Di = la([
  j("epic-wf-bar-icon")
], Di);
const da = `:host{display:flex;align-items:center}:host .logo{display:block;display:flex;align-items:center}:host .logo__img{display:block}:host .logo__img--icon{display:none}@media (min-width: 1440px) and (max-width: 1560px){:host .logo--has-icon .logo__img{display:none}:host .logo--has-icon .logo__img--icon{display:block}}@media (min-width: 370px) and (max-width: 410px){:host .logo--has-icon .logo__img{height:24px;width:auto}}@media (max-width: 369.9px){:host .logo--has-icon .logo__img{display:none}:host .logo--has-icon .logo__img--icon{display:block}}@media (max-width: 1023.9px){:host .logo .logo__img.mobile-help{height:20px;width:auto}}:host a[href].logo{cursor:pointer}
`;
var ca = Object.defineProperty, pa = Object.getOwnPropertyDescriptor, re = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? pa(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && ca(e, i, n), n;
};
let Z = class extends R {
  constructor() {
    super(...arguments), this.domain = "", this.hrefTemplate = "", this.locale = "", this.logo = {}, this.iconOnlyLogo = {}, this.forDrawer = !1, this.logoAlt = "", this.width = 32;
  }
  render() {
    var e, i;
    const r = !!(this.logo && (e = this.logo) != null && e.url), n = !!(this.iconOnlyLogo && (i = this.iconOnlyLogo) != null && i.url), o = ie({ domain: this.domain, hrefTemplate: this.hrefTemplate, locale: this.locale }), a = !!o, l = r ? b`
					<img
						alt=${this.logoAlt}
						class="logo__img"
						fetchpriority="high"
						height="32"
						src=${this.logo.url}
						width=${this.width || "auto"}
					/>
			  ` : null, s = n ? b`
					<img
						alt=${this.logoAlt}
						class="logo__img logo__img--icon"
						height="32"
						src=${this.iconOnlyLogo.url}
						width="32"
					/>
			  ` : null;
    return a ? b`<a href=${o} class="logo ${n ? "logo--has-icon" : ""}">${l}${s}</a>` : b`<span class="logo ${n ? "logo--has-icon" : ""}">${l}${s}</span>`;
  }
};
Z.styles = F`
		${D(da)}
	`;
re([
  f()
], Z.prototype, "domain", 2);
re([
  f()
], Z.prototype, "hrefTemplate", 2);
re([
  f()
], Z.prototype, "locale", 2);
re([
  f({ type: Object })
], Z.prototype, "logo", 2);
re([
  f({ type: Object })
], Z.prototype, "iconOnlyLogo", 2);
re([
  f({ type: Boolean, reflect: !0 })
], Z.prototype, "forDrawer", 2);
re([
  f()
], Z.prototype, "logoAlt", 2);
re([
  f({ type: Number })
], Z.prototype, "width", 2);
Z = re([
  j("epic-wf-property-logo")
], Z);
const Rt = `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M10.5 2.25a8.25 8.25 0 1 0 5.28 14.59l4.69 4.69a.75.75 0 1 0 1.06-1.06l-4.69-4.69A8.25 8.25 0 0 0 10.5 2.25ZM3.75 10.5a6.75 6.75 0 1 1 13.5 0 6.75 6.75 0 0 1-13.5 0Z" clip-rule="evenodd"/>
</svg>
`, ua = `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M4.47 4.47a.75.75 0 0 1 1.06 0L12 10.94l6.47-6.47a.75.75 0 1 1 1.06 1.06L13.06 12l6.47 6.47a.75.75 0 1 1-1.06 1.06L12 13.06l-6.47 6.47a.75.75 0 0 1-1.06-1.06L10.94 12 4.47 5.53a.75.75 0 0 1 0-1.06Z" clip-rule="evenodd"/>
</svg>
`;
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const ha = (t, e, i) => {
  for (const r of e)
    if (r[0] === t)
      return (0, r[1])();
  return i?.();
};
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const ji = yr(class extends wr {
  constructor(t) {
    var e;
    if (super(t), t.type !== _r.ATTRIBUTE || t.name !== "class" || ((e = t.strings) == null ? void 0 : e.length) > 2)
      throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.");
  }
  render(t) {
    return " " + Object.keys(t).filter((e) => t[e]).join(" ") + " ";
  }
  update(t, [e]) {
    var i, r;
    if (this.it === void 0) {
      this.it = /* @__PURE__ */ new Set(), t.strings !== void 0 && (this.st = new Set(t.strings.join(" ").split(/\s/).filter((o) => o !== "")));
      for (const o in e)
        e[o] && !((i = this.st) != null && i.has(o)) && this.it.add(o);
      return this.render(e);
    }
    const n = t.element.classList;
    for (const o of this.it)
      o in e || (n.remove(o), this.it.delete(o));
    for (const o in e) {
      const a = !!e[o];
      a === this.it.has(o) || (r = this.st) != null && r.has(o) || (a ? (n.add(o), this.it.add(o)) : (n.remove(o), this.it.delete(o)));
    }
    return de;
  }
}), fa = `.visually-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin-block:-1px;margin-inline:-1px;overflow:hidden;padding:0;position:absolute;width:1px}@keyframes fade-in{0%{opacity:0}to{opacity:1}}@media (max-width: 1279.9px){:host{flex:1}}:host button{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:transparent;border:0;color:inherit;font-family:inherit;font-size:inherit;padding:0;text-decoration:none;-webkit-user-select:none;user-select:none}:host button>*{pointer-events:none}:host button:not([disabled]){cursor:pointer}:host svg{fill:currentColor}:host input[type=search]::-webkit-search-decoration,:host input[type=search]::-webkit-search-cancel-button,:host input[type=search]::-webkit-search-results-button,:host input[type=search]::-webkit-search-results-decoration{display:none}:host .icon-wrapper{display:flex}:host .search-form{align-items:center;display:flex;width:var(--search-box-width);column-gap:1rem}:host .search-form.active .search-button{display:none}:host .search-form:not(.active) .search{display:none}:host .search-form:not(.prestine) .search-button,:host .search-form:not(.prestine) .search{animation:fade-in var(--easing-duration, .2s) ease-in-out}:host .search-button{color:var(--color-text-secondary, #aaaaae);display:flex;padding-block:.25rem;padding-inline:.25rem;transition:opacity .2s ease-in-out}:host .search-button:hover{color:var(--color-text-link-secondary-default, #e6e6ea)}:host .search-button svg{transition:fill var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1));fill:currentColor;height:1.5rem;width:1.5rem}:host .search{align-items:center;border-block:.125rem solid var(--color-border-default, #707074);border-inline:.125rem solid var(--color-border-default, #707074);border-radius:1rem;color:var(--color-text-secondary, #aaaaae);display:flex;gap:.5rem;height:1.75rem;padding-inline-end:.25rem;padding-inline-start:.625rem;transition:opacity .2s ease-in-out;width:var(--search-box-width)}:host .search:focus-within{border-color:var(--color-text-select-default, #26bbff)}:host .search__icon{display:flex}:host .search__icon svg{width:1.25rem;height:1.25rem}:host .search__submit{order:-1}:host .search__input{font-family:Inter,sans-serif;font-style:normal;font-weight:400;line-height:150%;font-size:.875rem;letter-spacing:.02em;background-color:transparent;border:none;color:var(--color-text-primary, #e6e6ea);flex:1 0 auto;height:100%;outline:none;padding:0;width:10.75rem}:host .search__input::placeholder{color:var(--color-text-secondary, #aaaaae)}:host .search__close{align-items:center;aspect-ratio:1/1;display:flex;height:100%;justify-content:center}:host .search__close svg{width:.75rem;height:.75rem;transition:fill var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1))}:host .search__close:hover svg{fill:var(--color-text-link-secondary-default, #e6e6ea)}@media (max-width: 1279.9px){:host .search__close{display:none}}:host .close-button{font-family:Inter,sans-serif;font-style:normal;font-weight:500;line-height:100%;letter-spacing:.02em;font-size:.75rem;background:transparent;border-radius:.25rem;color:var(--color-text-primary, #e6e6ea);display:none;height:1.5rem;padding-block:.25rem;padding-inline:.5rem;text-align:center;vertical-align:middle}@media (max-width: 1279.9px){:host .close-button{display:block}}:host .close-button.cancel-button{flex-shrink:0}:host([mode=static]){display:flex;flex-wrap:nowrap;width:100%}:host([mode=static]) .active{border-color:var(--color-border-default, #707074);border-radius:1.5rem;grid-template-columns:1.25rem auto;width:100%}
`;
var ma = Object.defineProperty, ga = Object.getOwnPropertyDescriptor, G = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? ga(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && ma(e, i, n), n;
};
const va = ["normal", "static", "trigger"], ba = {
  fromAttribute: (t, e) => va.includes(t) ? t : "normal",
  toAttribute: (t, e) => t
};
let H = class extends R {
  constructor() {
    super(...arguments), this.activateSearchLabel = "Open Search", this.deactivateSearchLabel = "Close Search", this.inputLabel = "Search the Epic Games website", this.placeholderLabel = "Search", this.submitLabel = "Search", this.cancelLabel = "Cancel", this.mode = "normal", this.opened = !1, this._prestine = !0;
  }
  render() {
    return b`
			${ha(
      this.mode,
      [
        ["normal", this.normalMode.bind(this)],
        ["static", this.staticMode.bind(this)],
        ["trigger", this.triggerMode.bind(this)]
      ],
      this.normalMode
    )}
		`;
  }
  updated() {
    this.opened && this._inputElement && this._inputElement.focus();
  }
  /* ***************************** */
  /* Templates and Private methods */
  /* ***************************** */
  normalMode() {
    const e = { active: this.opened || this.isStaticMode, prestine: this._prestine };
    return b`
			<form
				@keydown=${this._keypress}
				@submit=${this._submit}
				autocomplete="off"
				class="search-form ${ji(e)}"
				role="search"
			>
				${this.opened ? this.activeTemplate() : this.deactiveTemplate()} ${this.cancelBtnTemplate()}
			</form>
		`;
  }
  staticMode() {
    const e = { active: !0, static: !0, prestine: this._prestine };
    return b`
			<form
				@keydown=${this._keypress}
				@submit=${this._submit}
				autocomplete="off"
				class="search-form ${ji(e)}"
				role="search"
			>
				${this.activeTemplate()} ${this.cancelBtnTemplate()}
			</form>
		`;
  }
  triggerMode() {
    return b`<button
			@click=${this._toggleActive}
			aria-label=${this.opened ? this.deactivateSearchLabel : this.activateSearchLabel}
			class="search-button"
		>
			<span aria-hidden="true" class="icon-wrapper">${K(Rt)}</span>
		</button>`;
  }
  activeTemplate() {
    const e = this.isStaticMode ? null : b`<button
					@click=${this._deactivate}
					aria-label=${this.deactivateSearchLabel}
					class="search__close"
					type="reset"
			  >
					<span aria-hidden="true" class="icon-wrapper">${K(ua)}</span>
			  </button>`;
    return b`
			<div class="search">
				<input
					aria-label=${this.inputLabel}
					class="search__input"
					id="search"
					inputmode="search"
					placeholder="${this.placeholderLabel}"
					type="search"
				/>
				<button class="search__submit" type="submit">
					<div aria-hidden="true" class="search__icon">${K(Rt)}</div>
					<span class="visually-hidden">${this.submitLabel}</span>
				</button>
				${e}
			</div>
		`;
  }
  deactiveTemplate() {
    return b`<button @click=${this._activate} aria-label=${this.activateSearchLabel} class="search-button">
			<span aria-hidden="true" class="icon-wrapper">${K(Rt)}</span>
		</button>`;
  }
  cancelBtnTemplate() {
    return !this.isStaticMode && this.opened ? b`<button @click="${this._deactivate}" class="close-button cancel-button" type="reset">
				${this.cancelLabel}
			</button>` : null;
  }
  get isStaticMode() {
    return this.mode === "static";
  }
  _setOpenedFlag(e) {
    this.opened = e, this.opened ? this.setAttribute("opened", "") : this.removeAttribute("opened");
  }
  /* ************** */
  /* Event handlers */
  /* ************** */
  _toggleActive(e) {
    this._prestine = !1, this._setOpenedFlag(!this.opened), this.dispatchEvent(
      new CustomEvent(Te.SEARCH_ACTIVATED, {
        detail: { activated: this.opened },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _activate(e) {
    this._prestine = !1, this._setOpenedFlag(!0), this.dispatchEvent(
      new CustomEvent(Te.SEARCH_ACTIVATED, {
        detail: { activated: !0 },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _deactivate(e) {
    this._prestine = !1, this._setOpenedFlag(!1), this.dispatchEvent(
      new CustomEvent(Te.SEARCH_ACTIVATED, {
        detail: { activated: !1 },
        bubbles: !0,
        composed: !0
      })
    );
  }
  _submit(e) {
    e.stopPropagation(), e.preventDefault(), this.opened && (e.preventDefault(), e.stopPropagation(), this._onSearch(e));
  }
  _keypress(e) {
    if (this.opened)
      switch (e.key) {
        case "Escape": {
          e.preventDefault(), e.stopPropagation(), this._deactivate();
          break;
        }
        default:
          if (e.stopPropagation(), this._inputElement) {
            const i = this._inputElement.value;
            setTimeout(() => {
              this.dispatchEvent(
                new CustomEvent(Te.SEARCH_KEYDOWN, {
                  detail: { originalEvent: e, value: i },
                  bubbles: !0,
                  composed: !0
                })
              );
            }, 0);
          }
      }
  }
  _onSearch(e) {
    if (this._inputElement) {
      const i = this._inputElement.value;
      i.length > 0 && (setTimeout(() => {
        this.dispatchEvent(
          new CustomEvent(Te.SEARCH, {
            detail: { originalEvent: e, value: i },
            bubbles: !0,
            composed: !0
          })
        );
      }, 0), this._deactivate());
    }
  }
};
H.styles = F`
		${D(fa)}
	`;
G([
  f()
], H.prototype, "activateSearchLabel", 2);
G([
  f()
], H.prototype, "deactivateSearchLabel", 2);
G([
  f()
], H.prototype, "inputLabel", 2);
G([
  f()
], H.prototype, "placeholderLabel", 2);
G([
  f()
], H.prototype, "submitLabel", 2);
G([
  f()
], H.prototype, "cancelLabel", 2);
G([
  f({ type: String, attribute: !0, reflect: !0, converter: ba })
], H.prototype, "mode", 2);
G([
  f({ type: Boolean })
], H.prototype, "opened", 2);
G([
  ni()
], H.prototype, "_prestine", 2);
G([
  jn("#search", !1)
], H.prototype, "_inputElement", 2);
H = G([
  j("epic-wf-search-box")
], H);
const _a = `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M12 4.75a.75.75 0 0 1 0-1.5h4.75V8a.75.75 0 0 1-1.5 0V5.81l-4.72 4.72a.75.75 0 1 1-1.06-1.06l4.72-4.72H12Zm-7 2a.25.25 0 0 0-.25.25v8c0 .138.112.25.25.25h8a.25.25 0 0 0 .25-.25v-2a.75.75 0 0 1 1.5 0v2A1.75 1.75 0 0 1 13 16.75H5A1.75 1.75 0 0 1 3.25 15V7c0-.966.784-1.75 1.75-1.75h2a.75.75 0 0 1 0 1.5H5Z" clip-rule="evenodd"/>
</svg>
`, ya = `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M3.784 11.25h3.99c.153-2.35.994-4.44 1.815-5.969.282-.525.564-.988.82-1.378a8.255 8.255 0 0 0-6.625 7.347ZM12 4.232c-.305.43-.697 1.03-1.09 1.759-.75 1.398-1.481 3.237-1.632 5.259h5.444c-.15-2.022-.882-3.861-1.633-5.259-.392-.73-.784-1.33-1.089-1.76Zm2.722 8.518H9.278c.15 2.022.882 3.861 1.633 5.259.392.73.784 1.33 1.089 1.76.305-.43.697-1.03 1.09-1.76.75-1.398 1.481-3.237 1.632-5.259Zm-4.313 7.347c-.256-.39-.538-.853-.82-1.378-.82-1.528-1.662-3.618-1.815-5.969h-3.99a8.255 8.255 0 0 0 6.625 7.347Zm3.182 0c.256-.39.538-.853.82-1.378.82-1.528 1.662-3.618 1.815-5.969h3.99a8.255 8.255 0 0 1-6.625 7.347Zm6.625-8.847h-3.99c-.153-2.35-.994-4.44-1.815-5.969a18.45 18.45 0 0 0-.82-1.378 8.255 8.255 0 0 1 6.625 7.347ZM2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Z" clip-rule="evenodd"/>
</svg>
`, wa = `<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M10 3.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5ZM6.25 6a3.75 3.75 0 1 1 7.5 0 3.75 3.75 0 0 1-7.5 0ZM6.64 12.75a1.25 1.25 0 0 0-1.226 1.005l-.679 3.392a.75.75 0 1 1-1.47-.294l.678-3.392A2.75 2.75 0 0 1 6.64 11.25h6.72c1.311 0 2.44.925 2.697 2.21l.678 3.393a.75.75 0 1 1-1.47.294l-.679-3.392a1.25 1.25 0 0 0-1.226-1.005H6.64Z" clip-rule="evenodd"/>
</svg>
`, xa = `.visually-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin-block:-1px;margin-inline:-1px;overflow:hidden;padding:0;position:absolute;width:1px}@media (min-width: 1280px){:host([data-show-icon-lg-up=true]) svg{display:unset}}.simple-menu-item{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:transparent;border:0;color:inherit;font-family:inherit;font-size:inherit;padding:0;transition:color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1)),background-color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1));-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;--link-block-padding: .25rem;--link-inline-padding: 1rem;align-items:center;border-radius:.5rem;box-sizing:border-box;color:var(--color-text-secondary, #aaaaae);display:flex;justify-content:space-between;margin-block:calc(var(--link-block-padding) * -1);margin-inline:calc(var(--link-inline-padding) * -1);min-height:2rem;padding-block:var(--link-block-padding);padding-inline:var(--link-inline-padding);position:relative;text-decoration:none;-webkit-user-select:none;user-select:none;z-index:3;--link-inline-padding: .75rem}.simple-menu-item>*{pointer-events:none}.simple-menu-item:not([disabled]){cursor:pointer}.simple-menu-item:hover,.simple-menu-item.active{background-color:var(--color-background-elevated-high-hover, #404044);color:var(--color-text-primary, #e6e6ea)}.simple-menu-item .label{font-family:Inter,sans-serif;font-style:normal;font-weight:400;line-height:150%;font-size:.875rem;letter-spacing:.02em;flex-grow:1}@media (max-width: 1279.9px){.simple-menu-item{background:var(--color-background-elevated-high-default, #202024);color:var(--color-text-primary, #e6e6ea);border-radius:.75rem;margin:0;padding-block:1rem;padding-inline:1rem;text-align:start;width:100%}}.simple-menu-item .label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:flex;align-items:center}.simple-menu-item svg{fill:var(--color-text-secondary, #aaaaae);flex-shrink:0;height:1.25rem;transform:translate(calc(.25rem * var(--transform-direction)));width:1.25rem}.simple-menu-item svg:hover{fill:var(--color-text-link-secondary-default, #e6e6ea)}@media (min-width: 1280px){.simple-menu-item svg{display:none}}@media (max-width: 1279.9px){.simple-menu-item svg{fill:var(--color-text-primary, #e6e6ea)}}@media (min-width: 1280px){.simple-menu-item.button-with-icon{width:calc(100% + var(--link-inline-padding) * 2)}}.simple-menu-item.no-hover{pointer-events:none}
`;
var ka = Object.defineProperty, $a = Object.getOwnPropertyDescriptor, Re = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? $a(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && ka(e, i, n), n;
}, Ze = /* @__PURE__ */ ((t) => (t.arrowUpRightSquare = "arrowUpRightFromSquare", t.globe = "globe", t.user = "user", t))(Ze || {});
let pe = class extends M {
  constructor() {
    super(...arguments), this.icon = "", this.labelStyle = "", this.labelAfterStyle = "", this.labelBeforeStyle = "", this.noHoverStyle = !1;
  }
  render() {
    const e = ie({ domain: this.domain, hrefTemplate: this.hrefTemplate, locale: this.locale });
    if (!this.label)
      return console.debug("simple-menu-item label attribute is missing!"), b``;
    let i;
    switch (this.icon) {
      case "arrowUpRightFromSquare": {
        i = b`${K(_a)}`;
        break;
      }
      case "globe": {
        i = b`${K(ya)}`;
        break;
      }
      case "user": {
        i = b`${K(wa)}`;
        break;
      }
      default:
        i = void 0;
    }
    const r = b`
			<style>
				.simple-menu-item span.label {
					${this.labelStyle};
				}
				.simple-menu-item .label::before {
					${this.labelBeforeStyle};
				}
				.simple-menu-item .label::after {
					${this.labelAfterStyle};
				}
			</style>
			<span class="label">${this.label}</span>
			${O(i)}
		`;
    return e ? b`
				<a class="simple-menu-item ${this.noHoverStyle ? "no-hover" : ""}" href="${e}">${r}</a>
			` : b`
			<button class="simple-menu-item ${this.noHoverStyle ? "no-hover" : ""} ${this.icon ? "button-with-icon" : ""}">
				${r}
			</button>
		`;
  }
};
pe.styles = F`
		${D(xa)}
	`;
Re([
  f()
], pe.prototype, "icon", 2);
Re([
  f()
], pe.prototype, "labelStyle", 2);
Re([
  f()
], pe.prototype, "labelAfterStyle", 2);
Re([
  f()
], pe.prototype, "labelBeforeStyle", 2);
Re([
  f({ type: Boolean, converter: U })
], pe.prototype, "noHoverStyle", 2);
pe = Re([
  j("epic-wf-simple-menu-item")
], pe);
const Aa = `:host{align-items:stretch;box-sizing:border-box;display:flex;flex-direction:column;gap:.5rem}@media (min-width: 1280px){:host{box-shadow:0 32px 16px #0000001a,0 16px 8px #0000001a,0 8px 4px #0000001a,0 4px 2px #0000001a,0 2px 1px #0000001a;background:var(--color-background-elevated-high-default, #202024);border-radius:.5rem;min-width:10rem;padding-block:1.5rem;padding-inline:1.25rem}}
`;
var La = Object.defineProperty, Sa = Object.getOwnPropertyDescriptor, Sr = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? Sa(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && La(e, i, n), n;
};
let wt = class extends R {
  constructor() {
    super(...arguments), this.links = new Array();
  }
  render() {
    return b` <slot> </slot> `;
  }
};
wt.styles = F`
		${D(Aa)}
	`;
Sr([
  f({ type: Array })
], wt.prototype, "links", 2);
wt = Sr([
  j("epic-wf-simple-menu")
], wt);
var Ea = Object.defineProperty, Ta = Object.getOwnPropertyDescriptor, oi = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? Ta(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && Ea(e, i, n), n;
};
let it = class extends M {
  constructor() {
    super(...arguments), this.logo = {}, this.description = "";
  }
  render() {
    var e;
    const i = (e = this.logo) == null ? void 0 : e.url, r = `
			mask: url(${i}) center no-repeat;
			-webkit-mask: url(${i}) center no-repeat;
		`, n = ie({ domain: this.domain, hrefTemplate: this.hrefTemplate, locale: this.locale });
    return b`
			<a class="subnav-link subnav-link--logocard" href=${n}>
				<div aria-hidden="true" class="subnav-link__logo" style="${r}"></div>
				<div class="subnav-link__content">
					<span class="label">${this.label}</span>
					<p class="subnav-link__description">${this.description}</p>
				</div>
			</a>
		`;
  }
};
it.styles = F`
		${D(ai)}
	`;
oi([
  f({ type: Object })
], it.prototype, "logo", 2);
oi([
  f()
], it.prototype, "description", 2);
it = oi([
  j("epic-wf-subnav-item-logocard")
], it);
var B = /* @__PURE__ */ ((t) => (t.LTR = "ltr", t.RTL = "rtl", t))(B || {}), oe = /* @__PURE__ */ ((t) => (t.SEARCH = "epic-wf-nav-on-search", t.SEARCH_KEYDOWN = "epic-wf-nav-search-on-keydown", t.SEARCH_ACTIVATED = "epic-wf-nav-search-activated", t.NAV_LINK_CLICK = "epic-wf-nav-link-on-click", t.PROPERTY_LOGO_CLICK = "epic-wf-prop-logo-on-click", t.LOCALE_LINK_CLICK = "epic-wf-locale-on-click", t.CTA_CLICK = "epic-wf-cta-on-click", t.ACCOUNT_LINK_CLICK = "epic-wf-account-link-on-click", t.DRAWER_TOGGLE = "epic-wf-drawer-on-toggle", t))(oe || {});
const z = ({ hrefTemplate: t = "", domain: e = "", locale: i = "" }) => {
  if (!t)
    return "";
  const r = i?.replace(/_/g, "-");
  let n = t;
  return !e && /({|%7B)domain(}|%7D)/i.test(n) ? n = n.replace(/\/({|%7B)domain(}|%7D)/gi, e || "") : n = n.replace(/({|%7B)domain(}|%7D)/gi, e || ""), !r && /({|%7B)locale(}|%7D)/i.test(n) ? n = n.replace(/\/({|%7B)locale(}|%7D)/gi, r || "") : n = n.replace(/({|%7B)locale(}|%7D)/gi, r || ""), n;
};
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const mt = globalThis, si = mt.ShadowRoot && (mt.ShadyCSS === void 0 || mt.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, li = Symbol(), Fi = /* @__PURE__ */ new WeakMap();
let Er = class {
  constructor(e, i, r) {
    if (this._$cssResult$ = !0, r !== li)
      throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = e, this.t = i;
  }
  get styleSheet() {
    let e = this.o;
    const i = this.t;
    if (si && e === void 0) {
      const r = i !== void 0 && i.length === 1;
      r && (e = Fi.get(i)), e === void 0 && ((this.o = e = new CSSStyleSheet()).replaceSync(this.cssText), r && Fi.set(i, e));
    }
    return e;
  }
  toString() {
    return this.cssText;
  }
};
const Ye = (t) => new Er(typeof t == "string" ? t : t + "", void 0, li), Tr = (t, ...e) => {
  const i = t.length === 1 ? t[0] : e.reduce((r, n, o) => r + ((a) => {
    if (a._$cssResult$ === !0)
      return a.cssText;
    if (typeof a == "number")
      return a;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + a + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(n) + t[o + 1], t[0]);
  return new Er(i, t, li);
}, Ca = (t, e) => {
  if (si)
    t.adoptedStyleSheets = e.map((i) => i instanceof CSSStyleSheet ? i : i.styleSheet);
  else
    for (const i of e) {
      const r = document.createElement("style"), n = mt.litNonce;
      n !== void 0 && r.setAttribute("nonce", n), r.textContent = i.cssText, t.appendChild(r);
    }
}, Bi = si ? (t) => t : (t) => t instanceof CSSStyleSheet ? ((e) => {
  let i = "";
  for (const r of e.cssRules)
    i += r.cssText;
  return Ye(i);
})(t) : t;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const { is: Oa, defineProperty: Ma, getOwnPropertyDescriptor: Pa, getOwnPropertyNames: Na, getOwnPropertySymbols: za, getPrototypeOf: Ia } = Object, Tt = globalThis, Hi = Tt.trustedTypes, Ra = Hi ? Hi.emptyScript : "", Da = Tt.reactiveElementPolyfillSupport, Ge = (t, e) => t, xt = { toAttribute(t, e) {
  switch (e) {
    case Boolean:
      t = t ? Ra : null;
      break;
    case Object:
    case Array:
      t = t == null ? t : JSON.stringify(t);
  }
  return t;
}, fromAttribute(t, e) {
  let i = t;
  switch (e) {
    case Boolean:
      i = t !== null;
      break;
    case Number:
      i = t === null ? null : Number(t);
      break;
    case Object:
    case Array:
      try {
        i = JSON.parse(t);
      } catch {
        i = null;
      }
  }
  return i;
} }, di = (t, e) => !Oa(t, e), Ui = { attribute: !0, type: String, converter: xt, reflect: !1, hasChanged: di };
Symbol.metadata ??= Symbol("metadata"), Tt.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
class Oe extends HTMLElement {
  static addInitializer(e) {
    this._$Ei(), (this.l ??= []).push(e);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(e, i = Ui) {
    if (i.state && (i.attribute = !1), this._$Ei(), this.elementProperties.set(e, i), !i.noAccessor) {
      const r = Symbol(), n = this.getPropertyDescriptor(e, r, i);
      n !== void 0 && Ma(this.prototype, e, n);
    }
  }
  static getPropertyDescriptor(e, i, r) {
    const { get: n, set: o } = Pa(this.prototype, e) ?? { get() {
      return this[i];
    }, set(a) {
      this[i] = a;
    } };
    return { get() {
      return n?.call(this);
    }, set(a) {
      const l = n?.call(this);
      o.call(this, a), this.requestUpdate(e, l, r);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(e) {
    return this.elementProperties.get(e) ?? Ui;
  }
  static _$Ei() {
    if (this.hasOwnProperty(Ge("elementProperties")))
      return;
    const e = Ia(this);
    e.finalize(), e.l !== void 0 && (this.l = [...e.l]), this.elementProperties = new Map(e.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(Ge("finalized")))
      return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(Ge("properties"))) {
      const i = this.properties, r = [...Na(i), ...za(i)];
      for (const n of r)
        this.createProperty(n, i[n]);
    }
    const e = this[Symbol.metadata];
    if (e !== null) {
      const i = litPropertyMetadata.get(e);
      if (i !== void 0)
        for (const [r, n] of i)
          this.elementProperties.set(r, n);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [i, r] of this.elementProperties) {
      const n = this._$Eu(i, r);
      n !== void 0 && this._$Eh.set(n, i);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(e) {
    const i = [];
    if (Array.isArray(e)) {
      const r = new Set(e.flat(1 / 0).reverse());
      for (const n of r)
        i.unshift(Bi(n));
    } else
      e !== void 0 && i.push(Bi(e));
    return i;
  }
  static _$Eu(e, i) {
    const r = i.attribute;
    return r === !1 ? void 0 : typeof r == "string" ? r : typeof e == "string" ? e.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$Eg = new Promise((e) => this.enableUpdating = e), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((e) => e(this));
  }
  addController(e) {
    (this._$ES ??= []).push(e), this.renderRoot !== void 0 && this.isConnected && e.hostConnected?.();
  }
  removeController(e) {
    this._$ES?.splice(this._$ES.indexOf(e) >>> 0, 1);
  }
  _$E_() {
    const e = /* @__PURE__ */ new Map(), i = this.constructor.elementProperties;
    for (const r of i.keys())
      this.hasOwnProperty(r) && (e.set(r, this[r]), delete this[r]);
    e.size > 0 && (this._$Ep = e);
  }
  createRenderRoot() {
    const e = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return Ca(e, this.constructor.elementStyles), e;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(!0), this._$ES?.forEach((e) => e.hostConnected?.());
  }
  enableUpdating(e) {
  }
  disconnectedCallback() {
    this._$ES?.forEach((e) => e.hostDisconnected?.());
  }
  attributeChangedCallback(e, i, r) {
    this._$AK(e, r);
  }
  _$EO(e, i) {
    const r = this.constructor.elementProperties.get(e), n = this.constructor._$Eu(e, r);
    if (n !== void 0 && r.reflect === !0) {
      const o = (r.converter?.toAttribute !== void 0 ? r.converter : xt).toAttribute(i, r.type);
      this._$Em = e, o == null ? this.removeAttribute(n) : this.setAttribute(n, o), this._$Em = null;
    }
  }
  _$AK(e, i) {
    const r = this.constructor, n = r._$Eh.get(e);
    if (n !== void 0 && this._$Em !== n) {
      const o = r.getPropertyOptions(n), a = typeof o.converter == "function" ? { fromAttribute: o.converter } : o.converter?.fromAttribute !== void 0 ? o.converter : xt;
      this._$Em = n, this[n] = a.fromAttribute(i, o.type), this._$Em = null;
    }
  }
  requestUpdate(e, i, r, n = !1, o) {
    if (e !== void 0) {
      if (r ??= this.constructor.getPropertyOptions(e), !(r.hasChanged ?? di)(n ? o : this[e], i))
        return;
      this.C(e, i, r);
    }
    this.isUpdatePending === !1 && (this._$Eg = this._$EP());
  }
  C(e, i, r) {
    this._$AL.has(e) || this._$AL.set(e, i), r.reflect === !0 && this._$Em !== e && (this._$Ej ??= /* @__PURE__ */ new Set()).add(e);
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$Eg;
    } catch (i) {
      Promise.reject(i);
    }
    const e = this.scheduleUpdate();
    return e != null && await e, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending)
      return;
    if (!this.hasUpdated) {
      if (this._$Ep) {
        for (const [n, o] of this._$Ep)
          this[n] = o;
        this._$Ep = void 0;
      }
      const r = this.constructor.elementProperties;
      if (r.size > 0)
        for (const [n, o] of r)
          o.wrapped !== !0 || this._$AL.has(n) || this[n] === void 0 || this.C(n, this[n], o);
    }
    let e = !1;
    const i = this._$AL;
    try {
      e = this.shouldUpdate(i), e ? (this.willUpdate(i), this._$ES?.forEach((r) => r.hostUpdate?.()), this.update(i)) : this._$ET();
    } catch (r) {
      throw e = !1, this._$ET(), r;
    }
    e && this._$AE(i);
  }
  willUpdate(e) {
  }
  _$AE(e) {
    this._$ES?.forEach((i) => i.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(e)), this.updated(e);
  }
  _$ET() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$Eg;
  }
  shouldUpdate(e) {
    return !0;
  }
  update(e) {
    this._$Ej &&= this._$Ej.forEach((i) => this._$EO(i, this[i])), this._$ET();
  }
  updated(e) {
  }
  firstUpdated(e) {
  }
}
Oe.elementStyles = [], Oe.shadowRootOptions = { mode: "open" }, Oe[Ge("elementProperties")] = /* @__PURE__ */ new Map(), Oe[Ge("finalized")] = /* @__PURE__ */ new Map(), Da?.({ ReactiveElement: Oe }), (Tt.reactiveElementVersions ??= []).push("2.0.0");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const ci = globalThis, kt = ci.trustedTypes, Vi = kt ? kt.createPolicy("lit-html", { createHTML: (t) => t }) : void 0, Cr = "$lit$", le = `lit$${(Math.random() + "").slice(9)}$`, Or = "?" + le, ja = `<${Or}>`, $e = document, rt = () => $e.createComment(""), nt = (t) => t === null || typeof t != "object" && typeof t != "function", Mr = Array.isArray, Fa = (t) => Mr(t) || typeof t?.[Symbol.iterator] == "function", Dt = `[ 	
\f\r]`, Ue = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, Ki = /-->/g, qi = />/g, ge = RegExp(`>|${Dt}(?:([^\\s"'>=/]+)(${Dt}*=${Dt}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Wi = /'/g, Zi = /"/g, Pr = /^(?:script|style|textarea|title)$/i, Ba = (t) => (e, ...i) => ({ _$litType$: t, strings: e, values: i }), w = Ba(1), ue = Symbol.for("lit-noChange"), E = Symbol.for("lit-nothing"), Yi = /* @__PURE__ */ new WeakMap(), _e = $e.createTreeWalker($e, 129);
function Nr(t, e) {
  if (!Array.isArray(t) || !t.hasOwnProperty("raw"))
    throw Error("invalid template strings array");
  return Vi !== void 0 ? Vi.createHTML(e) : e;
}
const Ha = (t, e) => {
  const i = t.length - 1, r = [];
  let n, o = e === 2 ? "<svg>" : "", a = Ue;
  for (let l = 0; l < i; l++) {
    const s = t[l];
    let d, h, u = -1, k = 0;
    for (; k < s.length && (a.lastIndex = k, h = a.exec(s), h !== null); )
      k = a.lastIndex, a === Ue ? h[1] === "!--" ? a = Ki : h[1] !== void 0 ? a = qi : h[2] !== void 0 ? (Pr.test(h[2]) && (n = RegExp("</" + h[2], "g")), a = ge) : h[3] !== void 0 && (a = ge) : a === ge ? h[0] === ">" ? (a = n ?? Ue, u = -1) : h[1] === void 0 ? u = -2 : (u = a.lastIndex - h[2].length, d = h[1], a = h[3] === void 0 ? ge : h[3] === '"' ? Zi : Wi) : a === Zi || a === Wi ? a = ge : a === Ki || a === qi ? a = Ue : (a = ge, n = void 0);
    const x = a === ge && t[l + 1].startsWith("/>") ? " " : "";
    o += a === Ue ? s + ja : u >= 0 ? (r.push(d), s.slice(0, u) + Cr + s.slice(u) + le + x) : s + le + (u === -2 ? l : x);
  }
  return [Nr(t, o + (t[i] || "<?>") + (e === 2 ? "</svg>" : "")), r];
};
class at {
  constructor({ strings: e, _$litType$: i }, r) {
    let n;
    this.parts = [];
    let o = 0, a = 0;
    const l = e.length - 1, s = this.parts, [d, h] = Ha(e, i);
    if (this.el = at.createElement(d, r), _e.currentNode = this.el.content, i === 2) {
      const u = this.el.content.firstChild;
      u.replaceWith(...u.childNodes);
    }
    for (; (n = _e.nextNode()) !== null && s.length < l; ) {
      if (n.nodeType === 1) {
        if (n.hasAttributes())
          for (const u of n.getAttributeNames())
            if (u.endsWith(Cr)) {
              const k = h[a++], x = n.getAttribute(u).split(le), V = /([.?@])?(.*)/.exec(k);
              s.push({ type: 1, index: o, name: V[2], strings: x, ctor: V[1] === "." ? Va : V[1] === "?" ? Ka : V[1] === "@" ? qa : Ct }), n.removeAttribute(u);
            } else
              u.startsWith(le) && (s.push({ type: 6, index: o }), n.removeAttribute(u));
        if (Pr.test(n.tagName)) {
          const u = n.textContent.split(le), k = u.length - 1;
          if (k > 0) {
            n.textContent = kt ? kt.emptyScript : "";
            for (let x = 0; x < k; x++)
              n.append(u[x], rt()), _e.nextNode(), s.push({ type: 2, index: ++o });
            n.append(u[k], rt());
          }
        }
      } else if (n.nodeType === 8)
        if (n.data === Or)
          s.push({ type: 2, index: o });
        else {
          let u = -1;
          for (; (u = n.data.indexOf(le, u + 1)) !== -1; )
            s.push({ type: 7, index: o }), u += le.length - 1;
        }
      o++;
    }
  }
  static createElement(e, i) {
    const r = $e.createElement("template");
    return r.innerHTML = e, r;
  }
}
function ze(t, e, i = t, r) {
  if (e === ue)
    return e;
  let n = r !== void 0 ? i._$Co?.[r] : i._$Cl;
  const o = nt(e) ? void 0 : e._$litDirective$;
  return n?.constructor !== o && (n?._$AO?.(!1), o === void 0 ? n = void 0 : (n = new o(t), n._$AT(t, i, r)), r !== void 0 ? (i._$Co ??= [])[r] = n : i._$Cl = n), n !== void 0 && (e = ze(t, n._$AS(t, e.values), n, r)), e;
}
class Ua {
  constructor(e, i) {
    this._$AV = [], this._$AN = void 0, this._$AD = e, this._$AM = i;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(e) {
    const { el: { content: i }, parts: r } = this._$AD, n = (e?.creationScope ?? $e).importNode(i, !0);
    _e.currentNode = n;
    let o = _e.nextNode(), a = 0, l = 0, s = r[0];
    for (; s !== void 0; ) {
      if (a === s.index) {
        let d;
        s.type === 2 ? d = new ct(o, o.nextSibling, this, e) : s.type === 1 ? d = new s.ctor(o, s.name, s.strings, this, e) : s.type === 6 && (d = new Wa(o, this, e)), this._$AV.push(d), s = r[++l];
      }
      a !== s?.index && (o = _e.nextNode(), a++);
    }
    return _e.currentNode = $e, n;
  }
  p(e) {
    let i = 0;
    for (const r of this._$AV)
      r !== void 0 && (r.strings !== void 0 ? (r._$AI(e, r, i), i += r.strings.length - 2) : r._$AI(e[i])), i++;
  }
}
class ct {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(e, i, r, n) {
    this.type = 2, this._$AH = E, this._$AN = void 0, this._$AA = e, this._$AB = i, this._$AM = r, this.options = n, this._$Cv = n?.isConnected ?? !0;
  }
  get parentNode() {
    let e = this._$AA.parentNode;
    const i = this._$AM;
    return i !== void 0 && e?.nodeType === 11 && (e = i.parentNode), e;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(e, i = this) {
    e = ze(this, e, i), nt(e) ? e === E || e == null || e === "" ? (this._$AH !== E && this._$AR(), this._$AH = E) : e !== this._$AH && e !== ue && this._(e) : e._$litType$ !== void 0 ? this.g(e) : e.nodeType !== void 0 ? this.$(e) : Fa(e) ? this.T(e) : this._(e);
  }
  k(e) {
    return this._$AA.parentNode.insertBefore(e, this._$AB);
  }
  $(e) {
    this._$AH !== e && (this._$AR(), this._$AH = this.k(e));
  }
  _(e) {
    this._$AH !== E && nt(this._$AH) ? this._$AA.nextSibling.data = e : this.$($e.createTextNode(e)), this._$AH = e;
  }
  g(e) {
    const { values: i, _$litType$: r } = e, n = typeof r == "number" ? this._$AC(e) : (r.el === void 0 && (r.el = at.createElement(Nr(r.h, r.h[0]), this.options)), r);
    if (this._$AH?._$AD === n)
      this._$AH.p(i);
    else {
      const o = new Ua(n, this), a = o.u(this.options);
      o.p(i), this.$(a), this._$AH = o;
    }
  }
  _$AC(e) {
    let i = Yi.get(e.strings);
    return i === void 0 && Yi.set(e.strings, i = new at(e)), i;
  }
  T(e) {
    Mr(this._$AH) || (this._$AH = [], this._$AR());
    const i = this._$AH;
    let r, n = 0;
    for (const o of e)
      n === i.length ? i.push(r = new ct(this.k(rt()), this.k(rt()), this, this.options)) : r = i[n], r._$AI(o), n++;
    n < i.length && (this._$AR(r && r._$AB.nextSibling, n), i.length = n);
  }
  _$AR(e = this._$AA.nextSibling, i) {
    for (this._$AP?.(!1, !0, i); e && e !== this._$AB; ) {
      const r = e.nextSibling;
      e.remove(), e = r;
    }
  }
  setConnected(e) {
    this._$AM === void 0 && (this._$Cv = e, this._$AP?.(e));
  }
}
class Ct {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(e, i, r, n, o) {
    this.type = 1, this._$AH = E, this._$AN = void 0, this.element = e, this.name = i, this._$AM = n, this.options = o, r.length > 2 || r[0] !== "" || r[1] !== "" ? (this._$AH = Array(r.length - 1).fill(new String()), this.strings = r) : this._$AH = E;
  }
  _$AI(e, i = this, r, n) {
    const o = this.strings;
    let a = !1;
    if (o === void 0)
      e = ze(this, e, i, 0), a = !nt(e) || e !== this._$AH && e !== ue, a && (this._$AH = e);
    else {
      const l = e;
      let s, d;
      for (e = o[0], s = 0; s < o.length - 1; s++)
        d = ze(this, l[r + s], i, s), d === ue && (d = this._$AH[s]), a ||= !nt(d) || d !== this._$AH[s], d === E ? e = E : e !== E && (e += (d ?? "") + o[s + 1]), this._$AH[s] = d;
    }
    a && !n && this.j(e);
  }
  j(e) {
    e === E ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
  }
}
class Va extends Ct {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(e) {
    this.element[this.name] = e === E ? void 0 : e;
  }
}
class Ka extends Ct {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(e) {
    this.element.toggleAttribute(this.name, !!e && e !== E);
  }
}
class qa extends Ct {
  constructor(e, i, r, n, o) {
    super(e, i, r, n, o), this.type = 5;
  }
  _$AI(e, i = this) {
    if ((e = ze(this, e, i, 0) ?? E) === ue)
      return;
    const r = this._$AH, n = e === E && r !== E || e.capture !== r.capture || e.once !== r.once || e.passive !== r.passive, o = e !== E && (r === E || n);
    n && this.element.removeEventListener(this.name, this, r), o && this.element.addEventListener(this.name, this, e), this._$AH = e;
  }
  handleEvent(e) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, e) : this._$AH.handleEvent(e);
  }
}
class Wa {
  constructor(e, i, r) {
    this.element = e, this.type = 6, this._$AN = void 0, this._$AM = i, this.options = r;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(e) {
    ze(this, e);
  }
}
const Za = ci.litHtmlPolyfillSupport;
Za?.(at, ct), (ci.litHtmlVersions ??= []).push("3.0.0");
const Ya = (t, e, i) => {
  const r = i?.renderBefore ?? e;
  let n = r._$litPart$;
  if (n === void 0) {
    const o = i?.renderBefore ?? null;
    r._$litPart$ = n = new ct(e.insertBefore(rt(), o), o, void 0, i ?? {});
  }
  return n._$AI(t), n;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let we = class extends Oe {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const e = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= e.firstChild, e;
  }
  update(e) {
    const i = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(e), this._$Do = Ya(i, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return ue;
  }
};
we._$litElement$ = !0, we.finalized = !0, globalThis.litElementHydrateSupport?.({ LitElement: we });
const Ga = globalThis.litElementPolyfillSupport;
Ga?.({ LitElement: we });
(globalThis.litElementVersions ??= []).push("4.0.0");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const zr = (t) => (e, i) => {
  i !== void 0 ? i.addInitializer(() => {
    customElements.define(t, e);
  }) : customElements.define(t, e);
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Qa = { attribute: !0, type: String, converter: xt, reflect: !1, hasChanged: di }, Xa = (t = Qa, e, i) => {
  const { kind: r, metadata: n } = i;
  let o = globalThis.litPropertyMetadata.get(n);
  if (o === void 0 && globalThis.litPropertyMetadata.set(n, o = /* @__PURE__ */ new Map()), o.set(i.name, t), r === "accessor") {
    const { name: a } = i;
    return { set(l) {
      const s = e.get.call(this);
      e.set.call(this, l), this.requestUpdate(a, s, t);
    }, init(l) {
      return l !== void 0 && this.C(a, void 0, t), l;
    } };
  }
  if (r === "setter") {
    const { name: a } = i;
    return function(l) {
      const s = this[a];
      e.call(this, l), this.requestUpdate(a, s, t);
    };
  }
  throw Error("Unsupported decorator location: " + r);
};
function y(t) {
  return (e, i) => typeof i == "object" ? Xa(t, e, i) : ((r, n, o) => {
    const a = n.hasOwnProperty(o);
    return n.constructor.createProperty(o, a ? { ...r, wrapped: !0 } : r), a ? Object.getOwnPropertyDescriptor(n, o) : void 0;
  })(t, e, i);
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function W(t) {
  return y({ ...t, state: !0, attribute: !1 });
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Gi = (t, e, i) => (i.configurable = !0, i.enumerable = !0, Reflect.decorate && typeof e != "object" && Object.defineProperty(t, e, i), i);
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function Ir(t, e) {
  return (i, r, n) => {
    const o = (a) => a.renderRoot?.querySelector(t) ?? null;
    if (e) {
      const { get: a, set: l } = typeof r == "object" ? i : n ?? (() => {
        const s = Symbol();
        return { get() {
          return this[s];
        }, set(d) {
          this[s] = d;
        } };
      })();
      return Gi(i, r, { get() {
        if (e) {
          let s = a.call(this);
          return s === void 0 && (s = o(this), l.call(this, s)), s;
        }
        return o(this);
      } });
    }
    return Gi(i, r, { get() {
      return o(this);
    } });
  };
}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function Qe(t, e, i) {
  return t ? e() : i?.();
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Rr = { ATTRIBUTE: 1, CHILD: 2, PROPERTY: 3, BOOLEAN_ATTRIBUTE: 4, EVENT: 5, ELEMENT: 6 }, Dr = (t) => (...e) => ({ _$litDirective$: t, values: e });
class jr {
  constructor(e) {
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AT(e, i, r) {
    this._$Ct = e, this._$AM = i, this._$Ci = r;
  }
  _$AS(e, i) {
    return this.update(e, i);
  }
  update(e, i) {
    return this.render(...i);
  }
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let Zt = class extends jr {
  constructor(e) {
    if (super(e), this.et = E, e.type !== Rr.CHILD)
      throw Error(this.constructor.directiveName + "() can only be used in child bindings");
  }
  render(e) {
    if (e === E || e == null)
      return this.vt = void 0, this.et = e;
    if (e === ue)
      return e;
    if (typeof e != "string")
      throw Error(this.constructor.directiveName + "() called with a non-string value");
    if (e === this.et)
      return this.vt;
    this.et = e;
    const i = [e];
    return i.raw = i, this.vt = { _$litType$: this.constructor.resultType, strings: i, values: [] };
  }
};
Zt.directiveName = "unsafeHTML", Zt.resultType = 1;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
class Yt extends Zt {
}
Yt.directiveName = "unsafeSVG", Yt.resultType = 2;
const qe = Dr(Yt);
/*! typescript-cookie v1.0.6 | MIT */
const Fr = (t) => encodeURIComponent(t).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape), Br = (t) => encodeURIComponent(t).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g, decodeURIComponent), pi = decodeURIComponent, ui = (t) => (t[0] === '"' && (t = t.slice(1, -1)), t.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent));
function Ja(t) {
  return t = Object.assign({}, t), typeof t.expires == "number" && (t.expires = new Date(Date.now() + t.expires * 864e5)), t.expires != null && (t.expires = t.expires.toUTCString()), Object.entries(t).filter(([e, i]) => i != null && i !== !1).map(([e, i]) => i === !0 ? `; ${e}` : `; ${e}=${i.split(";")[0]}`).join("");
}
function Hr(t, e, i) {
  const r = /(?:^|; )([^=]*)=([^;]*)/g, n = {};
  let o;
  for (; (o = r.exec(document.cookie)) != null; )
    try {
      const a = i(o[1]);
      if (n[a] = e(o[2], a), t === a)
        break;
    } catch {
    }
  return t != null ? n[t] : n;
}
const Qi = Object.freeze({
  decodeName: pi,
  decodeValue: ui,
  encodeName: Fr,
  encodeValue: Br
}), hi = Object.freeze({
  path: "/"
});
function Ur(t, e, i = hi, { encodeValue: r = Br, encodeName: n = Fr } = {}) {
  return document.cookie = `${n(t)}=${r(e, t)}${Ja(i)}`;
}
function Vr(t, { decodeValue: e = ui, decodeName: i = pi } = {}) {
  return Hr(t, e, i);
}
function eo({ decodeValue: t = ui, decodeName: e = pi } = {}) {
  return Hr(void 0, t, e);
}
function to(t, e = hi) {
  Ur(t, "", Object.assign({}, e, {
    expires: -1
  }));
}
function Gt(t, e) {
  const i = {
    set: function(n, o, a) {
      return Ur(n, o, Object.assign({}, this.attributes, a), {
        encodeValue: this.converter.write
      });
    },
    get: function(n) {
      if (arguments.length === 0)
        return eo(this.converter.read);
      if (n != null)
        return Vr(n, this.converter.read);
    },
    remove: function(n, o) {
      to(n, Object.assign({}, this.attributes, o));
    },
    withAttributes: function(n) {
      return Gt(this.converter, Object.assign({}, this.attributes, n));
    },
    withConverter: function(n) {
      return Gt(Object.assign({}, this.converter, n), this.attributes);
    }
  }, r = {
    attributes: { value: Object.freeze(e) },
    converter: { value: Object.freeze(t) }
  };
  return Object.create(i, r);
}
Gt({ read: Qi.decodeValue, write: Qi.encodeValue }, hi);
const io = ({
  disabled: t,
  nav: e,
  validPropertyLogo: i
}) => w`
		<div class="global-header__flyout-wrapper ${i ? "hide-in-drawer" : null}">
			<epic-wf-nav-flyout-menu
				.buttonLabel=${e.navigationFlyout?.buttonLabel || ""}
				.disabled=${t}
				.sections=${e.navigationFlyout?.sections || []}
				@epic-wf-nav-flyout-toggle=${e.toggleFlyout}
				open=${e.flyoutOpen}
			>
			</epic-wf-nav-flyout-menu>
			<epic-wf-bar-icon
				aria-hidden="true"
				class="icon-wrapper ${i ? "" : "invalid-logo"}"
			></epic-wf-bar-icon>
		</div>
	`;
/*!
* tabbable 6.2.0
* @license MIT, https://github.com/focus-trap/tabbable/blob/master/LICENSE
*/
var Kr = ["input:not([inert])", "select:not([inert])", "textarea:not([inert])", "a[href]:not([inert])", "button:not([inert])", "[tabindex]:not(slot):not([inert])", "audio[controls]:not([inert])", "video[controls]:not([inert])", '[contenteditable]:not([contenteditable="false"]):not([inert])', "details>summary:first-of-type:not([inert])", "details:not([inert])"], $t = /* @__PURE__ */ Kr.join(","), qr = typeof Element > "u", Ae = qr ? function() {
} : Element.prototype.matches || Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector, At = !qr && Element.prototype.getRootNode ? function(t) {
  var e;
  return t == null || (e = t.getRootNode) === null || e === void 0 ? void 0 : e.call(t);
} : function(t) {
  return t?.ownerDocument;
}, Lt = function t(e, i) {
  var r;
  i === void 0 && (i = !0);
  var n = e == null || (r = e.getAttribute) === null || r === void 0 ? void 0 : r.call(e, "inert"), o = n === "" || n === "true", a = o || i && e && t(e.parentNode);
  return a;
}, ro = function(e) {
  var i, r = e == null || (i = e.getAttribute) === null || i === void 0 ? void 0 : i.call(e, "contenteditable");
  return r === "" || r === "true";
}, Wr = function(e, i, r) {
  if (Lt(e))
    return [];
  var n = Array.prototype.slice.apply(e.querySelectorAll($t));
  return i && Ae.call(e, $t) && n.unshift(e), n = n.filter(r), n;
}, Zr = function t(e, i, r) {
  for (var n = [], o = Array.from(e); o.length; ) {
    var a = o.shift();
    if (!Lt(a, !1))
      if (a.tagName === "SLOT") {
        var l = a.assignedElements(), s = l.length ? l : a.children, d = t(s, !0, r);
        r.flatten ? n.push.apply(n, d) : n.push({
          scopeParent: a,
          candidates: d
        });
      } else {
        var h = Ae.call(a, $t);
        h && r.filter(a) && (i || !e.includes(a)) && n.push(a);
        var u = a.shadowRoot || // check for an undisclosed shadow
        typeof r.getShadowRoot == "function" && r.getShadowRoot(a), k = !Lt(u, !1) && (!r.shadowRootFilter || r.shadowRootFilter(a));
        if (u && k) {
          var x = t(u === !0 ? a.children : u.children, !0, r);
          r.flatten ? n.push.apply(n, x) : n.push({
            scopeParent: a,
            candidates: x
          });
        } else
          o.unshift.apply(o, a.children);
      }
  }
  return n;
}, Yr = function(e) {
  return !isNaN(parseInt(e.getAttribute("tabindex"), 10));
}, ve = function(e) {
  if (!e)
    throw new Error("No node provided");
  return e.tabIndex < 0 && (/^(AUDIO|VIDEO|DETAILS)$/.test(e.tagName) || ro(e)) && !Yr(e) ? 0 : e.tabIndex;
}, no = function(e, i) {
  var r = ve(e);
  return r < 0 && i && !Yr(e) ? 0 : r;
}, ao = function(e, i) {
  return e.tabIndex === i.tabIndex ? e.documentOrder - i.documentOrder : e.tabIndex - i.tabIndex;
}, Gr = function(e) {
  return e.tagName === "INPUT";
}, oo = function(e) {
  return Gr(e) && e.type === "hidden";
}, so = function(e) {
  var i = e.tagName === "DETAILS" && Array.prototype.slice.apply(e.children).some(function(r) {
    return r.tagName === "SUMMARY";
  });
  return i;
}, lo = function(e, i) {
  for (var r = 0; r < e.length; r++)
    if (e[r].checked && e[r].form === i)
      return e[r];
}, co = function(e) {
  if (!e.name)
    return !0;
  var i = e.form || At(e), r = function(l) {
    return i.querySelectorAll('input[type="radio"][name="' + l + '"]');
  }, n;
  if (typeof window < "u" && typeof window.CSS < "u" && typeof window.CSS.escape == "function")
    n = r(window.CSS.escape(e.name));
  else
    try {
      n = r(e.name);
    } catch (a) {
      return console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s", a.message), !1;
    }
  var o = lo(n, e.form);
  return !o || o === e;
}, po = function(e) {
  return Gr(e) && e.type === "radio";
}, uo = function(e) {
  return po(e) && !co(e);
}, ho = function(e) {
  var i, r = e && At(e), n = (i = r) === null || i === void 0 ? void 0 : i.host, o = !1;
  if (r && r !== e) {
    var a, l, s;
    for (o = !!((a = n) !== null && a !== void 0 && (l = a.ownerDocument) !== null && l !== void 0 && l.contains(n) || e != null && (s = e.ownerDocument) !== null && s !== void 0 && s.contains(e)); !o && n; ) {
      var d, h, u;
      r = At(n), n = (d = r) === null || d === void 0 ? void 0 : d.host, o = !!((h = n) !== null && h !== void 0 && (u = h.ownerDocument) !== null && u !== void 0 && u.contains(n));
    }
  }
  return o;
}, Xi = function(e) {
  var i = e.getBoundingClientRect(), r = i.width, n = i.height;
  return r === 0 && n === 0;
}, fo = function(e, i) {
  var r = i.displayCheck, n = i.getShadowRoot;
  if (getComputedStyle(e).visibility === "hidden")
    return !0;
  var o = Ae.call(e, "details>summary:first-of-type"), a = o ? e.parentElement : e;
  if (Ae.call(a, "details:not([open]) *"))
    return !0;
  if (!r || r === "full" || r === "legacy-full") {
    if (typeof n == "function") {
      for (var l = e; e; ) {
        var s = e.parentElement, d = At(e);
        if (s && !s.shadowRoot && n(s) === !0)
          return Xi(e);
        e.assignedSlot ? e = e.assignedSlot : !s && d !== e.ownerDocument ? e = d.host : e = s;
      }
      e = l;
    }
    if (ho(e))
      return !e.getClientRects().length;
    if (r !== "legacy-full")
      return !0;
  } else if (r === "non-zero-area")
    return Xi(e);
  return !1;
}, mo = function(e) {
  if (/^(INPUT|BUTTON|SELECT|TEXTAREA)$/.test(e.tagName))
    for (var i = e.parentElement; i; ) {
      if (i.tagName === "FIELDSET" && i.disabled) {
        for (var r = 0; r < i.children.length; r++) {
          var n = i.children.item(r);
          if (n.tagName === "LEGEND")
            return Ae.call(i, "fieldset[disabled] *") ? !0 : !n.contains(e);
        }
        return !0;
      }
      i = i.parentElement;
    }
  return !1;
}, St = function(e, i) {
  return !(i.disabled || // we must do an inert look up to filter out any elements inside an inert ancestor
  //  because we're limited in the type of selectors we can use in JSDom (see related
  //  note related to `candidateSelectors`)
  Lt(i) || oo(i) || fo(i, e) || // For a details element with a summary, the summary element gets the focus
  so(i) || mo(i));
}, Qt = function(e, i) {
  return !(uo(i) || ve(i) < 0 || !St(e, i));
}, go = function(e) {
  var i = parseInt(e.getAttribute("tabindex"), 10);
  return !!(isNaN(i) || i >= 0);
}, vo = function t(e) {
  var i = [], r = [];
  return e.forEach(function(n, o) {
    var a = !!n.scopeParent, l = a ? n.scopeParent : n, s = no(l, a), d = a ? t(n.candidates) : l;
    s === 0 ? a ? i.push.apply(i, d) : i.push(l) : r.push({
      documentOrder: o,
      tabIndex: s,
      item: n,
      isScope: a,
      content: d
    });
  }), r.sort(ao).reduce(function(n, o) {
    return o.isScope ? n.push.apply(n, o.content) : n.push(o.content), n;
  }, []).concat(i);
}, bo = function(e, i) {
  i = i || {};
  var r;
  return i.getShadowRoot ? r = Zr([e], i.includeContainer, {
    filter: Qt.bind(null, i),
    flatten: !1,
    getShadowRoot: i.getShadowRoot,
    shadowRootFilter: go
  }) : r = Wr(e, i.includeContainer, Qt.bind(null, i)), vo(r);
}, _o = function(e, i) {
  i = i || {};
  var r;
  return i.getShadowRoot ? r = Zr([e], i.includeContainer, {
    filter: St.bind(null, i),
    flatten: !0,
    getShadowRoot: i.getShadowRoot
  }) : r = Wr(e, i.includeContainer, St.bind(null, i)), r;
}, Ee = function(e, i) {
  if (i = i || {}, !e)
    throw new Error("No node provided");
  return Ae.call(e, $t) === !1 ? !1 : Qt(i, e);
}, yo = /* @__PURE__ */ Kr.concat("iframe").join(","), jt = function(e, i) {
  if (i = i || {}, !e)
    throw new Error("No node provided");
  return Ae.call(e, yo) === !1 ? !1 : St(i, e);
};
/*!
* focus-trap 7.5.2
* @license MIT, https://github.com/focus-trap/focus-trap/blob/master/LICENSE
*/
function Ji(t, e) {
  var i = Object.keys(t);
  if (Object.getOwnPropertySymbols) {
    var r = Object.getOwnPropertySymbols(t);
    e && (r = r.filter(function(n) {
      return Object.getOwnPropertyDescriptor(t, n).enumerable;
    })), i.push.apply(i, r);
  }
  return i;
}
function er(t) {
  for (var e = 1; e < arguments.length; e++) {
    var i = arguments[e] != null ? arguments[e] : {};
    e % 2 ? Ji(Object(i), !0).forEach(function(r) {
      wo(t, r, i[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : Ji(Object(i)).forEach(function(r) {
      Object.defineProperty(t, r, Object.getOwnPropertyDescriptor(i, r));
    });
  }
  return t;
}
function wo(t, e, i) {
  return e = ko(e), e in t ? Object.defineProperty(t, e, {
    value: i,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : t[e] = i, t;
}
function xo(t, e) {
  if (typeof t != "object" || t === null)
    return t;
  var i = t[Symbol.toPrimitive];
  if (i !== void 0) {
    var r = i.call(t, e || "default");
    if (typeof r != "object")
      return r;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(t);
}
function ko(t) {
  var e = xo(t, "string");
  return typeof e == "symbol" ? e : String(e);
}
var tr = {
  activateTrap: function(e, i) {
    if (e.length > 0) {
      var r = e[e.length - 1];
      r !== i && r.pause();
    }
    var n = e.indexOf(i);
    n === -1 || e.splice(n, 1), e.push(i);
  },
  deactivateTrap: function(e, i) {
    var r = e.indexOf(i);
    r !== -1 && e.splice(r, 1), e.length > 0 && e[e.length - 1].unpause();
  }
}, $o = function(e) {
  return e.tagName && e.tagName.toLowerCase() === "input" && typeof e.select == "function";
}, Ao = function(e) {
  return e?.key === "Escape" || e?.key === "Esc" || e?.keyCode === 27;
}, Xe = function(e) {
  return e?.key === "Tab" || e?.keyCode === 9;
}, Lo = function(e) {
  return Xe(e) && !e.shiftKey;
}, So = function(e) {
  return Xe(e) && e.shiftKey;
}, ir = function(e) {
  return setTimeout(e, 0);
}, rr = function(e, i) {
  var r = -1;
  return e.every(function(n, o) {
    return i(n) ? (r = o, !1) : !0;
  }), r;
}, Ve = function(e) {
  for (var i = arguments.length, r = new Array(i > 1 ? i - 1 : 0), n = 1; n < i; n++)
    r[n - 1] = arguments[n];
  return typeof e == "function" ? e.apply(void 0, r) : e;
}, ut = function(e) {
  return e.target.shadowRoot && typeof e.composedPath == "function" ? e.composedPath()[0] : e.target;
}, Eo = [], To = function(e, i) {
  var r = i?.document || document, n = i?.trapStack || Eo, o = er({
    returnFocusOnDeactivate: !0,
    escapeDeactivates: !0,
    delayInitialFocus: !0,
    isKeyForward: Lo,
    isKeyBackward: So
  }, i), a = {
    // containers given to createFocusTrap()
    // @type {Array<HTMLElement>}
    containers: [],
    // list of objects identifying tabbable nodes in `containers` in the trap
    // NOTE: it's possible that a group has no tabbable nodes if nodes get removed while the trap
    //  is active, but the trap should never get to a state where there isn't at least one group
    //  with at least one tabbable node in it (that would lead to an error condition that would
    //  result in an error being thrown)
    // @type {Array<{
    //   container: HTMLElement,
    //   tabbableNodes: Array<HTMLElement>, // empty if none
    //   focusableNodes: Array<HTMLElement>, // empty if none
    //   posTabIndexesFound: boolean,
    //   firstTabbableNode: HTMLElement|undefined,
    //   lastTabbableNode: HTMLElement|undefined,
    //   firstDomTabbableNode: HTMLElement|undefined,
    //   lastDomTabbableNode: HTMLElement|undefined,
    //   nextTabbableNode: (node: HTMLElement, forward: boolean) => HTMLElement|undefined
    // }>}
    containerGroups: [],
    // same order/length as `containers` list
    // references to objects in `containerGroups`, but only those that actually have
    //  tabbable nodes in them
    // NOTE: same order as `containers` and `containerGroups`, but __not necessarily__
    //  the same length
    tabbableGroups: [],
    nodeFocusedBeforeActivation: null,
    mostRecentlyFocusedNode: null,
    active: !1,
    paused: !1,
    // timer ID for when delayInitialFocus is true and initial focus in this trap
    //  has been delayed during activation
    delayInitialFocusTimer: void 0,
    // the most recent KeyboardEvent for the configured nav key (typically [SHIFT+]TAB), if any
    recentNavEvent: void 0
  }, l, s = function(c, p, g) {
    return c && c[p] !== void 0 ? c[p] : o[g || p];
  }, d = function(c, p) {
    var g = typeof p?.composedPath == "function" ? p.composedPath() : void 0;
    return a.containerGroups.findIndex(function($) {
      var A = $.container, S = $.tabbableNodes;
      return A.contains(c) || g?.includes(A) || S.find(function(C) {
        return C === c;
      });
    });
  }, h = function(c) {
    var p = o[c];
    if (typeof p == "function") {
      for (var g = arguments.length, $ = new Array(g > 1 ? g - 1 : 0), A = 1; A < g; A++)
        $[A - 1] = arguments[A];
      p = p.apply(void 0, $);
    }
    if (p === !0 && (p = void 0), !p) {
      if (p === void 0 || p === !1)
        return p;
      throw new Error("`".concat(c, "` was specified but was not a node, or did not return a node"));
    }
    var S = p;
    if (typeof p == "string" && (S = r.querySelector(p), !S))
      throw new Error("`".concat(c, "` as selector refers to no known node"));
    return S;
  }, u = function() {
    var c = h("initialFocus");
    if (c === !1)
      return !1;
    if (c === void 0 || !jt(c, o.tabbableOptions))
      if (d(r.activeElement) >= 0)
        c = r.activeElement;
      else {
        var p = a.tabbableGroups[0], g = p && p.firstTabbableNode;
        c = g || h("fallbackFocus");
      }
    if (!c)
      throw new Error("Your focus-trap needs to have at least one focusable element");
    return c;
  }, k = function() {
    if (a.containerGroups = a.containers.map(function(c) {
      var p = bo(c, o.tabbableOptions), g = _o(c, o.tabbableOptions), $ = p.length > 0 ? p[0] : void 0, A = p.length > 0 ? p[p.length - 1] : void 0, S = g.find(function(P) {
        return Ee(P);
      }), C = g.slice().reverse().find(function(P) {
        return Ee(P);
      }), I = !!p.find(function(P) {
        return ve(P) > 0;
      });
      return {
        container: c,
        tabbableNodes: p,
        focusableNodes: g,
        /** True if at least one node with positive `tabindex` was found in this container. */
        posTabIndexesFound: I,
        /** First tabbable node in container, __tabindex__ order; `undefined` if none. */
        firstTabbableNode: $,
        /** Last tabbable node in container, __tabindex__ order; `undefined` if none. */
        lastTabbableNode: A,
        // NOTE: DOM order is NOT NECESSARILY "document position" order, but figuring that out
        //  would require more than just https://developer.mozilla.org/en-US/docs/Web/API/Node/compareDocumentPosition
        //  because that API doesn't work with Shadow DOM as well as it should (@see
        //  https://github.com/whatwg/dom/issues/320) and since this first/last is only needed, so far,
        //  to address an edge case related to positive tabindex support, this seems like a much easier,
        //  "close enough most of the time" alternative for positive tabindexes which should generally
        //  be avoided anyway...
        /** First tabbable node in container, __DOM__ order; `undefined` if none. */
        firstDomTabbableNode: S,
        /** Last tabbable node in container, __DOM__ order; `undefined` if none. */
        lastDomTabbableNode: C,
        /**
         * Finds the __tabbable__ node that follows the given node in the specified direction,
         *  in this container, if any.
         * @param {HTMLElement} node
         * @param {boolean} [forward] True if going in forward tab order; false if going
         *  in reverse.
         * @returns {HTMLElement|undefined} The next tabbable node, if any.
         */
        nextTabbableNode: function(fe) {
          var je = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0, ne = p.indexOf(fe);
          return ne < 0 ? je ? g.slice(g.indexOf(fe) + 1).find(function(Fe) {
            return Ee(Fe);
          }) : g.slice(0, g.indexOf(fe)).reverse().find(function(Fe) {
            return Ee(Fe);
          }) : p[ne + (je ? 1 : -1)];
        }
      };
    }), a.tabbableGroups = a.containerGroups.filter(function(c) {
      return c.tabbableNodes.length > 0;
    }), a.tabbableGroups.length <= 0 && !h("fallbackFocus"))
      throw new Error("Your focus-trap must have at least one container with at least one tabbable node in it at all times");
    if (a.containerGroups.find(function(c) {
      return c.posTabIndexesFound;
    }) && a.containerGroups.length > 1)
      throw new Error("At least one node with a positive tabindex was found in one of your focus-trap's multiple containers. Positive tabindexes are only supported in single-container focus-traps.");
  }, x = function L(c) {
    if (c !== !1 && c !== r.activeElement) {
      if (!c || !c.focus) {
        L(u());
        return;
      }
      c.focus({
        preventScroll: !!o.preventScroll
      }), a.mostRecentlyFocusedNode = c, $o(c) && c.select();
    }
  }, V = function(c) {
    var p = h("setReturnFocus", c);
    return p || (p === !1 ? !1 : c);
  }, mi = function(c) {
    var p = c.target, g = c.event, $ = c.isBackward, A = $ === void 0 ? !1 : $;
    p = p || ut(g), k();
    var S = null;
    if (a.tabbableGroups.length > 0) {
      var C = d(p, g), I = C >= 0 ? a.containerGroups[C] : void 0;
      if (C < 0)
        A ? S = a.tabbableGroups[a.tabbableGroups.length - 1].lastTabbableNode : S = a.tabbableGroups[0].firstTabbableNode;
      else if (A) {
        var P = rr(a.tabbableGroups, function(Pt) {
          var Nt = Pt.firstTabbableNode;
          return p === Nt;
        });
        if (P < 0 && (I.container === p || jt(p, o.tabbableOptions) && !Ee(p, o.tabbableOptions) && !I.nextTabbableNode(p, !1)) && (P = C), P >= 0) {
          var fe = P === 0 ? a.tabbableGroups.length - 1 : P - 1, je = a.tabbableGroups[fe];
          S = ve(p) >= 0 ? je.lastTabbableNode : je.lastDomTabbableNode;
        } else
          Xe(g) || (S = I.nextTabbableNode(p, !1));
      } else {
        var ne = rr(a.tabbableGroups, function(Pt) {
          var Nt = Pt.lastTabbableNode;
          return p === Nt;
        });
        if (ne < 0 && (I.container === p || jt(p, o.tabbableOptions) && !Ee(p, o.tabbableOptions) && !I.nextTabbableNode(p)) && (ne = C), ne >= 0) {
          var Fe = ne === a.tabbableGroups.length - 1 ? 0 : ne + 1, wi = a.tabbableGroups[Fe];
          S = ve(p) >= 0 ? wi.firstTabbableNode : wi.firstDomTabbableNode;
        } else
          Xe(g) || (S = I.nextTabbableNode(p));
      }
    } else
      S = h("fallbackFocus");
    return S;
  }, pt = function(c) {
    var p = ut(c);
    if (!(d(p, c) >= 0)) {
      if (Ve(o.clickOutsideDeactivates, c)) {
        l.deactivate({
          // NOTE: by setting `returnFocus: false`, deactivate() will do nothing,
          //  which will result in the outside click setting focus to the node
          //  that was clicked (and if not focusable, to "nothing"); by setting
          //  `returnFocus: true`, we'll attempt to re-focus the node originally-focused
          //  on activation (or the configured `setReturnFocus` node), whether the
          //  outside click was on a focusable node or not
          returnFocus: o.returnFocusOnDeactivate
        });
        return;
      }
      Ve(o.allowOutsideClick, c) || c.preventDefault();
    }
  }, gi = function(c) {
    var p = ut(c), g = d(p, c) >= 0;
    if (g || p instanceof Document)
      g && (a.mostRecentlyFocusedNode = p);
    else {
      c.stopImmediatePropagation();
      var $, A = !0;
      if (a.mostRecentlyFocusedNode)
        if (ve(a.mostRecentlyFocusedNode) > 0) {
          var S = d(a.mostRecentlyFocusedNode), C = a.containerGroups[S].tabbableNodes;
          if (C.length > 0) {
            var I = C.findIndex(function(P) {
              return P === a.mostRecentlyFocusedNode;
            });
            I >= 0 && (o.isKeyForward(a.recentNavEvent) ? I + 1 < C.length && ($ = C[I + 1], A = !1) : I - 1 >= 0 && ($ = C[I - 1], A = !1));
          }
        } else
          a.containerGroups.some(function(P) {
            return P.tabbableNodes.some(function(fe) {
              return ve(fe) > 0;
            });
          }) || (A = !1);
      else
        A = !1;
      A && ($ = mi({
        // move FROM the MRU node, not event-related node (which will be the node that is
        //  outside the trap causing the focus escape we're trying to fix)
        target: a.mostRecentlyFocusedNode,
        isBackward: o.isKeyBackward(a.recentNavEvent)
      })), x($ || a.mostRecentlyFocusedNode || u());
    }
    a.recentNavEvent = void 0;
  }, tn = function(c) {
    var p = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    a.recentNavEvent = c;
    var g = mi({
      event: c,
      isBackward: p
    });
    g && (Xe(c) && c.preventDefault(), x(g));
  }, vi = function(c) {
    if (Ao(c) && Ve(o.escapeDeactivates, c) !== !1) {
      c.preventDefault(), l.deactivate();
      return;
    }
    (o.isKeyForward(c) || o.isKeyBackward(c)) && tn(c, o.isKeyBackward(c));
  }, bi = function(c) {
    var p = ut(c);
    d(p, c) >= 0 || Ve(o.clickOutsideDeactivates, c) || Ve(o.allowOutsideClick, c) || (c.preventDefault(), c.stopImmediatePropagation());
  }, _i = function() {
    if (a.active)
      return tr.activateTrap(n, l), a.delayInitialFocusTimer = o.delayInitialFocus ? ir(function() {
        x(u());
      }) : x(u()), r.addEventListener("focusin", gi, !0), r.addEventListener("mousedown", pt, {
        capture: !0,
        passive: !1
      }), r.addEventListener("touchstart", pt, {
        capture: !0,
        passive: !1
      }), r.addEventListener("click", bi, {
        capture: !0,
        passive: !1
      }), r.addEventListener("keydown", vi, {
        capture: !0,
        passive: !1
      }), l;
  }, yi = function() {
    if (a.active)
      return r.removeEventListener("focusin", gi, !0), r.removeEventListener("mousedown", pt, !0), r.removeEventListener("touchstart", pt, !0), r.removeEventListener("click", bi, !0), r.removeEventListener("keydown", vi, !0), l;
  }, rn = function(c) {
    var p = c.some(function(g) {
      var $ = Array.from(g.removedNodes);
      return $.some(function(A) {
        return A === a.mostRecentlyFocusedNode;
      });
    });
    p && x(u());
  }, Mt = typeof window < "u" && "MutationObserver" in window ? new MutationObserver(rn) : void 0, De = function() {
    Mt && (Mt.disconnect(), a.active && !a.paused && a.containers.map(function(c) {
      Mt.observe(c, {
        subtree: !0,
        childList: !0
      });
    }));
  };
  return l = {
    get active() {
      return a.active;
    },
    get paused() {
      return a.paused;
    },
    activate: function(c) {
      if (a.active)
        return this;
      var p = s(c, "onActivate"), g = s(c, "onPostActivate"), $ = s(c, "checkCanFocusTrap");
      $ || k(), a.active = !0, a.paused = !1, a.nodeFocusedBeforeActivation = r.activeElement, p?.();
      var A = function() {
        $ && k(), _i(), De(), g?.();
      };
      return $ ? ($(a.containers.concat()).then(A, A), this) : (A(), this);
    },
    deactivate: function(c) {
      if (!a.active)
        return this;
      var p = er({
        onDeactivate: o.onDeactivate,
        onPostDeactivate: o.onPostDeactivate,
        checkCanReturnFocus: o.checkCanReturnFocus
      }, c);
      clearTimeout(a.delayInitialFocusTimer), a.delayInitialFocusTimer = void 0, yi(), a.active = !1, a.paused = !1, De(), tr.deactivateTrap(n, l);
      var g = s(p, "onDeactivate"), $ = s(p, "onPostDeactivate"), A = s(p, "checkCanReturnFocus"), S = s(p, "returnFocus", "returnFocusOnDeactivate");
      g?.();
      var C = function() {
        ir(function() {
          S && x(V(a.nodeFocusedBeforeActivation)), $?.();
        });
      };
      return S && A ? (A(V(a.nodeFocusedBeforeActivation)).then(C, C), this) : (C(), this);
    },
    pause: function(c) {
      if (a.paused || !a.active)
        return this;
      var p = s(c, "onPause"), g = s(c, "onPostPause");
      return a.paused = !0, p?.(), yi(), De(), g?.(), this;
    },
    unpause: function(c) {
      if (!a.paused || !a.active)
        return this;
      var p = s(c, "onUnpause"), g = s(c, "onPostUnpause");
      return a.paused = !1, p?.(), k(), _i(), De(), g?.(), this;
    },
    updateContainerElements: function(c) {
      var p = [].concat(c).filter(Boolean);
      return a.containers = p.map(function(g) {
        return typeof g == "string" ? r.querySelector(g) : g;
      }), a.active && k(), De(), this;
    }
  }, l.updateContainerElements(e), l;
};
function ot(t) {
  return t.nextElementSibling;
}
function Xt(t) {
  return t.shadowRoot?.querySelector(".main-link");
}
function Me(t) {
  return t;
}
class st {
  static waitForDisplay(e, i) {
    e.style.getPropertyValue("display") !== "none" ? i() : new ResizeObserver((o, a) => {
      for (const l of o)
        l.target === e && e.style.display !== "none" && (i(), a.disconnect());
    }).observe(e);
  }
  trapFocusIn(e, i) {
    if (!e) {
      console.debug("Focus trpping empty container");
      return;
    }
    const { returnFocusTo: r, fallbackFocus: n, onDeactivate: o, onEscapeDeactivates: a } = i;
    if (this._returnFocusTo = r, this._onDeactivate = o, this._onEscapeDeactivates = a, this._globalFocusTrap)
      st.waitForDisplay(e, () => {
        this._globalFocusTrap && (this._globalFocusTrap.updateContainerElements(e), this._globalFocusTrap.activate());
      });
    else {
      const l = {
        onDeactivate: () => {
          this._onDeactivate && this._onDeactivate();
        },
        clickOutsideDeactivates: !0,
        fallbackFocus: () => n,
        tabbableOptions: {
          getShadowRoot: !0
        },
        escapeDeactivates: (s) => (this._onEscapeDeactivates && this._onEscapeDeactivates(s), !0),
        isKeyForward: (s) => s.key === "ArrowDown" || s.key === "Tab",
        isKeyBackward: (s) => s.key === "ArrowUp" || s.shiftKey && s.key === "Tab"
      };
      l.setReturnFocus = (s) => this._returnFocusTo ? this._returnFocusTo : !1, l.checkCanFocusTrap = (s) => new Promise((d) => {
        st.waitForDisplay(s[0], d);
      });
      try {
        this._globalFocusTrap = To(e, l), this._globalFocusTrap.activate();
      } catch (s) {
        console.debug(s);
      }
    }
  }
  untrapFocus() {
    this._globalFocusTrap && this._globalFocusTrap.deactivate();
  }
  get active() {
    return this._globalFocusTrap ? this._globalFocusTrap.active : !1;
  }
}
function Co(t, e, i, r) {
  e ? t.type === "click" ? r._trapSubFocus(
    t,
    ot,
    Me,
    t.target,
    () => r._untrapSubFocus(),
    (n) => {
      n.preventDefault(), n.stopImmediatePropagation(), i();
    }
  ) : r._isSubFocusTrapped && r._untrapSubFocus() : r._untrapSubFocus();
}
const Oo = (t, e, i) => {
  const r = (a) => {
    const l = t.moreOpened;
    t.closeMenusAndInput(), t.moreOpened = !l, t.moreOpened ? t._trapFocus(a, ot, Xt, () => {
    }) : t._untrapFocus();
  };
  return w`
		<li
			@pointerenter=${(a) => {
    ye(a) || (t.closeMenusAndInput(), t.moreOpened = !0);
  }}
			@pointerleave=${(a) => {
    ye(a) || (t._untrapFocus(), t.moreOpened = !1);
  }}
			class="main-nav__list-item main-nav__list-item--condensed"
		>
			<epic-wf-main-link
				.rtl=${t.dir === B.RTL}
				@click=${r}
				active=${t.moreOpened}
				forceActiveStyle=${t.activeMainLinkIndex === -1 && i}
				hasMenu=${!0}
				label=${t?.largeCondensedLabel || ""}
				domain=${t?.domain || ""}
				locale=${t.getMappedHygraphLocale(t.locale)}
			>
				<div class="friendly-box friendly-box--wide"></div>
			</epic-wf-main-link>
			<epic-wf-condensed-menu
				.getMappedHygraphLocale=${t.getMappedHygraphLocale.bind(t)}
				.mainLinks=${e || []}
				.onLinkClick=${t._navLinkClick.bind(t)}
				.onSubmenu=${(a, l, s) => Co(a, l, s, t)}
				.rtl=${t.dir === B.RTL}
				domain=${t?.domain || ""}
				locale=${t.getMappedHygraphLocale(t.locale)}
			></epic-wf-condensed-menu>
		</li>
	`;
}, Qr = (t) => {
  try {
    return window && window.location && window.location.href ? new URL(window.location.href) : new URL(t);
  } catch (e) {
    return console.warn("getCurrentUrl() Failed to parse current URL", e), null;
  }
}, Mo = (t, e) => t?.search ? t.search.substring(1).split("&").filter((r) => {
  const n = r.split("="), o = e ? !e.includes(n[0]) : !0;
  return n[0] !== "lang" && o;
}) : [], Po = (t, e, i) => {
  const r = [...e];
  return t && r.push(...Mo(t, i)), r.length > 0 ? `?${r.join("&")}` : "";
}, Ke = (t, e) => {
  if (!t || !e)
    return !1;
  let i = null;
  try {
    e.indexOf("http") === 0 ? i = new URL(e) : e.indexOf("/") === 0 && (i = new URL(`${t.origin}${e}`));
  } catch (r) {
    return console.warn("isRoughlyEqual() Failed to parse the href and compare to current URL", r), !1;
  }
  return !!(t && i && t.origin === i.origin && t.pathname === i.pathname);
}, nr = (t, e, i) => {
  const r = Qr(t);
  if (i.hrefTemplate) {
    const n = z({
      domain: t,
      locale: e,
      hrefTemplate: i.hrefTemplate
    });
    if (n && Ke(r, n))
      return !0;
  }
  if (i?.menu?.__typename === "NavSimpleMenu" && i.menu?.links?.length)
    for (let n = 0; n < i.menu.links.length; n++) {
      const o = i.menu.links[n], a = z({
        domain: t,
        locale: e,
        hrefTemplate: o.hrefTemplate
      });
      if (Ke(r, a))
        return !0;
    }
  if (i?.menu?.__typename === "NavSubnavMenu" && i.menu?.links?.length) {
    for (let n = 0; n < i.menu.links.length; n++) {
      const o = i.menu.links[n], a = z({
        domain: t,
        locale: e,
        hrefTemplate: o.hrefTemplate
      });
      if (Ke(r, a))
        return !0;
    }
    for (let n = 0; n < i.menu.descLinks.length; n++) {
      const o = i.menu.descLinks[n], a = z({
        domain: t,
        locale: e,
        hrefTemplate: o.hrefTemplate
      });
      if (Ke(r, a))
        return !0;
    }
    for (let n = 0; n < i.menu.cardLinks.length; n++) {
      const o = i.menu.cardLinks[n], a = z({
        domain: t,
        locale: e,
        hrefTemplate: o.hrefTemplate
      });
      if (Ke(r, a))
        return !0;
    }
  }
  return !1;
};
function J(t, e, i, r) {
  var n = arguments.length, o = n < 3 ? e : r === null ? r = Object.getOwnPropertyDescriptor(e, i) : r, a;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function")
    o = Reflect.decorate(t, e, i, r);
  else
    for (var l = t.length - 1; l >= 0; l--)
      (a = t[l]) && (o = (n < 3 ? a(o) : n > 3 ? a(e, i, o) : a(e, i)) || o);
  return n > 3 && o && Object.defineProperty(e, i, o), o;
}
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const No = Dr(class extends jr {
  constructor(t) {
    if (super(t), t.type !== Rr.ATTRIBUTE || t.name !== "class" || t.strings?.length > 2)
      throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.");
  }
  render(t) {
    return " " + Object.keys(t).filter((e) => t[e]).join(" ") + " ";
  }
  update(t, [e]) {
    if (this.it === void 0) {
      this.it = /* @__PURE__ */ new Set(), t.strings !== void 0 && (this.st = new Set(t.strings.join(" ").split(/\s/).filter((r) => r !== "")));
      for (const r in e)
        e[r] && !this.st?.has(r) && this.it.add(r);
      return this.render(e);
    }
    const i = t.element.classList;
    for (const r of this.it)
      r in e || (i.remove(r), this.it.delete(r));
    for (const r in e) {
      const n = !!e[r];
      n === this.it.has(r) || this.st?.has(r) || (n ? (i.add(r), this.it.add(r)) : (i.remove(r), this.it.delete(r)));
    }
    return ue;
  }
});
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Xr = Symbol.for(""), zo = (t) => {
  if (t?.r === Xr)
    return t?._$litStatic$;
}, Ft = (t, ...e) => ({ _$litStatic$: e.reduce((i, r, n) => i + ((o) => {
  if (o._$litStatic$ !== void 0)
    return o._$litStatic$;
  throw Error(`Value passed to 'literal' function must be a 'literal' result: ${o}. Use 'unsafeStatic' to pass non-literal values, but
            take care to ensure page security.`);
})(r) + t[n + 1], t[0]), r: Xr }), ar = /* @__PURE__ */ new Map(), Io = (t) => (e, ...i) => {
  const r = i.length;
  let n, o;
  const a = [], l = [];
  let s, d = 0, h = !1;
  for (; d < r; ) {
    for (s = e[d]; d < r && (o = i[d], (n = zo(o)) !== void 0); )
      s += n + e[++d], h = !0;
    d !== r && l.push(o), a.push(s), d++;
  }
  if (d === r && a.push(e[r]), h) {
    const u = a.join("$$lit$$");
    (e = ar.get(u)) === void 0 && (a.raw = a, ar.set(u, e = a)), i = l;
  }
  return t(e, ...i);
}, ht = Io(w);
function Ro(t, e) {
  if (typeof t != "object" || t === null)
    return t;
  var i = t[Symbol.toPrimitive];
  if (i !== void 0) {
    var r = i.call(t, e || "default");
    if (typeof r != "object")
      return r;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(t);
}
function Do(t) {
  var e = Ro(t, "string");
  return typeof e == "symbol" ? e : String(e);
}
function jo(t, e, i) {
  return e = Do(e), e in t ? Object.defineProperty(t, e, {
    value: i,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : t[e] = i, t;
}
function or(t, e) {
  var i = Object.keys(t);
  if (Object.getOwnPropertySymbols) {
    var r = Object.getOwnPropertySymbols(t);
    e && (r = r.filter(function(n) {
      return Object.getOwnPropertyDescriptor(t, n).enumerable;
    })), i.push.apply(i, r);
  }
  return i;
}
function sr(t) {
  for (var e = 1; e < arguments.length; e++) {
    var i = arguments[e] != null ? arguments[e] : {};
    e % 2 ? or(Object(i), !0).forEach(function(r) {
      jo(t, r, i[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : or(Object(i)).forEach(function(r) {
      Object.defineProperty(t, r, Object.getOwnPropertyDescriptor(i, r));
    });
  }
  return t;
}
function lr(t, e) {
  var i = {};
  for (var r in t)
    i[r] = e(t[r], r);
  return i;
}
var Fo = (t, e, i) => {
  for (var r of Object.keys(t)) {
    var n;
    if (t[r] !== ((n = e[r]) !== null && n !== void 0 ? n : i[r]))
      return !1;
  }
  return !0;
}, Ot = (t) => {
  var e = (i) => {
    var r = t.defaultClassName, n = sr(sr({}, t.defaultVariants), i);
    for (var o in n) {
      var a, l = (a = n[o]) !== null && a !== void 0 ? a : t.defaultVariants[o];
      if (l != null) {
        var s = l;
        typeof s == "boolean" && (s = s === !0 ? "true" : "false");
        var d = (
          // @ts-expect-error
          t.variantClassNames[o][s]
        );
        d && (r += " " + d);
      }
    }
    for (var [h, u] of t.compoundVariants)
      Fo(h, n, t.defaultVariants) && (r += " " + u);
    return r;
  };
  return e.variants = () => Object.keys(t.variantClassNames), e.classNames = {
    get base() {
      return t.defaultClassName.split(" ")[0];
    },
    get variants() {
      return lr(t.variantClassNames, (i) => lr(i, (r) => r.split(" ")[0]));
    }
  }, e;
}, Bo = ".eds_xd1k8g0{--eds_xd1k8g1:750ms;--eds_xd1k8g2:1000ms;--eds_xd1k8g3:cubic-bezier(0,0,1,1);--eds_xd1k8g4:cubic-bezier(0.45,0,0.55,1);--eds_xd1k8g5:rgba(0,0,0,0.7);--eds_xd1k8g6:#303034;--eds_xd1k8g7:#101014;--eds_xd1k8g8:#18181c;--eds_xd1k8g9:#202024;--eds_xd1k8ga:#404044;--eds_xd1k8gb:#202024;--eds_xd1k8gc:#28282c;--eds_xd1k8gd:#ffffff;--eds_xd1k8ge:#707074;--eds_xd1k8gf:#808084;--eds_xd1k8gg:#e6e6ea;--eds_xd1k8gh:#303034;--eds_xd1k8gi:#ff3f56;--eds_xd1k8gj:#ff6173;--eds_xd1k8gk:#707074;--eds_xd1k8gl:#aaaaae;--eds_xd1k8gm:#707074;--eds_xd1k8gn:#202024;--eds_xd1k8go:#26bbff;--eds_xd1k8gp:#61cdff;--eds_xd1k8gq:#26bbff;--eds_xd1k8gr:#303034;--eds_xd1k8gs:#404044;--eds_xd1k8gt:#606064;--eds_xd1k8gu:#404044;--eds_xd1k8gv:#606064;--eds_xd1k8gw:#707074;--eds_xd1k8gx:#303034;--eds_xd1k8gy:#e6e6ea;--eds_xd1k8gz:#101014;--eds_xd1k8g10:#101014;--eds_xd1k8g11:rgba(0,0,0,0);--eds_xd1k8g12:#404044;--eds_xd1k8g13:#505054;--eds_xd1k8g14:#28282c;--eds_xd1k8g15:rgba(0,0,0,0);--eds_xd1k8g16:#303034;--eds_xd1k8g17:rgba(0,0,0,0);--eds_xd1k8g18:#45c761;--eds_xd1k8g19:#ffc229;--eds_xd1k8g1a:#ff3f56;--eds_xd1k8g1b:#ff6173;--eds_xd1k8g1c:#ff3f56;--eds_xd1k8g1d:#707074;--eds_xd1k8g1e:rgba(0,0,0,0);--eds_xd1k8g1f:#e6e6ea;--eds_xd1k8g1g:#aaaaae;--eds_xd1k8g1h:#aaaaae;--eds_xd1k8g1i:#101014;--eds_xd1k8g1j:#26bbff;--eds_xd1k8g1k:#61cdff;--eds_xd1k8g1l:#e6e6ea;--eds_xd1k8g1m:#ffffff;--eds_xd1k8g1n:#26bbff;--eds_xd1k8g1o:#61cdff;--eds_xd1k8g1p:#45c761;--eds_xd1k8g1q:#ffc229;--eds_xd1k8g1r:#ff6173;--eds_xd1k8g1s:#101014;--eds_xd1k8g1t:#ffffff;--eds_xd1k8g1u:#ffffff;--eds_xd1k8g1v:#000000;--eds_xd1k8g1w:#101014;--eds_xd1k8g1x:#18181c;--eds_xd1k8g1y:#202024;--eds_xd1k8g1z:#28282c;--eds_xd1k8g20:#303034;--eds_xd1k8g21:#404044;--eds_xd1k8g22:#505054;--eds_xd1k8g23:#606064;--eds_xd1k8g24:#707074;--eds_xd1k8g25:#808084;--eds_xd1k8g26:#aaaaae;--eds_xd1k8g27:#e6e6ea;--eds_xd1k8g28:#26bbff;--eds_xd1k8g29:#61cdff;--eds_xd1k8g2a:#a9d34f;--eds_xd1k8g2b:#bfde7c;--eds_xd1k8g2c:#ffc229;--eds_xd1k8g2d:#ffd15c;--eds_xd1k8g2e:#ff3f56;--eds_xd1k8g2f:#ff6173;--eds_xd1k8g2g:#fe54ba;--eds_xd1k8g2h:#fe73c7;--eds_xd1k8g2i:#be3dff;--eds_xd1k8g2j:#d480ff;--eds_xd1k8g2k:#7371ff;--eds_xd1k8g2l:#aba9ff;--eds_xd1k8g2m:#43dac2;--eds_xd1k8g2n:#89e8d8;--eds_xd1k8g2o:#45c761;--eds_xd1k8g2p:#70d586;--eds_xd1k8g2q:#ff8e1f;--eds_xd1k8g2r:#ffb162;--eds_xd1k8g2s:#fd6535;--eds_xd1k8g2t:#fd7e56;--eds_xd1k8g2u:#b2715d;--eds_xd1k8g2v:#c8988a;--eds_xd1k8g2w:rgba(0,0,0,0);--eds_xd1k8g2x:#e6e6ea;--eds_xd1k8g2y:#aaaaae;--eds_xd1k8g2z:#aaaaae;--eds_xd1k8g30:#101014;--eds_xd1k8g31:#26bbff;--eds_xd1k8g32:#61cdff;--eds_xd1k8g33:#e6e6ea;--eds_xd1k8g34:#ffffff;--eds_xd1k8g35:#26bbff;--eds_xd1k8g36:#61cdff;--eds_xd1k8g37:#45c761;--eds_xd1k8g38:#ffc229;--eds_xd1k8g39:#ff6173;--eds_xd1k8g3a:#101014;--eds_xd1k8g3b:#ffffff;--eds_xd1k8g3c:Inter;--eds_xd1k8g3d:Inter Tight;--eds_xd1k8g3e:Recursive Mono;--eds_xd1k8g3f:400;--eds_xd1k8g3g:500;--eds_xd1k8g3h:700;--eds_xd1k8g3i:900;--eds_xd1k8g3j:0.4;--eds_xd1k8g3k:0.6;--eds_xd1k8g3l:0.8;--eds_xd1k8g3m:0px 1px 1px rgba(0,0,0,0.1),0px 2px 2px rgba(0,0,0,0.1),0px 4px 4px rgba(0,0,0,0.1),0px 6px 8px rgba(0,0,0,0.1),0px 8px 16px rgba(0,0,0,0.1);--eds_xd1k8g3n:0px 2px 1px rgba(0,0,0,0.1),0px 4px 2px rgba(0,0,0,0.1),0px 8px 4px rgba(0,0,0,0.1),0px 16px 8px rgba(0,0,0,0.1),0px 32px 16px rgba(0,0,0,0.1);--eds_xd1k8g3o:2px;--eds_xd1k8g3p:3px;--eds_xd1k8g3q:4px;--eds_xd1k8g3r:5px;--eds_xd1k8g3s:6px;--eds_xd1k8g3t:8px;--eds_xd1k8g3u:10px;--eds_xd1k8g3v:12px;--eds_xd1k8g3w:9999px;--eds_xd1k8g3x:1px;--eds_xd1k8g3y:2px;--eds_xd1k8g3z:0.125rem;--eds_xd1k8g40:0.25rem;--eds_xd1k8g41:0.375rem;--eds_xd1k8g42:0.5rem;--eds_xd1k8g43:0.625rem;--eds_xd1k8g44:0.75rem;--eds_xd1k8g45:0.875rem;--eds_xd1k8g46:1rem;--eds_xd1k8g47:1.25rem;--eds_xd1k8g48:1.5rem;--eds_xd1k8g49:1.75rem;--eds_xd1k8g4a:2rem;--eds_xd1k8g4b:2.5rem;--eds_xd1k8g4c:3rem;--eds_xd1k8g4d:3.5rem;--eds_xd1k8g4e:4rem;--eds_xd1k8g4f:5rem;--eds_xd1k8g4g:6rem;--eds_xd1k8g4h:8rem;--eds_xd1k8g4i:10rem;--eds_xd1k8g4j:2px;--eds_xd1k8g4k:4px;--eds_xd1k8g4l:6px;--eds_xd1k8g4m:8px;--eds_xd1k8g4n:10px;--eds_xd1k8g4o:12px;--eds_xd1k8g4p:14px;--eds_xd1k8g4q:16px;--eds_xd1k8g4r:20px;--eds_xd1k8g4s:24px;--eds_xd1k8g4t:28px;--eds_xd1k8g4u:32px;--eds_xd1k8g4v:40px;--eds_xd1k8g4w:48px;--eds_xd1k8g4x:56px;--eds_xd1k8g4y:64px;--eds_xd1k8g4z:80px;--eds_xd1k8g50:96px;--eds_xd1k8g51:128px;--eds_xd1k8g52:160px;--eds_xd1k8g53:0em;--eds_xd1k8g54:0.02em;--eds_xd1k8g55:0.1em;--eds_xd1k8g56:100%;--eds_xd1k8g57:125%;--eds_xd1k8g58:150%;--eds_xd1k8g59:165%;--eds_xd1k8g5a:0.75rem;--eds_xd1k8g5b:0.875rem;--eds_xd1k8g5c:1rem;--eds_xd1k8g5d:1.25rem;--eds_xd1k8g5e:1.5rem;--eds_xd1k8g5f:2rem;--eds_xd1k8g5g:2.5rem;--eds_xd1k8g5h:3.25rem;--eds_xd1k8g5i:4rem;--eds_xd1k8g5j:16px;}", Ho = "eds_xd1k8g0", Uo = ".eds_5a2e4c0{position:relative;overflow:hidden;display:grid;place-items:center;box-sizing:border-box;}.eds_5a2e4c1{display:grid;place-items:end;}.eds_5a2e4c2{background-color:inherit;border:none;outline:none;cursor:pointer;text-decoration:none;}.eds_5a2e4c3{display:inline-flex;align-items:center;max-width:fit-content;}.eds_5a2e4c2:focus-visible .eds_5a2e4c3{outline:none;}.eds_5a2e4c2:hover .eds_5a2e4c3{cursor:pointer;}.eds_5a2e4c4{width:100%;height:100%;background-size:cover;color:transparent;}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4c4{opacity:0.8;}.eds_5a2e4c5{display:none;}.eds_5a2e4c6{border-radius:var(--eds_xd1k8g3w);font-family:var(--eds_xd1k8g3c),sans-serif;font-weight:var(--eds_xd1k8g3g);line-height:var(--eds_xd1k8g54);color:var(--eds_xd1k8g2x);text-align:center;position:relative;display:grid;grid-area:stack;align-items:center;justify-content:center;overflow:hidden;}.eds_5a2e4c3.eds_5a2e4c2:focus-visible .eds_5a2e4c6{outline-offset:calc(var(--eds_xd1k8g40) - var(--eds_xd1k8g3y));outline-color:var(--eds_xd1k8gd);outline-width:var(--eds_xd1k8g3y);outline-style:solid;}.eds_5a2e4c7{width:var(--eds_xd1k8g4e);height:var(--eds_xd1k8g4e);font-size:var(--eds_xd1k8g5e);}.eds_5a2e4c8{width:var(--eds_xd1k8g4c);height:var(--eds_xd1k8g4c);font-size:18px;}.eds_5a2e4c9{width:var(--eds_xd1k8g4b);height:var(--eds_xd1k8g4b);font-size:var(--eds_xd1k8g5c);}.eds_5a2e4ca{width:var(--eds_xd1k8g4a);height:var(--eds_xd1k8g4a);font-size:var(--eds_xd1k8g5b);}.eds_5a2e4cb{width:var(--eds_xd1k8g48);height:var(--eds_xd1k8g48);font-size:var(--eds_xd1k8g5a);}.eds_5a2e4cc{background-color:var(--eds_xd1k8gs);color:var(--eds_xd1k8g2x);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4cc{background-color:var(--eds_xd1k8gt);}.eds_5a2e4cd{background-color:var(--eds_xd1k8g2e);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4cd{background-color:var(--eds_xd1k8g2f);}.eds_5a2e4ce{background-color:var(--eds_xd1k8g2g);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4ce{background-color:var(--eds_xd1k8g2h);}.eds_5a2e4cf{background-color:var(--eds_xd1k8g2i);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4cf{background-color:var(--eds_xd1k8g2j);}.eds_5a2e4cg{background-color:var(--eds_xd1k8g2k);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4cg{background-color:var(--eds_xd1k8g2l);}.eds_5a2e4ch{background-color:var(--eds_xd1k8go);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4ch{background-color:var(--eds_xd1k8gp);}.eds_5a2e4ci{background-color:var(--eds_xd1k8g2m);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4ci{background-color:var(--eds_xd1k8g2n);}.eds_5a2e4cj{background-color:var(--eds_xd1k8g2o);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4cj{background-color:var(--eds_xd1k8g2p);}.eds_5a2e4ck{background-color:var(--eds_xd1k8g2a);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4ck{background-color:var(--eds_xd1k8g2b);}.eds_5a2e4cl{background-color:var(--eds_xd1k8g2c);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4cl{background-color:var(--eds_xd1k8g2d);}.eds_5a2e4cm{background-color:var(--eds_xd1k8g2q);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4cm{background-color:var(--eds_xd1k8g2r);}.eds_5a2e4cn{background-color:var(--eds_xd1k8g2s);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4cn{background-color:var(--eds_xd1k8g2t);}.eds_5a2e4co{background-color:var(--eds_xd1k8g2u);color:var(--eds_xd1k8g3a);}.eds_5a2e4c3.eds_5a2e4c2:hover .eds_5a2e4co{background-color:var(--eds_xd1k8g2v);}.eds_5a2e4cp{font-family:var(--eds_xd1k8g3c),sans-serif;font-weight:var(--eds_xd1k8g3f);line-height:var(--eds_xd1k8g59);letter-spacing:var(--eds_xd1k8g54);color:var(--eds_xd1k8g2x);}.eds_5a2e4cq{font-size:var(--eds_xd1k8g5c);padding-inline-start:var(--eds_xd1k8g46);}.eds_5a2e4cr{font-size:var(--eds_xd1k8g5c);padding-inline-start:var(--eds_xd1k8g45);}.eds_5a2e4cs{font-size:var(--eds_xd1k8g5c);padding-inline-start:var(--eds_xd1k8g44);}.eds_5a2e4ct{font-size:var(--eds_xd1k8g5b);padding-inline-start:var(--eds_xd1k8g43);}.eds_5a2e4cu{font-size:var(--eds_xd1k8g5a);padding-inline-start:var(--eds_xd1k8g42);}.eds_5a2e4cw{width:var(--eds_xd1k8g49);height:var(--eds_xd1k8g49);}.eds_5a2e4cx{width:var(--eds_xd1k8g48);height:var(--eds_xd1k8g48);}.eds_5a2e4cy{width:var(--eds_xd1k8g47);height:var(--eds_xd1k8g47);}.eds_5a2e4cz{width:var(--eds_xd1k8g47);height:var(--eds_xd1k8g47);}.eds_5a2e4c10{width:var(--eds_xd1k8g46);height:var(--eds_xd1k8g46);}", Vo = Ot({ defaultClassName: "eds_5a2e4c6", variantClassNames: { size: { "2xl": "eds_5a2e4c7", xl: "eds_5a2e4c8", lg: "eds_5a2e4c9", md: "eds_5a2e4ca", sm: "eds_5a2e4cb" }, color: { gray: "eds_5a2e4cc", red: "eds_5a2e4cd", pink: "eds_5a2e4ce", purple: "eds_5a2e4cf", indigo: "eds_5a2e4cg", blue: "eds_5a2e4ch", cyan: "eds_5a2e4ci", green: "eds_5a2e4cj", lime: "eds_5a2e4ck", yellow: "eds_5a2e4cl", amber: "eds_5a2e4cm", orange: "eds_5a2e4cn", brown: "eds_5a2e4co" } }, defaultVariants: {}, compoundVariants: [] }), Ko = "eds_5a2e4c1";
Ot({ defaultClassName: "eds_5a2e4cv", variantClassNames: { size: { "2xl": "eds_5a2e4cw", xl: "eds_5a2e4cx", lg: "eds_5a2e4cy", md: "eds_5a2e4cz", sm: "eds_5a2e4c10" } }, defaultVariants: {}, compoundVariants: [] });
var qo = Ot({ defaultClassName: "eds_5a2e4cp", variantClassNames: { size: { "2xl": "eds_5a2e4cq", xl: "eds_5a2e4cr", lg: "eds_5a2e4cs", md: "eds_5a2e4ct", sm: "eds_5a2e4cu" } }, defaultVariants: {}, compoundVariants: [] }), Wo = "eds_5a2e4c3", Zo = "eds_5a2e4c4", Yo = "eds_5a2e4c2", Go = ".eds_1admtkn0{border-radius:var(--eds_xd1k8g3w);border-color:var(--eds_xd1k8g7);border-style:solid;background-color:var(--eds_xd1k8g2a);display:inline-flex;isolation:isolate;grid-area:stack;box-sizing:border-box;}.eds_1admtkn1{width:calc(var(--eds_xd1k8g46) + (var(--eds_xd1k8g40) * 2));height:calc(var(--eds_xd1k8g46) + (var(--eds_xd1k8g40) * 2));border-width:var(--eds_xd1k8g40);}.eds_1admtkn2{width:calc(var(--eds_xd1k8g44) + 6px);height:calc(var(--eds_xd1k8g44) + 6px);border-width:3px;}.eds_1admtkn3{width:calc(var(--eds_xd1k8g43) + 5px);height:calc(var(--eds_xd1k8g43) + 5px);border-width:2.5px;}.eds_1admtkn4{width:calc(var(--eds_xd1k8g42) + (var(--eds_xd1k8g3y) * 2));height:calc(var(--eds_xd1k8g42) + (var(--eds_xd1k8g3y) * 2));border-width:var(--eds_xd1k8g3y);}.eds_1admtkn5{width:calc(var(--eds_xd1k8g41) + 3px);height:calc(var(--eds_xd1k8g41) + 3px);border-width:1.5px;}", Qo = Ot({ defaultClassName: "eds_1admtkn0", variantClassNames: { size: { "2xl": "eds_1admtkn1", xl: "eds_1admtkn2", lg: "eds_1admtkn3", md: "eds_1admtkn4", sm: "eds_1admtkn5" } }, defaultVariants: {}, compoundVariants: [] });
let q = class extends we {
  constructor() {
    super(...arguments), this.onclick = null, this.size = "md", this.color = "gray";
  }
  render() {
    var e;
    const i = this.onclick != null || this.href != null, r = this.href ? Ft`a` : this.onclick ? Ft`button` : Ft`div`, n = Array.from(this.label && this.label.trim() || "")[0];
    return ht`<${r}
      class=${No({
      [Ho]: !0,
      [Wo]: !0,
      [Yo]: i
    })}
      @click=${this.onclick}
      href=${(e = this.href) !== null && e !== void 0 ? e : E}
    >
      <span class=${Ko}>
        <span
          class=${Vo({
      size: this.size,
      color: this.color
    })}
        >
          ${this.image ? ht`<img class=${Zo} src=${this.image} />` : n}
        </span>
        ${this.badge ? ht`<span
                class=${Qo({ size: this.size })}
                aria-label=${this.badgeLabel}
              />` : ""}
      </span>
      ${this.hideLabel ? "" : ht`<span class=${qo({ size: this.size })}>
              ${this.label}
            </span>`}</${r}>`;
  }
};
q.styles = Tr`
    ${Ye(Bo)}
    ${Ye(Uo)}
    ${Ye(Go)}
  `;
J([
  y({ type: String })
], q.prototype, "label", void 0);
J([
  y({ type: String })
], q.prototype, "image", void 0);
J([
  y({ type: Function })
], q.prototype, "onclick", void 0);
J([
  y({ type: String })
], q.prototype, "href", void 0);
J([
  y({ type: String })
], q.prototype, "size", void 0);
J([
  y({ type: String })
], q.prototype, "color", void 0);
J([
  y({ type: Boolean })
], q.prototype, "badge", void 0);
J([
  y({ type: String })
], q.prototype, "badgeLabel", void 0);
J([
  y({ type: Boolean })
], q.prototype, "hideLabel", void 0);
q = J([
  zr("eds-avatar")
], q);
const Xo = (t, e) => w`
		<epic-wf-simple-menu>
			${e?.links.map(
  (i) => w`
						<epic-wf-simple-menu-item
							@click=${(r) => t._navLinkClick(r, i)}
							hrefTemplate=${i.hrefTemplate || ""}
							locale=${t.getMappedHygraphLocale(i.locale || "")}
							label=${i.label || ""}
							domain=${t?.domain || ""}
						></epic-wf-simple-menu-item>
					`
)}
		</epic-wf-simple-menu>
	`, Jo = (t, e) => w`
		<epic-wf-subnav-item-menu
			.cardLinks=${e?.cardLinks || []}
			.descLinks=${e?.descLinks || []}
			.links=${e?.links || []}
			.onLinkClick=${t._navLinkClick.bind(t)}
			.getMappedHygraphLocale=${t.getMappedHygraphLocale.bind(t)}
			description=${e?.description || ""}
			itemTitle=${e?.itemTitle || ""}
			domain=${t?.domain || ""}
		></epic-wf-subnav-item-menu>
	`, es = (t, e) => {
  const i = e?.__typename === "NavSimpleMenu";
  return w`${i ? Xo(t, e) : Jo(t, e)} `;
};
let Bt = !1;
const ts = (t, e, i, r) => {
  const n = !!(e?.menu && e?.menu?.links?.length), o = (d, h) => {
    if (!n)
      return t._navLinkClick(d, e);
    if (e.hrefTemplate)
      if (ye(d) || Bt || t.isMobile)
        d.preventDefault();
      else
        return t._navLinkClick(d, e);
    t.closeDropdownsAndSearch(), t.activeMainLinkIndex === h ? t.activeMainLinkIndex = -1 : t.activeMainLinkIndex = h, Bt = !1;
  }, a = (d, h) => {
    ye(d) || (t.activeMainLinkIndex = h, n && (t.closeDropdownsAndSearch(), t._untrapFocus()));
  }, l = (d) => {
    ye(d) || (t.activeMainLinkIndex = -1);
  }, s = (d, h) => {
    (d.code === "Enter" || d.code === "Space") && (d.preventDefault(), t.activeMainLinkIndex === h ? (t.closeMenusAndInput(), t.drawerOpen ? t._untrapSubFocus() : t._untrapFocus()) : (t.closeDropdownsAndSearch(), t.activeMainLinkIndex = h, t.drawerOpen ? t._trapSubFocus(
      d,
      ot,
      Xt,
      d.target,
      () => t._untrapSubFocus(),
      (u) => {
        u.preventDefault(), u.stopImmediatePropagation(), t._backClick();
      }
    ) : t._trapFocus(d, ot, Xt)));
  };
  return w`
		<li
			@pointerenter=${t.isMobile ? null : (d) => a(d, i)}
			@pointerleave=${t.isMobile ? null : (d) => l(d)}
			class="main-nav__list-item"
			id="epic-wf-nav-main-link-${i}"
		>
			<epic-wf-main-link
				.rtl=${t.dir === B.RTL}
				@click=${(d) => o(d, i)}
				@touchend=${() => Bt = !0}
				@keydown=${n ? (d) => s(d, i) : null}
				active=${t.activeMainLinkIndex === i}
				forceActiveStyle=${t.activeMainLinkIndex === -1 && r}
				hasMenu=${n}
				hrefTemplate=${e?.hrefTemplate || ""}
				key=${e?.key || ""}
				label=${e?.label || ""}
				locale=${t.getMappedHygraphLocale(e?.locale || "")}
				domain=${t?.domain || ""}
				owner=${e?.owner || ""}
			>
				${n ? w`<div class="friendly-box friendly-box--wide"></div>` : ""}
			</epic-wf-main-link>
			${n ? e.menu && es(t, e.menu) : ""}
		</li>
	`;
}, is = (t) => {
  const e = !!(!t.drawerOpen && !t.isMobile && t.isCondensedLarge && t.largeCondensedLabel), i = t.mainLinks;
  let r = i, n = [], o = [];
  e && (o = i.filter((l) => l.collapsible), n = i.filter((l) => !l.collapsible), o.length > 1 && (r = n));
  const a = r.map((l, s) => {
    const d = t.forceActiveMainLinkKey && t.forceActiveMainLinkKey === l.key || nr(t.domain, t.locale, l);
    return ts(t, l, s, d);
  });
  if (e && o.length > 1) {
    let l = !1;
    for (let s = 0; s < o.length; s++) {
      const d = o[s];
      if (l = !!(t.forceActiveMainLinkKey && t.forceActiveMainLinkKey === d.key), l)
        break;
      if (nr(t.domain, t.locale, d)) {
        l = !0;
        break;
      }
    }
    a.push(Oo(t, o, l));
  }
  return a;
};
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Je = (t) => t ?? E, Jr = (t, e = "nav-account-menu") => w`
		<epic-wf-simple-menu id=${e}>
			<div class="avatar-wrapper">
				${t.isLoggedIn && t.displayName ? w`<eds-avatar label=${t.displayName} badge size="lg"></eds-avatar>` : ""}
			</div>
			${t.customAccountLinks.map(
  (i) => w`
						<epic-wf-simple-menu-item
							@click=${(r) => {
    t._mainAccountLinkClick(r, i);
  }}
							hrefTemplate=${i.hrefTemplate || ""}
							locale=${t.getMappedHygraphLocale(i.locale || "")}
							label=${i.label || ""}
							icon=${Ze.arrowUpRightSquare}
							labelBeforeStyle=${i.labelBeforeStyle || ""}
							labelAfterStyle=${i.labelAfterStyle || ""}
							labelStyle=${i.labelStyle || ""}
							domain=${t?.domain || ""}
						></epic-wf-simple-menu-item>
					`
)}
			${t.accountLinks.map((i) => {
  const r = i?.key || "", n = t.accountLinkOverrides[r] || {};
  return w`
					<epic-wf-simple-menu-item
						@click=${(o) => {
    t._mainAccountLinkClick(o, i);
  }}
						hrefTemplate=${i.hrefTemplate || ""}
						locale=${t.getMappedHygraphLocale(i.locale || "")}
						label=${i.label || ""}
						icon=${Ze.arrowUpRightSquare}
						domain=${t?.domain || ""}
						labelStyle=${Je(n?.labelStyle)}
						labelBeforeStyle=${Je(n?.labelBeforeStyle)}
						labelAfterStyle=${Je(n?.labelAfterStyle)}
					></epic-wf-simple-menu-item>
				`;
})}
			${t.signOutLink ? w`
						<epic-wf-simple-menu-item
							@click=${(i) => {
  t._mainAccountLinkClick(i, t.signOutLink);
}}
							hrefTemplate=${t.signOutLinkHref || t.signOutLink.hrefTemplate || ""}
							locale=${t.getMappedHygraphLocale(t.signOutLink.locale || "")}
							label=${t.signOutLink.label || ""}
							icon=${Ze.user}
							domain=${t?.domain || ""}
						></epic-wf-simple-menu-item>
				  ` : ""}
		</epic-wf-simple-menu>
	`, rs = (t, e, i, r) => w`
		<button
			@click=${e.onClick}
			aria-controls=${i}
			aria-expanded="${t.accountMenuOpen ? "true" : "false"}"
			aria-label="Account menu"
			class="dropdown__button"
			title=${t.displayName}
		>
			${r}
		</button>
		<div class="friendly-box friendly-box--top"></div>
		<div class="friendly-box friendly-box--wide-adjust" id="nav-account-friendly-box"></div>
		${Jr(t, i)}
	`, ns = (t, e, i) => w`
		<a
			class="dropdown__button"
			@click=${(r) => {
  t._mainAccountLinkClick(r, t.signInLink);
}}
			href="${z({
  domain: t.domain,
  locale: t.getMappedHygraphLocale(t.locale),
  hrefTemplate: t.signInLinkHref || t.signInLink?.hrefTemplate
})}"
			aria-label="${t.signInLink?.label || ""}"
		>
			${i}
		</a>
		<div class="friendly-box"></div>
		${Jr(t, e)}
	`, as = (t, e, i = "nav-account-menu") => {
  if (!t?.signInLink?.label)
    return w``;
  const r = w`<epic-wf-avatar-icon aria-hidden="true" isLoggedIn=${t.isLoggedIn}></epic-wf-avatar-icon>`;
  return w`
		<div
			@mouseleave=${e.onMouseLeave}
			@mouseover=${e.onMouseOver}
			class="dropdown dropdown--account ${t.accountMenuOpen ? "open" : ""}"
		>
			${t.isLoggedIn ? rs(t, e, i, r) : ns(t, i, r)}
		</div>
	`;
}, os = `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M3.784 11.25h3.99c.153-2.35.994-4.44 1.815-5.969.282-.525.564-.988.82-1.378a8.255 8.255 0 0 0-6.625 7.347ZM12 4.232c-.305.43-.697 1.03-1.09 1.759-.75 1.398-1.481 3.237-1.632 5.259h5.444c-.15-2.022-.882-3.861-1.633-5.259-.392-.73-.784-1.33-1.089-1.76Zm2.722 8.518H9.278c.15 2.022.882 3.861 1.633 5.259.392.73.784 1.33 1.089 1.76.305-.43.697-1.03 1.09-1.76.75-1.398 1.481-3.237 1.632-5.259Zm-4.313 7.347c-.256-.39-.538-.853-.82-1.378-.82-1.528-1.662-3.618-1.815-5.969h-3.99a8.255 8.255 0 0 0 6.625 7.347Zm3.182 0c.256-.39.538-.853.82-1.378.82-1.528 1.662-3.618 1.815-5.969h3.99a8.255 8.255 0 0 1-6.625 7.347Zm6.625-8.847h-3.99c-.153-2.35-.994-4.44-1.815-5.969a18.45 18.45 0 0 0-.82-1.378 8.255 8.255 0 0 1 6.625 7.347ZM2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Z" clip-rule="evenodd"/>
</svg>
`, ss = (t, e = "nav-locale-menu") => w`
		<epic-wf-simple-menu id=${e}>
			${t.localeOptions.map((i) => {
  const r = t.getMappedHygraphLocale(i.langCode), n = t.getMappedHygraphLocale(t.locale);
  if (t.blackListLangCodes && t.blackListLangCodes.includes(r))
    return;
  const o = Qr(t.domain), a = t.locale === i.langCode || n === i.langCode || n.toLowerCase() === i.langCode.toLowerCase(), s = [`${t.langUrlParam || "lang"}=${r}`], d = t.localeHrefTemplate || Po(o, s, [t.langUrlParam]);
  return w`
					<epic-wf-simple-menu-item
						@click=${(h) => {
    t._localeLinkClick(h, i);
  }}
						hrefTemplate=${Je(a ? void 0 : d)}
						icon=${Je(a ? Ze.globe : void 0)}
						noHoverStyle=${a}
						data-show-icon-lg-up="true"
						label=${i.label || ""}
						domain=${t?.domain || ""}
						locale=${r}
					></epic-wf-simple-menu-item>
				`;
})}
		</epic-wf-simple-menu>
	`, ls = (t, e, i = "nav-locale-menu") => w`
		<div
			@mouseleave=${e.onMouseLeave}
			@mouseover=${e.onMouseOver}
			class="dropdown dropdown--locale ${t.localeMenuOpen ? "open" : ""}"
		>
			<button
				@click=${e.onClick}
				aria-controls=${i}
				aria-expanded="${t.localeMenuOpen ? "true" : "false"}"
				aria-label="Locale menu"
				class="dropdown__button"
			>
				<span aria-hidden="true" class="icon-wrapper">${qe(os)}</span>
			</button>
			<div class="friendly-box friendly-box--top"></div>
			<div class="friendly-box friendly-box--wide-adjust" id="nav-locale-friendly-box"></div>
			${ss(t, i)}
		</div>
	`, ds = (t, e) => w`
		<epic-wf-search-box
			mode="normal"
			?opened=${t.searchOpen}
			@epic-wf-nav-search-activated=${t.toggleSearch}
			@epic-wf-nav-on-search=${t._onSearch}
			.activateSearchLabel=${t.commonStrings?.searchActivateLabel}
			.cancelLabel=${t.commonStrings?.searchCancelLabel}
			.deactivateSearchLabel=${t.commonStrings?.searchDeactivateLabel}
			.inputLabel=${t.brandStrings?.searchInputLabel}
			.placeholderLabel=${t.commonStrings?.searchPlaceholderLabel}
			.submitLabel=${t.commonStrings?.searchSubmitLabel}
		></epic-wf-search-box>
		${Qe(e, () => w`<epic-wf-bar-icon aria-hidden="true" class="icon-wrapper"></epic-wf-bar-icon>`)}
	`, cs = (t) => {
  const e = {
    onMouseLeave: t.isMobile ? void 0 : t._mainAccountMenuMouseLeave,
    onMouseOver: t.isMobile ? void 0 : t._mainAccountMenuMouseOver,
    onClick: t._mainAccountMenuClick
  }, i = {
    onMouseLeave: t.isMobile ? void 0 : t._mainLocaleMenuMouseLeave,
    onMouseOver: t.isMobile ? void 0 : t._mainLocaleMenuMouseOver,
    onClick: t._mainLocaleMenuClick
  };
  return w`
		<div class="tools">
			${Qe(!t.disableSearch, () => ds(t, !t.disableLocale || !t.disableUser))}
			${Qe(!t.disableLocale, () => ls(t, i))}
			${Qe(!t.disableUser, () => as(t, e))}
		</div>
	`;
}, ps = (t) => cs(t);
class us extends we {
  /**
   * Fired when `lit-media-query` changes detects a change
   * in the media query (from `true` to `false` and vice versa).
   *
   * @event changed
   * @param {boolean} value If media query is being fulfilled or not.
   */
  static get properties() {
    return {
      /**
       * Media query to be watched by the element.
       *
       * Can be modified at run time by setting a new value.
       */
      query: { type: String },
      _match: { type: Boolean }
    };
  }
  constructor() {
    super(), this.query = "(max-width:460px)", this._match = !1, this.boundResizeHandler = this._handleRisize.bind(this);
  }
  render() {
    return w`
      <style>
        :host {
          display: none;
        }
      </style>
    `;
  }
  firstUpdated() {
    this._initialMediaQueryCheck();
  }
  connectedCallback() {
    super.connectedCallback(), typeof window.visualViewport < "u" ? window.visualViewport.addEventListener("resize", this.boundResizeHandler) : window.addEventListener("resize", this.boundResizeHandler);
  }
  disconnectedCallback() {
    typeof window.visualViewport < "u" ? window.visualViewport.removeEventListener(
      "resize",
      this.boundResizeHandler
    ) : window.removeEventListener("resize", this.boundResizeHandler), super.disconnectedCallback();
  }
  _initialMediaQueryCheck() {
    window.matchMedia(this.query).matches ? this.dispatchEvent(
      new CustomEvent("changed", {
        detail: {
          value: !0
        },
        composed: !0,
        bubbles: !0
      })
    ) : this.dispatchEvent(
      new CustomEvent("changed", {
        detail: {
          value: !1
        },
        composed: !0,
        bubbles: !0
      })
    );
  }
  _handleRisize() {
    window.matchMedia(this.query).matches ? this._match === !1 && (this.dispatchEvent(
      new CustomEvent("changed", {
        detail: {
          value: !0
        },
        composed: !0,
        bubbles: !0
      })
    ), this._match = !0) : this._match === !0 && (this.dispatchEvent(
      new CustomEvent("changed", {
        detail: {
          value: !1
        },
        composed: !0,
        bubbles: !0
      })
    ), this._match = !1);
  }
}
window.customElements.get("lit-media-query") || customElements.define("lit-media-query", us);
const hs = `svg{fill:currentColor}svg[viewBox="0 0 24 24"]{inline-size:1.5rem;block-size:1.5rem}svg[viewBox="0 0 20 20"]{inline-size:1.25rem;block-size:1.25rem}svg{color:var(--color-text-secondary, #aaaaae)}.visually-hidden{border:0;clip:rect(0 0 0 0);height:1px;margin-block:-1px;margin-inline:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.dropdown{display:flex}@media (min-width: 1280px){.dropdown{position:relative}}.dropdown--locale .dropdown__button{padding-block:.25rem;padding-inline:.25rem}.dropdown__button{appearance:none;background-color:transparent;border:0;color:inherit;font-family:inherit;font-size:inherit;padding:0;text-decoration:none;user-select:none;display:flex;position:relative;z-index:1}.dropdown__button>*{pointer-events:none}.dropdown__button:not([disabled]){cursor:pointer}.dropdown__button svg{transition:color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1))}.dropdown__button[aria-expanded=true],.dropdown__button:hover{--color-text-secondary: var(--color-text-link-secondary-default, #e6e6ea)}.dropdown__button:not([aria-expanded=true])~epic-wf-simple-menu{opacity:0;pointer-events:none;visibility:hidden;transform:translate(calc(1rem * var(--transform-direction)))}.dropdown__button:not([aria-expanded=true])~.friendly-box{opacity:0;pointer-events:none;visibility:hidden;overflow:hidden}.dropdown .friendly-box--wide:before,.dropdown .friendly-box--wide:after{width:10.5rem}@media (max-width: 1279.9px){.dropdown epic-wf-simple-menu{transition-duration:.3s;transition-property:opacity transform;transition-timing-function:cubic-bezier(.65,0,.35,1);transform:translate(0)}}@media (min-width: 1280px){.dropdown epic-wf-simple-menu{position:absolute;inset-block-start:4.25rem;inset-inline-start:-1.1875rem;translate:var(--overflow-adjustment, none)}}.tools{align-items:center;box-sizing:border-box;display:flex;gap:.75rem;justify-content:flex-end;z-index:4}@media (max-width: 1279.9px){.tools{height:2rem}}@media (min-width: 1280px){.tools{flex-grow:1;position:relative}}.tools epic-wf-bar-icon{padding-inline:.25rem}@media (max-width: 1279.9px){.tools epic-wf-bar-icon{display:none}}@media (prefers-reduced-motion: reduce){*,:before,:after{animation-delay:-1ms!important;animation-duration:0s!important;transition-delay:1ms!important;transition-duration:0s!important}}:host{--header-height: 4.5rem;display:flex;width:100%;height:var(--header-height);background:var(--color-background-default, #18181c);font-family:Inter,sans-serif}:host([sticky=true]){position:sticky;top:0;z-index:var(--header-z-index, 9000)}.global-header{--header-padding-inline: 1.25rem;--drawer-main-cta-height: 5.875rem;--drawer-padding-block-end: 1.5rem;--drawer-padding-block-start: .5rem;--drawer-toolbar-height: 2.5rem;--transform-direction: 1;align-items:center;box-sizing:border-box;column-gap:.75rem;display:flex;height:var(--header-height);padding-block:1.25rem;padding-inline:var(--header-padding-inline);position:relative;width:100%;background:var(--color-background-default, #18181c);z-index:var(--header-z-index, 9000)}.global-header[data-mobile-drawer-open=true]{background:var(--color-background-default, #101014)}.global-header[data-mobile-drawer-open=true] .main-nav,.global-header[data-mobile-drawer-open=true] .toolbar{background-color:var(--color-background-default, #101014)}@media (max-width: 1279.9px){.global-header{--flyout-toggle-width: -6.25rem}}@media (max-width: 767.9px){.global-header{--flyout-toggle-width: -5.25rem}}@media (min-width: 768px){.global-header{--header-padding-inline: 1.5rem;column-gap:1.5rem}}.global-header.rtl{--transform-direction: -1}.global-header[data-mobile-cta-hidden=true]{--drawer-main-cta-height: 0px}.global-header__flyout-wrapper{align-items:center;display:flex;flex-shrink:0;gap:.75rem}@media (min-width: 768px){.global-header__flyout-wrapper{gap:1rem}}@media (max-width: 1279.9px){.global-header__flyout-wrapper{transition-duration:.3s;transition-property:opacity;transition-timing-function:cubic-bezier(.65,0,.35,1)}.global-header__flyout-wrapper epic-wf-bar-icon.invalid-logo{display:none}}@media (max-width: 1279.9px){.global-header epic-wf-property-logo{transition-duration:.3s;transition-property:transform;transition-timing-function:cubic-bezier(.65,0,.35,1)}}.global-header__drawer{align-items:center;box-sizing:border-box;column-gap:1.5rem;display:flex;flex-grow:1}@media (max-width: 1279.9px){.global-header__drawer{transition-duration:.3s;transition-property:background-color opacity;transition-timing-function:cubic-bezier(.65,0,.35,1);align-items:stretch;flex-direction:column-reverse;height:calc(100vh - var(--header-height) - var(--top-offset, 0px));inset-block-start:var(--header-height);inset-inline-start:0;justify-content:start;overflow:hidden;position:absolute;transform:translate(0);width:100%;z-index:10}@supports (height: 100dvh){.global-header__drawer{height:calc(100dvh - var(--header-height) - var(--top-offset, 0px))}}}.global-header__nav{align-items:center;display:flex;flex-grow:1;column-gap:2rem;row-gap:2rem;justify-content:space-between}@media (min-width: 1280px){.global-header__nav{position:relative}}.skip-nav{margin:0;position:absolute;inset-block-start:.75rem;inset-inline-start:.75rem;z-index:var(--skipnav-z-index, 9001)}@media (min-width: 1280px){.skip-nav{inset-block-start:1.25rem;inset-inline-start:1.25rem}}.skip-nav:not(:focus):not(:focus-within){border:0;clip:rect(0 0 0 0);height:1px;margin-block:-1px;margin-inline:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.toolbar{align-items:stretch;column-gap:1.5rem;display:flex;flex-direction:column-reverse;flex:1;position:relative;z-index:1}@media (max-width: 1279.9px){.toolbar{transition-duration:.3s;transition-property:transform;transition-timing-function:cubic-bezier(.65,0,.35,1);padding-block:.25rem;padding-inline:var(--header-padding-inline)}}@media (min-width: 1280px){.toolbar{align-items:center;flex-direction:row}}.toolbar__back-wrapper{transition-duration:.3s;transition-property:opacity transform;transition-timing-function:cubic-bezier(.65,0,.35,1);align-items:flex-start;background-color:var(--color-background-default, #101014);display:flex;flex-direction:column;inset:0;justify-content:center;max-width:100%;padding-block:inherit;padding-inline:inherit;position:absolute;transform:translate(0);width:calc(100vw - var(--header-padding-inline) * 2);z-index:4}@media (min-width: 1280px){.toolbar__back-wrapper{display:none}}.toolbar .back-button{appearance:none;background-color:transparent;border:0;color:inherit;font-family:inherit;font-size:inherit;padding:0;transition:color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1)),background-color var(--easing-duration, .2s) var(--easing, cubic-bezier(.65, 0, .35, 1));-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;--link-block-padding: .25rem;--link-inline-padding: 1rem;align-items:center;border-radius:.5rem;box-sizing:border-box;color:var(--color-text-secondary, #aaaaae);display:flex;justify-content:space-between;margin-block:calc(var(--link-block-padding) * -1);margin-inline:calc(var(--link-inline-padding) * -1);min-height:2rem;padding-block:var(--link-block-padding);padding-inline:var(--link-inline-padding);position:relative;text-decoration:none;user-select:none;z-index:3;color:var(--color-text-primary, #e6e6ea);margin:0;margin-inline-start:-.75rem;width:auto}.toolbar .back-button>*{pointer-events:none}.toolbar .back-button:not([disabled]){cursor:pointer}.toolbar .back-button:hover,.toolbar .back-button.active{background-color:var(--color-background-elevated-high-hover, #404044);color:var(--color-text-primary, #e6e6ea)}.toolbar .back-button .label{font-family:Inter,sans-serif;font-style:normal;font-weight:400;line-height:150%;font-size:.875rem;letter-spacing:.02em;flex-grow:1}.toolbar .back-button:hover{background-color:inherit}.toolbar .back-button .icon-wrapper{margin-inline-start:-.5rem}@media (min-width: 1280px){.avatar-wrapper{display:none}}@media (max-width: 1279.9px){.main-cta{transition-duration:.3s;transition-property:opacity;transition-timing-function:cubic-bezier(.65,0,.35,1);background-image:linear-gradient(0,var(--color-background-default, #101014),transparent);display:flex;inset-block-end:0;inset-inline:0;justify-content:center;overflow:hidden;padding:1.5rem;position:absolute;z-index:3}[data-mobile-cta-hidden=true] .main-cta{display:none}[data-dropdown-open=true] .main-cta,[data-mobile-subdrawer-open=true] .main-cta{opacity:0;pointer-events:none}}@media (max-width: 1279.9px){.main-cta epic-wf-cta-button{transition-duration:.3s;transition-property:transform;transition-timing-function:cubic-bezier(.65,0,.35,1);display:flex;justify-content:center;width:100%}}@media (max-width: 1279.9px){[data-dropdown-open=false][data-mobile-subdrawer-open=false] .toolbar__back-wrapper{opacity:0;pointer-events:none;visibility:hidden;transform:translate(calc(1rem * var(--transform-direction)))}}.main-nav{scrollbar-color:dark;z-index:1}@media (max-width: 1279.9px){.main-nav{transition-duration:.3s;transition-property:padding transform;transition-timing-function:cubic-bezier(.65,0,.35,1);height:100%;overflow-y:auto;padding-block-end:max(var(--drawer-padding-block-end),var(--drawer-main-cta-height));padding-block-start:var(--drawer-padding-block-start);padding-inline:var(--header-padding-inline)}}@media (min-width: 1280px){.main-nav{transition-duration:.3s;transition-property:opacity;transition-timing-function:cubic-bezier(.65,0,.35,1);align-items:center;display:flex}[data-search-open=true] .main-nav{display:none}}.main-nav__list{list-style:none;margin:0;padding:0;align-items:center;display:flex;column-gap:2rem}@media (max-width: 1279.9px){.main-nav__list{flex-direction:column;flex-grow:1;row-gap:1rem}}.main-nav__list-item{--main-nav-mobile-offset: -2.5rem;align-items:center;display:flex;width:100%}@media (max-width: 1279.9px){.main-nav__list-item{transition-duration:.3s;transition-property:transform;transition-timing-function:cubic-bezier(.65,0,.35,1)}}.main-nav__list-item--condensed epic-wf-subnav-item-menu{max-width:21.375rem}.main-nav__list-item epic-wf-condensed-menu{margin-inline-start:-1.5rem}@media (min-width: 1280px){.main-nav__list-item epic-wf-simple-menu{margin-inline-start:-1.25rem}}@media (min-width: 1280px){.main-nav__list-item epic-wf-subnav-item-menu{inset-inline-start:0}}@media (min-width: 1280px){.main-nav__list-item epic-wf-simple-menu,.main-nav__list-item epic-wf-subnav-item-menu,.main-nav__list-item epic-wf-condensed-menu{inset-block-start:4.25rem;position:absolute}}.main-nav__list-item epic-wf-main-link:not([active=true])~epic-wf-simple-menu,.main-nav__list-item epic-wf-main-link:not([active=true])~epic-wf-subnav-item-menu,.main-nav__list-item epic-wf-main-link:not([active=true])~epic-wf-condensed-menu,.main-nav__list-item epic-wf-main-link:not([active=true]) .friendly-box{opacity:0;pointer-events:none;visibility:hidden}@media (max-width: 1279.9px){epic-wf-simple-menu,epic-wf-subnav-item-menu{transition-duration:.3s;transition-property:opacity transform;transition-timing-function:cubic-bezier(.65,0,.35,1);background-color:var(--color-background-default, #101014);box-shadow:none;box-sizing:border-box;display:flex;flex-direction:column;height:calc(100vh - (var(--header-height) + var(--drawer-toolbar-height) + var(--top-offset, 0px)));inset-block-start:var(--drawer-toolbar-height);inset-inline:0;max-width:100%;overflow-y:auto;padding-block-end:var(--drawer-padding-block-end);padding-block-start:var(--drawer-padding-block-start);padding-inline:var(--header-padding-inline);position:absolute;row-gap:1rem;scrollbar-color:dark;transform:translate(calc(1rem * var(--transform-direction)));width:100vw;z-index:4}@supports (height: 100dvh){epic-wf-simple-menu,epic-wf-subnav-item-menu{height:calc(100dvh - (var(--header-height) + var(--drawer-toolbar-height) + var(--top-offset, 0px)))}}}.icon-wrapper{display:flex}.friendly-box{height:2.5rem;inset-block-start:100%;inset-inline-start:50%;position:absolute;transform:translate(calc(-50% * var(--transform-direction)));width:4.375rem}.friendly-box--wide{width:5rem}.friendly-box--wide:before,.friendly-box--wide:after{content:"";height:inherit;position:absolute;width:12rem}.friendly-box--wide:before{inset-inline-end:0;transform:rotate(340deg)}.friendly-box--wide:after{inset-inline-start:0;transform:rotate(-340deg)}.friendly-box--wide-adjust{width:15rem;translate:var(--overflow-adjustment, none)}.friendly-box--top{width:4rem;inset-block-start:1rem}.menu-toggle{appearance:none;background-color:transparent;border:0;color:inherit;font-family:inherit;font-size:inherit;padding:0;text-decoration:none;user-select:none;padding:.75rem;margin:-.75rem;margin-inline-start:auto}.menu-toggle>*{pointer-events:none}.menu-toggle:not([disabled]){cursor:pointer}@media (min-width: 1280px){.menu-toggle{display:none}}.menu-toggle svg{display:block;width:1.5rem;height:1.5rem;fill:var(--color-text-primary, #e6e6ea)}@media (max-width: 1279.9px){[data-mobile-drawer-open=false][data-mobile-drawer-has-opened=true] .main-nav{overflow-y:hidden}[data-mobile-drawer-open=true] .global-header__flyout-wrapper.hide-in-drawer{opacity:0;pointer-events:none}[data-mobile-drawer-open=true] epic-wf-property-logo{transform:translate(calc(var(--flyout-toggle-width) * var(--transform-direction)))}[data-mobile-drawer-open=true][data-mobile-drawer-has-opened=false] .global-header__drawer{pointer-events:none}[data-mobile-drawer-open=true][data-mobile-drawer-has-opened=false] .main-nav{overflow-y:hidden}[data-mobile-drawer-open=true] .toolbar{transform:translateY(0)}[data-mobile-drawer-open=true] .main-cta epic-wf-cta-button{transform:translateY(0)}[data-mobile-drawer-open=true][data-search-open=true]{--search-box-width: 100%}[data-mobile-drawer-open=true][data-search-open=true] .dropdown{display:none}[data-dropdown-open=true] epic-wf-simple-menu,[data-dropdown-open=true] epic-wf-subnav-item-menu,[data-mobile-subdrawer-open=true] epic-wf-simple-menu,[data-mobile-subdrawer-open=true] epic-wf-subnav-item-menu{transform:translate(0)}[data-mobile-drawer-open=false] epic-wf-property-logo{transform:translate(0)}[data-mobile-drawer-open=false] .global-header__drawer{opacity:0;pointer-events:none;visibility:hidden;background-color:transparent}[data-mobile-drawer-open=false] .main-nav{padding-block-start:2.5rem;transform:translateY(calc(var(--drawer-main-cta-height) * -1))}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(1){transform:translateY(calc(var(--main-nav-mobile-offset) * 1));z-index:1}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(2){transform:translateY(calc(var(--main-nav-mobile-offset) * 2));z-index:2}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(3){transform:translateY(calc(var(--main-nav-mobile-offset) * 3));z-index:3}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(4){transform:translateY(calc(var(--main-nav-mobile-offset) * 4));z-index:4}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(5){transform:translateY(calc(var(--main-nav-mobile-offset) * 5));z-index:5}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(6){transform:translateY(calc(var(--main-nav-mobile-offset) * 6));z-index:6}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(7){transform:translateY(calc(var(--main-nav-mobile-offset) * 7));z-index:7}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(8){transform:translateY(calc(var(--main-nav-mobile-offset) * 8));z-index:8}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(9){transform:translateY(calc(var(--main-nav-mobile-offset) * 9));z-index:9}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(10){transform:translateY(calc(var(--main-nav-mobile-offset) * 10));z-index:10}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(11){transform:translateY(calc(var(--main-nav-mobile-offset) * 11));z-index:11}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(12){transform:translateY(calc(var(--main-nav-mobile-offset) * 12));z-index:12}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(13){transform:translateY(calc(var(--main-nav-mobile-offset) * 13));z-index:13}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(14){transform:translateY(calc(var(--main-nav-mobile-offset) * 14));z-index:14}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(15){transform:translateY(calc(var(--main-nav-mobile-offset) * 15));z-index:15}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(16){transform:translateY(calc(var(--main-nav-mobile-offset) * 16));z-index:16}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(17){transform:translateY(calc(var(--main-nav-mobile-offset) * 17));z-index:17}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(18){transform:translateY(calc(var(--main-nav-mobile-offset) * 18));z-index:18}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(19){transform:translateY(calc(var(--main-nav-mobile-offset) * 19));z-index:19}[data-mobile-drawer-open=false] .main-nav__list-item:nth-child(20){transform:translateY(calc(var(--main-nav-mobile-offset) * 20));z-index:20}[data-mobile-drawer-open=false] .toolbar{transform:translateY(calc(-.375rem - 100%))}[data-mobile-drawer-open=false] .main-cta epic-wf-cta-button{transform:translateY(100%)}}
`, fs = () => {
  if (document) {
    const t = document.createElement("style");
    t.innerHTML = `
			.wf-nav-open {
				height: 100vh;
				overflow: hidden;
				position: fixed;
				width: 100vw;
			}

			@supports (height: 100dvh) {
				.wf-nav-open {
					height: 100dvh;
				}
			}
		`, document.body.appendChild(t);
  }
}, ms = (t) => {
  t === !0 ? document.body.classList.add("wf-nav-open") : document.body.classList.remove("wf-nav-open");
};
function N(t) {
  return t.getBoundingClientRect();
}
function gs(t, e) {
  return {
    get collidedTop() {
      return N(t).top < N(e).top;
    },
    get collidedBottom() {
      return N(t).bottom > N(e).bottom;
    },
    get collidedLeft() {
      return N(t).left < N(e).left;
    },
    get collidedRight() {
      return N(t).right > N(e).right;
    },
    get overflowTop() {
      return N(e).top - N(t).top;
    },
    get overflowBottom() {
      return N(t).bottom - N(e).bottom;
    },
    get overflowLeft() {
      return N(e).left - N(t).left;
    },
    get overflowRight() {
      return N(t).right - N(e).right;
    }
  };
}
const en = ["nav-account-friendly-box", "nav-account-menu", "nav-locale-friendly-box", "nav-locale-menu"], Jt = "data-overflow-adjusted", fi = "--overflow-adjustment", vs = (t) => {
  t && en.forEach((e) => {
    const i = t.querySelector(`#${e}`);
    i && (i.setAttribute(Jt, "false"), i.style.setProperty(fi, "none"));
  });
}, bs = (t, { isMobile: e, drawerOpen: i, force: r }) => {
  t && (r && vs(t), setTimeout(() => {
    en.forEach((n) => {
      const o = t.querySelector(`#${n}`);
      o && (e || i ? (o.setAttribute(Jt, "false"), o.style.setProperty(fi, "none")) : (_s(o), o.setAttribute(Jt, "true")));
    });
  }, 0));
};
function _s(t, e = 16) {
  const i = gs(t, document.body);
  let r = 0;
  i.overflowLeft > 0 ? r = e + i.overflowLeft : i.overflowRight > 0 && (r = (e + i.overflowRight) * -1);
  const n = `${r / 16}rem`;
  r && t.style.setProperty(fi, n);
}
const ys = ["ar", "ar-ar", "ar-AR"], dr = (t) => !t || typeof t != "string" ? !1 : ys.includes(t), ws = (t, e, i) => t.map((n) => {
  const o = z({
    hrefTemplate: n.hrefTemplate,
    domain: e,
    locale: i
  });
  return n.menu && (n.menu.__typename === "NavSimpleMenu" ? n.menu.links = n.menu.links.map((a) => ({
    ...a,
    hrefTemplate: z({
      hrefTemplate: a.hrefTemplate,
      domain: e,
      locale: i
    })
  })) : n.menu.__typename === "NavSubnavMenu" && (n.menu.links = n.menu.links.map((a) => ({
    ...a,
    hrefTemplate: z({
      hrefTemplate: a.hrefTemplate,
      domain: e,
      locale: i
    })
  })), n.menu.descLinks = n.menu.descLinks.map((a) => ({
    ...a,
    hrefTemplate: z({
      hrefTemplate: a.hrefTemplate,
      domain: e,
      locale: i
    })
  })), n.menu.cardLinks = n.menu.cardLinks.map((a) => ({
    ...a,
    hrefTemplate: z({
      hrefTemplate: a.hrefTemplate,
      domain: e,
      locale: i
    })
  })))), {
    ...n,
    hrefTemplate: o
  };
});
var lt = typeof navigator < "u" && typeof window < "u";
if (lt && typeof nw < "u")
  try {
    nw.Window.get();
  } catch {
    lt = !1;
  }
var xs = !lt, Se = lt ? navigator.userAgent : void 0;
function ks(t, e) {
  var i = window.matchMedia(t);
  e(i.matches);
  var r = () => e(i.matches);
  return i.addListener(r), () => i.removeListener(r);
}
var _ = { gui: lt, terminal: xs, registerQuery: ks };
_.node = typeof process < "u" && !!process.versions && !!process.versions.node;
_.pwa = _.gui && window.matchMedia("(display-mode: standalone)").matches && document.head.querySelector('[rel="manifest"]') !== null;
_.uwp = typeof Windows < "u" && typeof MSApp < "u";
_.nwjs = !!(_.node && process.versions.nw);
_.electron = !!(_.node && process.versions.electron);
_.cordova = !!(_.gui && window.cordova);
_.packaged = _.uwp || _.nwjs || _.electron || _.cordova;
_.web = !_.node && !_.packaged;
_.browser = _.web;
_.website = _.web && !_.pwa;
_.worker = !_.gui && typeof self < "u" && self.importScripts !== void 0;
_.serviceWorker = _.worker && !!navigator.serviceWorker.controller || !1;
_.android = _.gui ? Se.includes("Android") : !1;
_.chromeos = _.gui ? Se.includes("CrOS") : !1;
_.tizen = _.gui ? Se.includes("Tizen") : !1;
_.ios = _.gui && /iPad|iPhone|iPod/.test(Se) && !window.MSStream || !1;
_.linuxBased = _.android || _.tizen;
_.windows = _.node ? process.platform === "win32" : Se.includes("Windows");
_.macos = _.node ? process.platform === "darwin" : Se.includes("Macintosh");
_.linux = _.node ? process.platform === "linux" : Se.includes("Linux") && !_.linuxBased && !_.macos;
const $s = (t, e, i) => {
  if (t?.hrefTemplate)
    return t.hrefTemplate;
  let r = t?.defaultHref || "";
  if (_.android && t?.androidHref ? r = t.androidHref : _.ios && t?.iosHref ? r = t.iosHref : _.windows && t?.windowsHref ? r = t.windowsHref : _.macos && t?.macHref && (r = t.macHref), i && r) {
    const n = new URL(r, e || location.origin);
    Object.entries(i).map((o) => n.searchParams.append(...o)), r = n.toString();
  }
  return r || "";
};
var As = Object.defineProperty, Ls = Object.getOwnPropertyDescriptor, v = (t, e, i, r) => {
  for (var n = r > 1 ? void 0 : r ? Ls(e, i) : e, o = t.length - 1, a; o >= 0; o--)
    (a = t[o]) && (n = (r ? a(e, i, n) : a(n)) || n);
  return r && n && As(e, i, n), n;
};
const Ss = {
  "zh-hans": "zh-CN",
  "zh-hant": "zh-TW"
};
let m = class extends we {
  constructor() {
    super(...arguments), this.allPageData = {}, this._locale = "", this._historyReplaced = !1, this.hygraphLocaleMapping = {}, this.isMobile = !1, this._isMobile = "(max-width: 1279.9px)", this.isCondensedLarge = !1, this._condensedLarge = "(min-width: 1280px) and (max-width: 1439.9px)", this.isNotMobile = !0, this._isNotMobile = "(min-width: 1280px)", this.epicSID = Vr("_epicSID"), this.flyoutOpen = !1, this.drawerOpen = !1, this.drawerInTransition = !1, this.submenuOpen = !1, this.largeCondensedLabel = "", this.brandStrings = {}, this.commonStrings = {}, this.navigationFlyout = {}, this.id = "", this.domain = "", this.propertyLogo = {}, this.mainLinks = new Array(), this.accountLinks = new Array(), this.customAccountLinks = new Array(), this.localeOptions = new Array(), this.blackListLangCodes = new Array(), this.signInLink = {}, this.signOutLink = {}, this.forceActiveMainLinkKey = "", this._platformCtaButton = {}, this.activeMainLinkIndex = -1, this.moreOpened = !1, this.localeMenuOpen = !1, this.accountMenuOpen = !1, this.searchOpen = !1, this.isLoggedIn = !1, this.displayName = "", this.disableSearch = !1, this.disableLocale = !1, this.disableUser = !1, this.disableCtaButton = !1, this.disableCtaButtonOnMobile = !1, this.topOffsetPixels = 0, this.langUrlParam = "lang", this.localeHrefTemplate = "", this.signInLinkHref = "", this.signOutLinkHref = "", this.sticky = "", this.accountLinkOverrides = {}, this.drawerButtonLabel = "Menu", this.skipNavContentId = "", this.skipNavLabel = "Skip to main content", this.propertyLogoWidth = 0, this._focusTrap = new st(), this._subFocusTrap = new st();
  }
  connectedCallback() {
    if (super.connectedCallback(), window && window.history && !this._historyReplaced) {
      const r = window.history.pushState;
      history.pushState = (...o) => {
        r.apply(window.history, o), this.requestUpdate();
      };
      const n = window.history.replaceState;
      history.replaceState = (...o) => {
        n.apply(window.history, o), this.requestUpdate();
      }, this._historyReplaced = !0;
    }
    addEventListener("click", this._bodyClick.bind(this));
    const t = document.body.style.getPropertyValue("overflow-x");
    document.body.style.setProperty("overflow-x", "hidden");
    let e = !0;
    const i = () => {
      e && (this._adjustOverflow(!0), e = !1, setTimeout(() => {
        document.body.style.setProperty("overflow-x", t);
      }, 100));
    };
    document.fonts.onloadingdone = i, setTimeout(i, 1500), fs();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), removeEventListener("click", this._bodyClick.bind(this));
  }
  _adjustOverflow(t = !1) {
    bs(this.shadowRoot, {
      isMobile: this.isMobile,
      drawerOpen: this.drawerOpen,
      force: t
    });
  }
  _bodyClick(t) {
    const e = this.shadowRoot;
    e && (t.composedPath().includes(e) || (this.accountMenuOpen || this.flyoutOpen || this.localeMenuOpen || this.moreOpened) && this.closeMenusAndInput());
  }
  _onSearch(t) {
    this.drawerOpen && (this.closeDrawer(), this._untrapFocus());
  }
  getReverseLocale(t) {
    if (!t)
      return;
    const i = Object.fromEntries(
      Object.entries(this.hygraphLocaleMapping || {}).map((r) => {
        const n = r[1] || "";
        return [n?.toLowerCase() || n, r[0]];
      })
    )[t.toLowerCase()];
    return i || Ss[t.toLowerCase()];
  }
  set locale(t) {
    const i = this.getReverseLocale(t) || t, r = this._locale;
    this._locale = i, r !== i && this.updatePropertyValues(i), this.requestUpdate("locale", r);
  }
  get locale() {
    return this._locale;
  }
  getMappedHygraphLocale(t) {
    return this.hygraphLocaleMapping && typeof this.hygraphLocaleMapping[t] < "u" ? this.hygraphLocaleMapping[t] : t;
  }
  async updatePropertyValues(t) {
    const e = t.replace(/-/g, "_"), i = this.allPageData?.[e];
    i ? Object.assign(this, i) : this.allPageData?.en && Object.assign(this, this.allPageData?.en);
  }
  _handleIsMobile(t) {
    this.isMobile = t?.detail?.value || !1, this.isMobile && (this.drawer.style.setProperty("display", "none"), setTimeout(() => {
      this.drawer.style.setProperty("display", "");
    }, 0.4)), this._adjustOverflow();
  }
  _handleCondensedQuery(t) {
    this.isCondensedLarge = t?.detail?.value || !1;
  }
  _handleIsNotMobile(t) {
    this.isNotMobile = t?.detail?.value || !1, this.closeDrawer();
  }
  set platformCtaButton(t) {
    const e = this._platformCtaButton;
    this._platformCtaButton = {
      ...t
    }, this.requestUpdate("platformCtaButton", e);
  }
  get platformCtaButton() {
    return this._platformCtaButton;
  }
  getMainLinks() {
    return ws(this.mainLinks, this.domain, this.locale);
  }
  closeDropdowns() {
    this.accountMenuOpen = !1, this.flyoutOpen = !1, this.localeMenuOpen = !1, this.moreOpened = !1;
  }
  closeSearch() {
    this.searchOpen = !1;
  }
  closeMainLinkMenus() {
    this.activeMainLinkIndex = -1;
  }
  closeDropdownsAndSearch() {
    this.closeDropdowns(), this.closeSearch();
  }
  closeMenusAndInput() {
    this.closeDropdownsAndSearch(), this.closeMainLinkMenus();
  }
  closeDrawer() {
    this.drawerOpen = !1, this._adjustOverflow(), this.dispatchEvent(
      new CustomEvent(oe.DRAWER_TOGGLE, {
        detail: { opened: !1 },
        bubbles: !0,
        composed: !0
      })
    );
  }
  closeAll() {
    this.closeDrawer(), this.closeMenusAndInput();
  }
  toggleDrawer(t) {
    this.drawerInTransition || (this.drawerOpen = !this.drawerOpen), this.drawerInTransition = !0, this._adjustOverflow(), this.drawerOpen ? (this.closeMenusAndInput(), this._trapFocus(t, ot, Me)) : this._untrapFocus(), this.dispatchEvent(
      new CustomEvent(oe.DRAWER_TOGGLE, {
        detail: { opened: this.drawerOpen },
        bubbles: !0,
        composed: !0
      })
    );
  }
  toggleFlyout(t) {
    const e = this.flyoutOpen;
    if (this.closeMenusAndInput(), this.flyoutOpen = !e, e)
      this._untrapFocus();
    else {
      const i = t.target;
      if (i && i.shadowRoot) {
        const r = i.shadowRoot, n = r.querySelector("#nav-flyout-toggle"), o = r.querySelector("#nav-flyout-menu");
        n && o && this._trapFocus(
          t,
          () => o,
          () => n,
          () => this._untrapFocus()
        );
      }
    }
  }
  toggleSearch(t) {
    if (this.closeMenusAndInput(), t?.detail && (this.searchOpen = t.detail?.activated || !1, this.drawerOpen))
      if (this.searchOpen) {
        const e = t.composedPath();
        if (e.length > 0) {
          const i = e[0];
          this._trapSubFocus(
            t,
            (r) => i,
            () => i,
            i,
            () => {
            },
            (r) => {
            }
          );
        }
      } else
        this._untrapSubFocus();
  }
  _handleEscape(t) {
    t.key === "Escape" && (this.accountMenuOpen || this.activeMainLinkIndex > -1 || this.flyoutOpen || this.localeMenuOpen || this.moreOpened || this.searchOpen ? this.closeMenusAndInput() : this.closeDrawer());
  }
  _navLinkClick(t, e, i) {
    i || this.closeAll(), e && (e.hrefTemplate && (e.hrefTemplate = z({
      domain: this.domain,
      locale: this.getMappedHygraphLocale(this.locale),
      hrefTemplate: e.hrefTemplate
    })), this.dispatchEvent(
      new CustomEvent(oe.NAV_LINK_CLICK, {
        detail: { originalEvent: t, link: e },
        bubbles: !0,
        composed: !0
      })
    ));
  }
  _localeLinkClick(t, e) {
    if (this.closeAll(), e) {
      const i = this.getMappedHygraphLocale(e.langCode);
      this.dispatchEvent(
        new CustomEvent(oe.LOCALE_LINK_CLICK, {
          detail: { originalEvent: t, link: { ...e, mappedLangCode: i } },
          bubbles: !0,
          composed: !0
        })
      );
    }
  }
  _mainLogoClick(t, e) {
    this.closeAll(), e && (e.hrefTemplate && (e.hrefTemplate = z({
      domain: this.domain,
      locale: this.getMappedHygraphLocale(this.locale),
      hrefTemplate: e.hrefTemplate
    })), this.dispatchEvent(
      new CustomEvent(oe.PROPERTY_LOGO_CLICK, {
        detail: { originalEvent: t, link: e },
        bubbles: !0,
        composed: !0
      })
    ));
  }
  _mainAccountLinkClick(t, e) {
    this.closeAll(), e && (e.hrefTemplate && (e.hrefTemplate = z({
      domain: this.domain,
      locale: this.getMappedHygraphLocale(this.locale),
      hrefTemplate: e.hrefTemplate
    })), this.dispatchEvent(
      new CustomEvent(oe.ACCOUNT_LINK_CLICK, {
        detail: { originalEvent: t, link: e },
        bubbles: !0,
        composed: !0
      })
    ));
  }
  _mainCtaClick(t, e) {
    this.closeAll(), e && (e.hrefTemplate && (e.hrefTemplate = z({
      domain: this.domain,
      locale: this.getMappedHygraphLocale(this.locale),
      hrefTemplate: e.hrefTemplate
    })), this.dispatchEvent(
      new CustomEvent(oe.CTA_CLICK, {
        detail: { originalEvent: t, link: e },
        bubbles: !0,
        composed: !0
      })
    ));
  }
  _mainLocaleMenuClick(t) {
    const e = this.localeMenuOpen;
    this.closeMenusAndInput(), this.localeMenuOpen = !e, this.localeMenuOpen ? this.drawerOpen ? this._trapSubFocus(
      t,
      (i) => i.nextElementSibling?.nextElementSibling?.nextElementSibling,
      Me,
      t.target,
      () => {
      },
      (i) => {
        this.closeMenusAndInput(), this._untrapSubFocus();
      }
    ) : this._trapFocus(
      t,
      (i) => i.nextElementSibling?.nextElementSibling?.nextElementSibling,
      Me,
      () => {
      }
    ) : this._untrapFocus();
  }
  _mainLocaleMenuMouseOver(t) {
    this.localeMenuOpen = !0;
  }
  _mainLocaleMenuMouseLeave(t) {
    this.localeMenuOpen = !1, this._untrapFocus();
  }
  _mainAccountMenuClick(t) {
    const e = this.accountMenuOpen;
    this.closeMenusAndInput(), this.accountMenuOpen = !e, this.accountMenuOpen ? this.drawerOpen ? this._trapSubFocus(
      t,
      (i) => i.nextElementSibling?.nextElementSibling?.nextElementSibling,
      Me,
      t.target,
      () => {
      },
      (i) => {
        this.closeMenusAndInput(), this._untrapSubFocus();
      }
    ) : this._trapFocus(
      t,
      (i) => i.nextElementSibling?.nextElementSibling?.nextElementSibling,
      Me,
      () => {
      }
    ) : this._untrapFocus();
  }
  _mainAccountMenuMouseOver(t) {
    this.accountMenuOpen = !0;
  }
  _mainAccountMenuMouseLeave(t) {
    this.accountMenuOpen = !1, this._untrapFocus();
  }
  onDrawerAnimationEnd(t) {
    this.drawerOpen ? (this.header.setAttribute("data-mobile-drawer-has-opened", "true"), this.header.setAttribute("data-mobile-drawer-has-closed", "false")) : (this.header.setAttribute("data-mobile-drawer-has-opened", "false"), this.header.setAttribute("data-mobile-drawer-has-closed", "true")), this.drawerInTransition = !1;
  }
  _backClick() {
    this.closeMenusAndInput();
  }
  _trapFocus(t, e, i, r, n) {
    this._trapFocusIn(
      t,
      this._focusTrap,
      e,
      i,
      this,
      r,
      n
    );
  }
  _untrapFocus() {
    this._untrapFocusIn(this._focusTrap);
  }
  _trapSubFocus(t, e, i, r, n, o) {
    this._trapFocusIn(
      t,
      this._subFocusTrap,
      e,
      i,
      r,
      n,
      o
    );
  }
  _untrapSubFocus() {
    this._untrapFocusIn(this._subFocusTrap);
  }
  get _isSubFocusTrapped() {
    return this._subFocusTrap.active;
  }
  _trapFocusIn(t, e, i, r, n, o, a) {
    const l = t.target;
    if (l) {
      const s = i(l);
      if (s) {
        const d = r(l);
        e.trapFocusIn(s, {
          returnFocusTo: d,
          fallbackFocus: n,
          onDeactivate: o ?? this.closeDropdowns.bind(this),
          onEscapeDeactivates: a ?? this._handleEscape.bind(this)
        });
      }
    }
  }
  _untrapFocusIn(t) {
    t.untrapFocus();
  }
  render() {
    (!this.localeOptions || !this.localeOptions.length) && this.disableLocale === !1 && (this.disableLocale = !0);
    const t = this.drawerOpen && this.activeMainLinkIndex > -1, e = !!(this.propertyLogo?.logo && this.propertyLogo?.logo?.url), i = !!(this.propertyLogo?.iconOnlyLogo && this.propertyLogo?.iconOnlyLogo?.url), r = e || i, n = this.propertyLogo?.logo?.url || this.propertyLogo?.iconOnlyLogo?.url || "";
    ms(this.drawerOpen), r && this.propertyLogoWidth === 0 && console.error("`propertyLogoWidth` not set, but is required to render the logo. Layout shift will occur!");
    const o = this.epicSID ? { trackingId: this.epicSID } : void 0, a = {
      ...this.platformCtaButton,
      defaultHref: z({
        hrefTemplate: $s(this.platformCtaButton, this.domain, o),
        locale: this.getMappedHygraphLocale(this.locale),
        domain: this.domain
      })
    };
    return (this.dir === "" || this.dir === B.LTR) && dr(this.locale) ? (this.dir = B.RTL, this.setAttribute("dir", B.RTL), this._adjustOverflow(!0)) : this.dir === B.RTL && !dr(this.locale) && (this.dir = B.LTR, this.setAttribute("dir", B.LTR), this._adjustOverflow(!0)), w`
			${r ? w`<link rel="preload" fetchpriority="high" as="image" href="${n}" />` : ""}
			${this.skipNavContentId ? w`<epic-wf-cta-button
						class="skip-nav"
						href="#${this.skipNavContentId}"
						id="skip-nav"
						label=${this.commonStrings?.skipNavLabel || this.skipNavLabel}
						target="_self"
				  ></epic-wf-cta-button>` : null}

			<header
				class="global-header ${this.dir === B.RTL ? B.RTL : ""}"
				data-dropdown-open=${this.accountMenuOpen || this.localeMenuOpen}
				data-flyout-open=${this.flyoutOpen}
				data-mobile-cta-hidden=${this.disableCtaButtonOnMobile}
				data-mobile-drawer-open=${this.drawerOpen}
				data-mobile-drawer-has-opened="false"
				data-mobile-drawer-has-closed="true"
				data-mobile-subdrawer-open=${t}
				data-search-open=${this.searchOpen}
				id="global-header"
				style=${this.topOffsetPixels > 0 ? `--top-offset: ${this.topOffsetPixels}px` : ""}
			>
				${io({ disabled: !r && this.drawerOpen, nav: this, validPropertyLogo: r })}

				<nav aria-label="${this.brandStrings?.componentLabel || ""}" class="global-header__nav">
					${r ? w`
								<epic-wf-property-logo
									@click=${(l) => {
      this._mainLogoClick(l, this.propertyLogo);
    }}
									.logo=${this.propertyLogo?.logo || {}}
									.iconOnlyLogo=${this.propertyLogo?.iconOnlyLogo || {}}
									logoAlt=${this.propertyLogo?.logoAlt || ""}
									hrefTemplate=${this.propertyLogo?.hrefTemplate || ""}
									locale=${this.getMappedHygraphLocale(this.propertyLogo?.locale || "")}
									width=${this.propertyLogoWidth}
									domain=${this.domain || ""}
								></epic-wf-property-logo>
						  ` : null}

					<button
						@click=${this.toggleDrawer}
						aria-controls="mobile-drawer"
						aria-expanded=${this.drawerOpen}
						aria-label=${this.drawerButtonLabel}
						class="menu-toggle"
						id="mobile-drawer-toggle"
					>
						${this.drawerOpen ? qe(sn) : qe(on)}
					</button>
					<div @transitionend=${this.onDrawerAnimationEnd} class="global-header__drawer" id="mobile-drawer">
						<div class="main-nav">
							<ul class="main-nav__list">
								${is(this)}
							</ul>
						</div>

						<div class="toolbar">
							${ps(this)}

							<div class="toolbar__back-wrapper">
								<button
									@click=${this._backClick}
									aria-label="${this.commonStrings?.backButtonAccessibleLabel || ""}"
									class="back-button"
								>
									<span aria-hidden="true" class="icon-wrapper">
										${this.dir === B.RTL ? qe(an) : qe(nn)}
									</span>
									<span class="label">${this.commonStrings?.backButtonLabel || ""}</span>
								</button>
							</div>
						</div>

						${Qe(
      !this.disableCtaButton && a?.label,
      () => w`
								<div class="main-cta">
									<epic-wf-cta-button
										@click=${(l) => {
        this._mainCtaClick(l, a);
      }}
										domain=${this.domain}
										href=${a?.defaultHref || ""}
										label=${a?.label || ""}
										locale=${this.getMappedHygraphLocale(this.locale)}
									></epic-wf-cta-button>
								</div>
							`
    )}
					</div>
				</nav>
				<lit-media-query .query="${this._isMobile}" @changed="${this._handleIsMobile}"></lit-media-query>
				<lit-media-query .query="${this._condensedLarge}" @changed="${this._handleCondensedQuery}"></lit-media-query>
				<lit-media-query .query="${this._isNotMobile}" @changed="${this._handleIsNotMobile}"></lit-media-query>
			</header>
		`;
  }
};
m.styles = Tr`
		${Ye(hs)}
	`;
v([
  y()
], m.prototype, "locale", 1);
v([
  y({ type: Object, converter: X })
], m.prototype, "hygraphLocaleMapping", 2);
v([
  Ir("#mobile-drawer")
], m.prototype, "drawer", 2);
v([
  Ir("#global-header")
], m.prototype, "header", 2);
v([
  W()
], m.prototype, "isMobile", 2);
v([
  W()
], m.prototype, "isCondensedLarge", 2);
v([
  W()
], m.prototype, "isNotMobile", 2);
v([
  y({ type: String })
], m.prototype, "epicSID", 2);
v([
  W()
], m.prototype, "flyoutOpen", 2);
v([
  W()
], m.prototype, "drawerOpen", 2);
v([
  W()
], m.prototype, "drawerInTransition", 2);
v([
  W()
], m.prototype, "submenuOpen", 2);
v([
  y()
], m.prototype, "largeCondensedLabel", 2);
v([
  y({ type: Object })
], m.prototype, "brandStrings", 2);
v([
  y({ type: Object })
], m.prototype, "commonStrings", 2);
v([
  y({ type: Object })
], m.prototype, "navigationFlyout", 2);
v([
  y({ type: String, attribute: !1 })
], m.prototype, "id", 2);
v([
  y()
], m.prototype, "domain", 2);
v([
  y({ type: Object, converter: X })
], m.prototype, "propertyLogo", 2);
v([
  y({ type: Array, converter: X })
], m.prototype, "mainLinks", 2);
v([
  y({ type: Array, converter: X })
], m.prototype, "accountLinks", 2);
v([
  y({ type: Array, converter: X })
], m.prototype, "customAccountLinks", 2);
v([
  y({ type: Array, converter: X })
], m.prototype, "localeOptions", 2);
v([
  y({ type: Array, converter: X })
], m.prototype, "blackListLangCodes", 2);
v([
  y({ type: Object, converter: X })
], m.prototype, "signInLink", 2);
v([
  y({ type: Object, converter: X })
], m.prototype, "signOutLink", 2);
v([
  y()
], m.prototype, "forceActiveMainLinkKey", 2);
v([
  y({ type: Object })
], m.prototype, "platformCtaButton", 1);
v([
  W()
], m.prototype, "activeMainLinkIndex", 2);
v([
  W()
], m.prototype, "moreOpened", 2);
v([
  W()
], m.prototype, "localeMenuOpen", 2);
v([
  W()
], m.prototype, "accountMenuOpen", 2);
v([
  W()
], m.prototype, "searchOpen", 2);
v([
  y({ type: Boolean, converter: U })
], m.prototype, "isLoggedIn", 2);
v([
  y()
], m.prototype, "displayName", 2);
v([
  y({ type: Boolean, converter: U })
], m.prototype, "disableSearch", 2);
v([
  y({ type: Boolean, converter: U })
], m.prototype, "disableLocale", 2);
v([
  y({ type: Boolean, converter: U })
], m.prototype, "disableUser", 2);
v([
  y({ type: Boolean, converter: U })
], m.prototype, "disableCtaButton", 2);
v([
  y({ type: Boolean, converter: U })
], m.prototype, "disableCtaButtonOnMobile", 2);
v([
  y({ type: Number, converter: xr })
], m.prototype, "topOffsetPixels", 2);
v([
  y()
], m.prototype, "langUrlParam", 2);
v([
  y()
], m.prototype, "localeHrefTemplate", 2);
v([
  y()
], m.prototype, "signInLinkHref", 2);
v([
  y()
], m.prototype, "signOutLinkHref", 2);
v([
  y()
], m.prototype, "sticky", 2);
v([
  y({ type: Object, converter: X })
], m.prototype, "accountLinkOverrides", 2);
v([
  y()
], m.prototype, "drawerButtonLabel", 2);
v([
  y()
], m.prototype, "skipNavContentId", 2);
v([
  y()
], m.prototype, "skipNavLabel", 2);
v([
  y({ type: Number, converter: xr })
], m.prototype, "propertyLogoWidth", 2);
m = v([
  zr("epic-wf-navigation")
], m);
export {
  m as N,
  Tr as i,
  Ye as r,
  hs as s,
  zr as t
};
//# sourceMappingURL=navigation-d49b4dd4.mjs.map
