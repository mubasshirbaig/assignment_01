import brandValues from "@wf-components/hygraph-content/dist/content/unrealengine";
import { AllPageData } from "@wf-components/navigation-consumer";
import { css, unsafeCSS } from "lit";
import { customElement } from "lit/decorators.js";

import { Navigation } from "@nav/navigation";
import styles from "@nav/navigation.scss?inline";

@customElement("unrealengine-navigation")
export class UnrealEngineNavigation extends Navigation {
	constructor() {
		super();
		this.allPageData = brandValues as unknown as AllPageData;
		this.domain = "https://www.unrealengine.com";
		this.locale = "en-US";
		this.hygraphLocaleMapping = {
			en: "en-US",
		};
		this.propertyLogoWidth = 233;
	}
	static override styles = css`
		${unsafeCSS(styles)}
	`;
}

declare global {
	interface HTMLElementTagNameMap {
		"unrealengine-navigation": UnrealEngineNavigation;
	}
}
