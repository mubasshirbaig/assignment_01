import { TemplateResult, html } from "lit";

import { Navigation } from "@nav/navigation";

export const flyoutTemplate = ({
	disabled,
	nav,
	validPropertyLogo,
}: {
	disabled?: boolean;
	nav: Navigation;
	validPropertyLogo?: boolean;
}): TemplateResult<1> => {
	return html`
		<div class="global-header__flyout-wrapper ${validPropertyLogo ? "hide-in-drawer" : null}">
			<epic-wf-nav-flyout-menu
				.buttonLabel=${nav.navigationFlyout?.buttonLabel || ""}
				.disabled=${disabled}
				.sections=${nav.navigationFlyout?.sections || []}
				@epic-wf-nav-flyout-toggle=${nav.toggleFlyout}
				open=${nav.flyoutOpen}
			>
			</epic-wf-nav-flyout-menu>
			<epic-wf-bar-icon
				aria-hidden="true"
				class="icon-wrapper ${validPropertyLogo ? "" : "invalid-logo"}"
			></epic-wf-bar-icon>
		</div>
	`;
};
