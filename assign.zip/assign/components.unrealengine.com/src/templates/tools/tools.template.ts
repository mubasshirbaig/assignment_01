import { TemplateResult, html } from "lit";
import { when } from "lit/directives/when.js";

import { Navigation } from "@nav/navigation";
import { accountToolTemplate } from "@nav/templates/tools/account-tool/account-tool.template";
import { localeToolTemplate } from "@nav/templates/tools/locale-tool/locale-tool.template";
import { searchToolTemplate } from "@nav/templates/tools/search-tool/search-tool.template";

import { MouseInteraction } from "./tools.types";

const toolItems = (nav: Navigation): TemplateResult<1> => {
	const accountNavActions: MouseInteraction = {
		onMouseLeave: nav.isMobile ? undefined : nav._mainAccountMenuMouseLeave,
		onMouseOver: nav.isMobile ? undefined : nav._mainAccountMenuMouseOver,
		onClick: nav._mainAccountMenuClick,
	};

	const localeNavActions: MouseInteraction = {
		onMouseLeave: nav.isMobile ? undefined : nav._mainLocaleMenuMouseLeave,
		onMouseOver: nav.isMobile ? undefined : nav._mainLocaleMenuMouseOver,
		onClick: nav._mainLocaleMenuClick,
	};

	return html`
		<div class="tools">
			${when(!nav.disableSearch, () => searchToolTemplate(nav, !nav.disableLocale || !nav.disableUser))}
			${when(!nav.disableLocale, () => localeToolTemplate(nav, localeNavActions))}
			${when(!nav.disableUser, () => accountToolTemplate(nav, accountNavActions))}
		</div>
	`;
};

export const toolsTemplate = (nav: Navigation): TemplateResult<1> => toolItems(nav);
