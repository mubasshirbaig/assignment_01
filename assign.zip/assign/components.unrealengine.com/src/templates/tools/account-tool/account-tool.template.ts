import { convertHrefTemplate } from "@wf-components/navigation-consumer";
import { TemplateResult, html } from "lit";

import "@eds-web/web-components";
import { Navigation } from "@nav/navigation";

import { MouseInteraction } from "../tools.types";

import { accountMenuTemplate } from "./account-menu.template";

const loggedInTemplate = (
	nav: Navigation,
	actionHandler: MouseInteraction,
	id: string,
	avatar: TemplateResult<1>
): TemplateResult<1> => {
	return html`
		<button
			@click=${actionHandler.onClick}
			aria-controls=${id}
			aria-expanded="${nav.accountMenuOpen ? "true" : "false"}"
			aria-label="Account menu"
			class="dropdown__button"
			title=${nav.displayName}
		>
			${avatar}
		</button>
		<div class="friendly-box friendly-box--top"></div>
		<div class="friendly-box friendly-box--wide-adjust" id="nav-account-friendly-box"></div>
		${accountMenuTemplate(nav, id)}
	`;
};

const loggedOutTemplate = (nav: Navigation, id: string, avatar: TemplateResult<1>): TemplateResult<1> => {
	return html`
		<a
			class="dropdown__button"
			@click=${(e: PointerEvent) => {
				nav._mainAccountLinkClick(e, nav.signInLink);
			}}
			href="${convertHrefTemplate({
				domain: nav.domain,
				locale: nav.getMappedHygraphLocale(nav.locale),
				hrefTemplate: nav.signInLinkHref || nav.signInLink?.hrefTemplate,
			})}"
			aria-label="${nav.signInLink?.label || ""}"
		>
			${avatar}
		</a>
		<div class="friendly-box"></div>
		${accountMenuTemplate(nav, id)}
	`;
};

export const accountToolTemplate = (
	nav: Navigation,
	actionHandler: MouseInteraction,
	id: string = "nav-account-menu"
): TemplateResult<1> => {
	if (!nav?.signInLink?.label) {
		return html``;
	}

	const avatar = html`<epic-wf-avatar-icon aria-hidden="true" isLoggedIn=${nav.isLoggedIn}></epic-wf-avatar-icon>`;

	// eslint-disable-next-line lit-a11y/mouse-events-have-key-events
	return html`
		<div
			@mouseleave=${actionHandler.onMouseLeave}
			@mouseover=${actionHandler.onMouseOver}
			class="dropdown dropdown--account ${nav.accountMenuOpen ? "open" : ""}"
		>
			${nav.isLoggedIn ? loggedInTemplate(nav, actionHandler, id, avatar) : loggedOutTemplate(nav, id, avatar)}
		</div>
	`;
};
