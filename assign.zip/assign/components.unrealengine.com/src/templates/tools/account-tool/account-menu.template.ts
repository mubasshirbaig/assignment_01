import { SimpleMenuItemIcon } from "@wf-components/atomic-components";
import { NavCustomAccountLink } from "@wf-components/navigation-consumer";
import { TemplateResult, html } from "lit";
import { ifDefined } from "lit/directives/if-defined.js";

import { Navigation } from "@nav/navigation";

import "@eds-web/web-components";

export const accountMenuTemplate = (nav: Navigation, id: string = "nav-account-menu"): TemplateResult<1> => {
	return html`
		<epic-wf-simple-menu id=${id}>
			<div class="avatar-wrapper">
				${nav.isLoggedIn && nav.displayName
					? html`<eds-avatar label=${nav.displayName} badge size="lg"></eds-avatar>`
					: ""}
			</div>
			${nav.customAccountLinks.map(
				(link) =>
					html`
						<epic-wf-simple-menu-item
							@click=${(e: PointerEvent) => {
								nav._mainAccountLinkClick(e, link);
							}}
							hrefTemplate=${link.hrefTemplate || ""}
							locale=${nav.getMappedHygraphLocale(link.locale || "")}
							label=${link.label || ""}
							icon=${SimpleMenuItemIcon.arrowUpRightSquare}
							labelBeforeStyle=${link.labelBeforeStyle || ""}
							labelAfterStyle=${link.labelAfterStyle || ""}
							labelStyle=${link.labelStyle || ""}
							domain=${nav?.domain || ""}
						></epic-wf-simple-menu-item>
					`
			)}
			${nav.accountLinks.map((link) => {
				const key = link?.key || "";
				const accountLinkOverride = nav.accountLinkOverrides[key] || ({} as NavCustomAccountLink);

				return html`
					<epic-wf-simple-menu-item
						@click=${(e: PointerEvent) => {
							nav._mainAccountLinkClick(e, link);
						}}
						hrefTemplate=${link.hrefTemplate || ""}
						locale=${nav.getMappedHygraphLocale(link.locale || "")}
						label=${link.label || ""}
						icon=${SimpleMenuItemIcon.arrowUpRightSquare}
						domain=${nav?.domain || ""}
						labelStyle=${ifDefined(accountLinkOverride?.labelStyle)}
						labelBeforeStyle=${ifDefined(accountLinkOverride?.labelBeforeStyle)}
						labelAfterStyle=${ifDefined(accountLinkOverride?.labelAfterStyle)}
					></epic-wf-simple-menu-item>
				`;
			})}
			${nav.signOutLink
				? html`
						<epic-wf-simple-menu-item
							@click=${(e: PointerEvent) => {
								nav._mainAccountLinkClick(e, nav.signOutLink);
							}}
							hrefTemplate=${nav.signOutLinkHref || nav.signOutLink.hrefTemplate || ""}
							locale=${nav.getMappedHygraphLocale(nav.signOutLink.locale || "")}
							label=${nav.signOutLink.label || ""}
							icon=${SimpleMenuItemIcon.user}
							domain=${nav?.domain || ""}
						></epic-wf-simple-menu-item>
				  `
				: ""}
		</epic-wf-simple-menu>
	`;
};
