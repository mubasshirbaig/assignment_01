import globeIcon from "@epic-tokens/epic-games-icons/globe-MD.svg?raw";
import { TemplateResult, html } from "lit";
import { unsafeSVG } from "lit-html/directives/unsafe-svg.js";

import { Navigation } from "@nav/navigation";

import { MouseInteraction } from "../tools.types";

import { localeMenuTemplate } from "./locale-menu.template";

export const localeToolTemplate = (
	nav: Navigation,
	actionHandler: MouseInteraction,
	id: string = "nav-locale-menu"
): TemplateResult<1> => {
	// eslint-disable-next-line lit-a11y/mouse-events-have-key-events
	return html`
		<div
			@mouseleave=${actionHandler.onMouseLeave}
			@mouseover=${actionHandler.onMouseOver}
			class="dropdown dropdown--locale ${nav.localeMenuOpen ? "open" : ""}"
		>
			<button
				@click=${actionHandler.onClick}
				aria-controls=${id}
				aria-expanded="${nav.localeMenuOpen ? "true" : "false"}"
				aria-label="Locale menu"
				class="dropdown__button"
			>
				<span aria-hidden="true" class="icon-wrapper">${unsafeSVG(globeIcon)}</span>
			</button>
			<div class="friendly-box friendly-box--top"></div>
			<div class="friendly-box friendly-box--wide-adjust" id="nav-locale-friendly-box"></div>
			${localeMenuTemplate(nav, id)}
		</div>
	`;
};
