import { SimpleMenuItemIcon } from "@wf-components/atomic-components";
import { LocaleOptionFragment } from "@wf-components/hygraph-content";
import { TemplateResult, html } from "lit";
import { ifDefined } from "lit/directives/if-defined.js";

import "@eds-web/web-components";
import { Navigation } from "@nav/navigation";
import { buildSearchQuery, getCurrentUrl } from "@nav/utils/urlUtils";

export const localeMenuTemplate = (nav: Navigation, id: string = "nav-locale-menu"): TemplateResult<1> => {
	return html`
		<epic-wf-simple-menu id=${id}>
			${nav.localeOptions.map((localeOption: LocaleOptionFragment) => {
				const mappedLangCode = nav.getMappedHygraphLocale(localeOption.langCode);
				const mappedNavLocale = nav.getMappedHygraphLocale(nav.locale);
				if (nav.blackListLangCodes && nav.blackListLangCodes.includes(mappedLangCode)) return;

				const currentUrl = getCurrentUrl(nav.domain);
				const isActiveLocale =
					nav.locale === localeOption.langCode ||
					mappedNavLocale === localeOption.langCode ||
					mappedNavLocale.toLowerCase() === localeOption.langCode.toLowerCase();

				const langParam = `${nav.langUrlParam || "lang"}=${mappedLangCode}`;
				const extraParams = [langParam];

				const hrefTemplate = nav.localeHrefTemplate || buildSearchQuery(currentUrl, extraParams, [nav.langUrlParam]);

				return html`
					<epic-wf-simple-menu-item
						@click=${(e: PointerEvent) => {
							nav._localeLinkClick(e, localeOption);
						}}
						hrefTemplate=${ifDefined(isActiveLocale ? undefined : hrefTemplate)}
						icon=${ifDefined(isActiveLocale ? SimpleMenuItemIcon.globe : undefined)}
						noHoverStyle=${isActiveLocale}
						data-show-icon-lg-up="true"
						label=${localeOption.label || ""}
						domain=${nav?.domain || ""}
						locale=${mappedLangCode}
					></epic-wf-simple-menu-item>
				`;
			})}
		</epic-wf-simple-menu>
	`;
};
