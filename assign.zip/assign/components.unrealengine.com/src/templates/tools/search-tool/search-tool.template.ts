import { TemplateResult, html } from "lit";
import { when } from "lit-html/directives/when.js";

import { Navigation } from "@nav/navigation";

export const searchToolTemplate = (nav: Navigation, divider: boolean): TemplateResult<1> => {
	return html`
		<epic-wf-search-box
			mode="normal"
			?opened=${nav.searchOpen}
			@epic-wf-nav-search-activated=${nav.toggleSearch}
			@epic-wf-nav-on-search=${nav._onSearch}
			.activateSearchLabel=${nav.commonStrings?.searchActivateLabel}
			.cancelLabel=${nav.commonStrings?.searchCancelLabel}
			.deactivateSearchLabel=${nav.commonStrings?.searchDeactivateLabel}
			.inputLabel=${nav.brandStrings?.searchInputLabel}
			.placeholderLabel=${nav.commonStrings?.searchPlaceholderLabel}
			.submitLabel=${nav.commonStrings?.searchSubmitLabel}
		></epic-wf-search-box>
		${when(divider, () => html`<epic-wf-bar-icon aria-hidden="true" class="icon-wrapper"></epic-wf-bar-icon>`)}
	`;
};
