import { NavSubnavMenuFragment } from "@wf-components/hygraph-content";
import { TemplateResult, html } from "lit";

import { Navigation } from "@nav/navigation";

import "@eds-web/web-components";

export const subnavMenuTemplate = (nav: Navigation, menu: NavSubnavMenuFragment): TemplateResult<1> => {
	return html`
		<epic-wf-subnav-item-menu
			.cardLinks=${menu?.cardLinks || []}
			.descLinks=${menu?.descLinks || []}
			.links=${menu?.links || []}
			.onLinkClick=${nav._navLinkClick.bind(nav)}
			.getMappedHygraphLocale=${nav.getMappedHygraphLocale.bind(nav)}
			description=${menu?.description || ""}
			itemTitle=${menu?.itemTitle || ""}
			domain=${nav?.domain || ""}
		></epic-wf-subnav-item-menu>
	`;
};
