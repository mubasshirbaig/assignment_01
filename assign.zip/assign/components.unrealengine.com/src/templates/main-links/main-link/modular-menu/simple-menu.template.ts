import { NavLinkFragment, NavSimpleMenuFragment } from "@wf-components/hygraph-content";
import { TemplateResult, html } from "lit";

import { Navigation } from "@nav/navigation";

import "@eds-web/web-components";

export const simpleMenuTemplate = (nav: Navigation, menu: NavSimpleMenuFragment): TemplateResult<1> => {
	return html`
		<epic-wf-simple-menu>
			${menu?.links.map(
				(link) =>
					html`
						<epic-wf-simple-menu-item
							@click=${(e: PointerEvent) => nav._navLinkClick(e, link as NavLinkFragment)}
							hrefTemplate=${link.hrefTemplate || ""}
							locale=${nav.getMappedHygraphLocale(link.locale || "")}
							label=${link.label || ""}
							domain=${nav?.domain || ""}
						></epic-wf-simple-menu-item>
					`
			)}
		</epic-wf-simple-menu>
	`;
};
