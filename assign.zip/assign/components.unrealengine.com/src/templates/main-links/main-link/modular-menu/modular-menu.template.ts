import { NavModularMenuFragment } from "@wf-components/hygraph-content";
import { TemplateResult, html } from "lit";

import { Navigation } from "@nav/navigation";

import { simpleMenuTemplate } from "./simple-menu.template";
import { subnavMenuTemplate } from "./subnav-menu.template";

export const modularMenuTemplate = (nav: Navigation, menu: NavModularMenuFragment): TemplateResult<1> => {
	const isSimpleMenu = menu?.__typename === "NavSimpleMenu";
	return html`${isSimpleMenu ? simpleMenuTemplate(nav, menu) : subnavMenuTemplate(nav, menu)} `;
};
