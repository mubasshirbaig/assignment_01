import { isTouch } from "@wf-components/atomic-components";
import { NavMainLinkFragment } from "@wf-components/hygraph-content";
import { DIR } from "@wf-components/navigation-consumer";
import { TemplateResult, html } from "lit";

import { Navigation } from "@nav/navigation";
import { ShadowMainLink, Trigger, TriggerSibling } from "@nav/utils/focusTrapUtils";

function onSubmenu(evt: PointerEvent | KeyboardEvent, opened: boolean, onClose: () => void, nav: Navigation): void {
	if (opened) {
		if (evt.type === "click") {
			// Trap focus only when user do a click (mouse / keyboard)
			nav._trapSubFocus(
				evt,
				TriggerSibling,
				Trigger,
				evt.target as HTMLElement,
				() => nav._untrapSubFocus(),
				(evt: KeyboardEvent) => {
					evt.preventDefault();
					evt.stopImmediatePropagation();
					onClose();
				}
			);
		} else if (nav._isSubFocusTrapped) {
			// Another submenu is opened, sends the focus back to the condensed menu
			nav._untrapSubFocus();
		}
	} else {
		// Submenu closed, untrap any focus
		nav._untrapSubFocus();
	}
}

export const mainLinkCondensedTemplate = (
	nav: Navigation,
	condensedLinks: NavMainLinkFragment[],
	forceActiveStyle: boolean
): TemplateResult<1> => {
	const handleClick = (evt: PointerEvent): void => {
		const current = nav.moreOpened;
		nav.closeMenusAndInput();
		nav.moreOpened = !current;

		if (nav.moreOpened) {
			nav._trapFocus(evt, TriggerSibling, ShadowMainLink, () => {});
		} else {
			nav._untrapFocus();
		}
	};

	const handlePointerEnter = (e: PointerEvent): void => {
		if (!isTouch(e)) {
			nav.closeMenusAndInput();
			nav.moreOpened = true;
		}
	};

	const handlePointerLeave = (e: PointerEvent): void => {
		if (!isTouch(e)) {
			nav._untrapFocus();
			nav.moreOpened = false;
		}
	};

	// eslint-disable-next-line lit-a11y/mouse-events-have-key-events
	return html`
		<li
			@pointerenter=${handlePointerEnter}
			@pointerleave=${handlePointerLeave}
			class="main-nav__list-item main-nav__list-item--condensed"
		>
			<epic-wf-main-link
				.rtl=${nav.dir === DIR.RTL}
				@click=${handleClick}
				active=${nav.moreOpened}
				forceActiveStyle=${nav.activeMainLinkIndex === -1 && forceActiveStyle}
				hasMenu=${true}
				label=${nav?.largeCondensedLabel || ""}
				domain=${nav?.domain || ""}
				locale=${nav.getMappedHygraphLocale(nav.locale)}
			>
				<div class="friendly-box friendly-box--wide"></div>
			</epic-wf-main-link>
			<epic-wf-condensed-menu
				.getMappedHygraphLocale=${nav.getMappedHygraphLocale.bind(nav)}
				.mainLinks=${condensedLinks || []}
				.onLinkClick=${nav._navLinkClick.bind(nav)}
				.onSubmenu=${(evt: PointerEvent, opened: boolean, onClose: () => void) => onSubmenu(evt, opened, onClose, nav)}
				.rtl=${nav.dir === DIR.RTL}
				domain=${nav?.domain || ""}
				locale=${nav.getMappedHygraphLocale(nav.locale)}
			></epic-wf-condensed-menu>
		</li>
	`;
};
