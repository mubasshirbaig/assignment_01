import { NavMainLinkFragment } from "@wf-components/hygraph-content";
import { convertHrefTemplate } from "@wf-components/navigation-consumer";

import { getCurrentUrl } from "../../../utils/urlUtils";

export const isRoughlyEqual = (currentUrl: URL | null, href: string): boolean => {
	if (!currentUrl || !href) return false;

	let linkUrl: URL | null = null;
	try {
		if (href.indexOf("http") === 0) {
			linkUrl = new URL(href);
		} else if (href.indexOf("/") === 0) {
			linkUrl = new URL(`${currentUrl.origin}${href}`);
		}
	} catch (e) {
		console.warn("isRoughlyEqual() Failed to parse the href and compare to current URL", e);
		return false;
	}

	if (currentUrl && linkUrl && currentUrl.origin === linkUrl.origin && currentUrl.pathname === linkUrl.pathname) {
		return true;
	}

	return false;
};

export const isParentOrChildrenActive = (domain: string, locale: string, mainLink: NavMainLinkFragment): boolean => {
	const currentUrl = getCurrentUrl(domain);
	if (mainLink.hrefTemplate) {
		const parentHref = convertHrefTemplate({
			domain,
			locale,
			hrefTemplate: mainLink.hrefTemplate,
		});
		if (parentHref) {
			const isParentActive = isRoughlyEqual(currentUrl, parentHref);
			if (isParentActive) {
				return true;
			}
		}
	}
	if (mainLink?.menu?.__typename === "NavSimpleMenu" && mainLink.menu?.links?.length) {
		for (let i = 0; i < mainLink.menu.links.length; i++) {
			const link = mainLink.menu.links[i];
			const href = convertHrefTemplate({
				domain,
				locale,
				hrefTemplate: link.hrefTemplate,
			});
			const isActive = isRoughlyEqual(currentUrl, href);
			if (isActive) {
				return true;
			}
		}
	}

	if (mainLink?.menu?.__typename === "NavSubnavMenu" && mainLink.menu?.links?.length) {
		for (let i = 0; i < mainLink.menu.links.length; i++) {
			const link = mainLink.menu.links[i];
			const href = convertHrefTemplate({
				domain,
				locale,
				hrefTemplate: link.hrefTemplate,
			});
			const isActive = isRoughlyEqual(currentUrl, href);
			if (isActive) {
				return true;
			}
		}
		for (let i = 0; i < mainLink.menu.descLinks.length; i++) {
			const link = mainLink.menu.descLinks[i];
			const href = convertHrefTemplate({
				domain,
				locale,
				hrefTemplate: link.hrefTemplate,
			});
			const isActive = isRoughlyEqual(currentUrl, href);
			if (isActive) {
				return true;
			}
		}
		for (let i = 0; i < mainLink.menu.cardLinks.length; i++) {
			const link = mainLink.menu.cardLinks[i];
			const href = convertHrefTemplate({
				domain,
				locale,
				hrefTemplate: link.hrefTemplate,
			});
			const isActive = isRoughlyEqual(currentUrl, href);
			if (isActive) {
				return true;
			}
		}
	}

	return false;
};
