/* eslint-disable lit-a11y/mouse-events-have-key-events */
import { isTouch } from "@wf-components/atomic-components";
import { NavLinkFragment, NavMainLinkFragment } from "@wf-components/hygraph-content";
import { DIR } from "@wf-components/navigation-consumer";
import { TemplateResult, html } from "lit";

import { Navigation } from "@nav/navigation";

import { ShadowMainLink, TriggerSibling } from "../../../utils/focusTrapUtils";

import { modularMenuTemplate } from "./modular-menu/modular-menu.template";

//used to flag touch on Safari and FF since pointerType is not set on click events
let isTouchEvent = false;

export const mainLinkTemplate = (
	nav: Navigation,
	mainLink: NavMainLinkFragment,
	i: number,
	forceActiveStyle: boolean
): TemplateResult<1> => {
	const validMenu = Boolean(mainLink?.menu && mainLink?.menu?.links?.length);

	const handleClick = (e: PointerEvent, i: number): void => {
		// if there's no submenu, we can assume it's just a link and can return early,
		// closing the drawer if it's open (in case client-side routing is being used)
		if (!validMenu) {
			return nav._navLinkClick(e, mainLink as NavLinkFragment);
		}

		// otherwise, if there's a submenu AND an href...
		if (mainLink.hrefTemplate) {
			// prevent navigation so that the menu can open on either:
			// 1. touch (determined via pointerType) or by detecting touchend
			// 2. our "mobile" screen sizes (where the menus are not visible on hover)
			if (isTouch(e) || isTouchEvent || nav.isMobile) {
				e.preventDefault();
			}

			// otherwise we can assume it's a mouse click on our desktop screen sizes,
			// and we just want the click to navigate to the href (no need to close menus)
			else {
				return nav._navLinkClick(e, mainLink as NavLinkFragment);
			}
		}

		// we want to close the other dropdowns and search,
		// but we want to be careful not to close the menu we just opened
		nav.closeDropdownsAndSearch();

		// open the menu, otherwise close it
		nav.activeMainLinkIndex === i ? (nav.activeMainLinkIndex = -1) : (nav.activeMainLinkIndex = i);

		//reset the touch flag
		isTouchEvent = false;
	};

	const handlePointerEnter = (e: PointerEvent, index: number): void => {
		if (!isTouch(e)) {
			nav.activeMainLinkIndex = index;

			if (validMenu) {
				nav.closeDropdownsAndSearch();
				nav._untrapFocus();
			}
		}
	};

	const handlePointerLeave = (e: PointerEvent): void => {
		if (!isTouch(e)) {
			nav.activeMainLinkIndex = -1;
		}
	};

	const handleKeyDown = (e: KeyboardEvent, index: number): void => {
		if (e.code === "Enter" || e.code === "Space") {
			e.preventDefault();
			if (nav.activeMainLinkIndex === index) {
				nav.closeMenusAndInput();
				if (nav.drawerOpen) {
					nav._untrapSubFocus();
				} else {
					nav._untrapFocus();
				}
			} else {
				nav.closeDropdownsAndSearch();
				nav.activeMainLinkIndex = index;
				if (nav.drawerOpen) {
					nav._trapSubFocus(
						e,
						TriggerSibling,
						ShadowMainLink,
						e.target as HTMLElement,
						() => nav._untrapSubFocus(),
						(evt: KeyboardEvent) => {
							evt.preventDefault();
							evt.stopImmediatePropagation();
							nav._backClick();
						}
					);
				} else {
					nav._trapFocus(e, TriggerSibling, ShadowMainLink);
				}
			}
		}
	};

	return html`
		<li
			@pointerenter=${!nav.isMobile ? (e: PointerEvent) => handlePointerEnter(e, i) : null}
			@pointerleave=${!nav.isMobile ? (e: PointerEvent) => handlePointerLeave(e) : null}
			class="main-nav__list-item"
			id="epic-wf-nav-main-link-${i}"
		>
			<epic-wf-main-link
				.rtl=${nav.dir === DIR.RTL}
				@click=${(e: PointerEvent) => handleClick(e, i)}
				@touchend=${() => (isTouchEvent = true)}
				@keydown=${validMenu ? (e: KeyboardEvent) => handleKeyDown(e, i) : null}
				active=${nav.activeMainLinkIndex === i}
				forceActiveStyle=${nav.activeMainLinkIndex === -1 && forceActiveStyle}
				hasMenu=${validMenu}
				hrefTemplate=${mainLink?.hrefTemplate || ""}
				key=${mainLink?.key || ""}
				label=${mainLink?.label || ""}
				locale=${nav.getMappedHygraphLocale(mainLink?.locale || "")}
				domain=${nav?.domain || ""}
				owner=${mainLink?.owner || ""}
			>
				${validMenu ? html`<div class="friendly-box friendly-box--wide"></div>` : ""}
			</epic-wf-main-link>
			${validMenu ? mainLink.menu && modularMenuTemplate(nav, mainLink.menu) : ""}
		</li>
	`;
};
