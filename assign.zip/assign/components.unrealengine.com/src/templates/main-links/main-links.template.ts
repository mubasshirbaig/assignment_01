import { NavMainLinkFragment } from "@wf-components/hygraph-content";
import { TemplateResult } from "lit";

import { Navigation } from "@nav/navigation";

import { mainLinkCondensedTemplate } from "./main-link/main-link-condensed.template";
import { isParentOrChildrenActive } from "./main-link/main-link-forced.utils";
import { mainLinkTemplate } from "./main-link/main-link.template";

export const mainLinksTemplate = (nav: Navigation): TemplateResult<1>[] => {
	const isCollapsed = Boolean(!nav.drawerOpen && !nav.isMobile && nav.isCondensedLarge && nav.largeCondensedLabel);

	const originalLinks = nav.mainLinks;
	let finalMainLinks = originalLinks;
	let modifiedMainLinks: NavMainLinkFragment[] = [];
	let condensedLinks: NavMainLinkFragment[] = [];

	if (isCollapsed) {
		condensedLinks = originalLinks.filter((link) => link.collapsible);
		modifiedMainLinks = originalLinks.filter((link) => !link.collapsible);
		if (condensedLinks.length > 1) {
			finalMainLinks = modifiedMainLinks;
		}
	}

	const mainLinksEl = finalMainLinks.map((mainLink, i) => {
		const forceActiveStyle =
			(nav.forceActiveMainLinkKey && nav.forceActiveMainLinkKey === mainLink.key) ||
			isParentOrChildrenActive(nav.domain, nav.locale, mainLink);
		return mainLinkTemplate(nav, mainLink, i, forceActiveStyle);
	});

	if (isCollapsed && condensedLinks.length > 1) {
		let forceActiveStyle = false;
		for (let i = 0; i < condensedLinks.length; i++) {
			const mainLink = condensedLinks[i];
			forceActiveStyle = Boolean(nav.forceActiveMainLinkKey && nav.forceActiveMainLinkKey === mainLink.key);
			if (forceActiveStyle) {
				break;
			}
			const active = isParentOrChildrenActive(nav.domain, nav.locale, mainLink);
			if (active) {
				forceActiveStyle = true;
				break;
			}
		}

		mainLinksEl.push(mainLinkCondensedTemplate(nav, condensedLinks, forceActiveStyle));
	}

	return mainLinksEl;
};
