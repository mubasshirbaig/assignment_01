import chevronLeftIcon from "@epic-tokens/epic-games-icons/chevron-left-SM.svg?raw";
import chevronRightIcon from "@epic-tokens/epic-games-icons/chevron-right-SM.svg?raw";
import linesHorizontal from "@epic-tokens/epic-games-icons/lines-horizontal-MD.svg?raw";
import xMark from "@epic-tokens/epic-games-icons/x-mark-MD.svg?raw";
import { booleanConverter, jsonConverter, numberConverter } from "@wf-components/atomic-components";
import {
	CommonStringsFragment,
	Locale,
	LocaleOptionFragment,
	LogoFragment,
	NavBrandStringsFragment,
	NavLinkFragment,
	NavMainLinkFragment,
	NavPlatformAwareLinkFragment,
	NavPropertyLogoFragment,
	NavigationFlyoutFragment,
} from "@wf-components/hygraph-content";
import {
	CONSUMER_EVENTS,
	DIR,
	HygraphLocaleMapping,
	MappedLocaleOptionFragment,
	NavAccountLinkClickEvent,
	NavCtaClickEvent,
	NavCustomAccountLink,
	NavDrawerToggleEvent,
	NavLinkClickEvent,
	NavLocaleClickEvent,
	NavPropertyLogoClickEvent,
	NavSearchActivateEvent,
	convertHrefTemplate,
	AllPageData,
	AccountLinkOverrides,
} from "@wf-components/navigation-consumer";
import { LitElement, TemplateResult, css, html, unsafeCSS } from "lit";
import { customElement, property, query, state } from "lit/decorators.js";
import { when } from "lit/directives/when.js";
import { unsafeSVG } from "lit-html/directives/unsafe-svg.js";
import { getCookie } from "typescript-cookie";

import { flyoutTemplate } from "@nav/templates/flyout/flyout.template";
import { mainLinksTemplate } from "@nav/templates/main-links/main-links.template";
import { toolsTemplate } from "@nav/templates/tools/tools.template";

import "@wf-components/atomic-components";
import "epic-lit-media-query/lit-media-query.js";
import styles from "./navigation.scss?inline";
import { LitMediaQueryEvent } from "./navigation.types";
import { appendStyleTag, toggleBodyClass } from "./utils/bodyUtils";
import { runSimpleMenuOverflowAdjustment } from "./utils/flyoutUtils";
import {
	FocusTrapper,
	OriginalFocusProvider,
	TrapContainerProvider,
	Trigger,
	TriggerSibling,
} from "./utils/focusTrapUtils";
import { isLangRtl } from "./utils/localeUtils";
import { getMainLinks } from "./utils/mainLinkUtils";
import { getPlatformAwareHref } from "./utils/navigationUtils";

const globalReverseLocaleMappings: { [key: string]: string } = {
	"zh-hans": "zh-CN",
	"zh-hant": "zh-TW",
};

@customElement("epic-wf-navigation")
export class Navigation extends LitElement {
	static override styles = css`
		${unsafeCSS(styles)}
	`;

	protected allPageData = {} as AllPageData;
	private _locale = "";

	/**
	 * Used to track if the window's history pushState and replaceState has been updated
	 */
	private _historyReplaced = false;

	override connectedCallback(): void {
		super.connectedCallback();

		/**
		 * If a consumer updates the history with a client side route, the active parent link
		 * might need to be updated.
		 *
		 * Here we replace the history functions in order to re-render the nav
		 */
		if (window && window.history && !this._historyReplaced) {
			const originalPushState = window.history.pushState;
			history.pushState = (...args) => {
				originalPushState.apply(window.history, args);
				this.requestUpdate();
			};
			const originalReplaceState = window.history.replaceState;
			history.replaceState = (...args) => {
				originalReplaceState.apply(window.history, args);
				this.requestUpdate();
			};
			this._historyReplaced = true;
		}
		addEventListener("click", this._bodyClick.bind(this));

		//hide horizontal scrollbar on the page until we can adjust simple menu overflow
		const overflowX: string | null = document.body.style.getPropertyValue("overflow-x");
		document.body.style.setProperty("overflow-x", "hidden");
		let overflowAdjusted = true;

		const resetOverflow = (): void => {
			if (overflowAdjusted) {
				this._adjustOverflow(true);
				overflowAdjusted = false;
				//re-apply the initial horizontal overflow value :homer:
				setTimeout(() => {
					document.body.style.setProperty("overflow-x", overflowX);
				}, 100);
			}
		};

		//when the fonts load the adjustment needs to be recalculated as widths will change
		document.fonts.onloadingdone = resetOverflow;
		// catch all in case the browser doesn't support the fonts.onloadingdone event (safari)
		setTimeout(resetOverflow, 1500);

		appendStyleTag();
	}

	override disconnectedCallback(): void {
		super.disconnectedCallback();
		removeEventListener("click", this._bodyClick.bind(this));
	}

	_adjustOverflow(force: boolean = false): void {
		runSimpleMenuOverflowAdjustment(this.shadowRoot, {
			isMobile: this.isMobile,
			drawerOpen: this.drawerOpen,
			force,
		});
	}

	_bodyClick(event: MouseEvent): void {
		const shadow = this.shadowRoot;
		if (shadow) {
			const clickInside = event.composedPath().includes(shadow);
			if (!clickInside) {
				if (this.accountMenuOpen || this.flyoutOpen || this.localeMenuOpen || this.moreOpened) {
					this.closeMenusAndInput();
				}
			}
		}
	}

	_onSearch(_evt: CustomEvent): void {
		if (this.drawerOpen) {
			this.closeDrawer();
			this._untrapFocus();
		}
	}

	getReverseLocale(locale: string): string | undefined {
		if (!locale) return undefined;
		/**
		 * flip the hygraph mapping from key: value to value: key
		 */
		const reverseMapping = Object.fromEntries(
			Object.entries(this.hygraphLocaleMapping || {}).map((a) => {
				const one = (a[1] as string) || "";
				return [one?.toLowerCase() || one, a[0]];
			})
		);

		const reversedLocale = reverseMapping[locale.toLowerCase()];
		if (!reversedLocale) {
			return globalReverseLocaleMappings[locale.toLowerCase()];
		}

		return reversedLocale;
	}

	set locale(newLoc: string) {
		const reverseLocale = this.getReverseLocale(newLoc);
		const reverseNewLoc = reverseLocale || newLoc;
		const oldValue = this._locale;

		this._locale = reverseNewLoc;
		if (oldValue !== reverseNewLoc) {
			this.updatePropertyValues(reverseNewLoc);
		}
		this.requestUpdate("locale", oldValue);
	}

	@property()
	get locale(): string {
		return this._locale;
	}

	/**
	 * Set by brand but can be overridden by attribute to use a different locale code in links than the locale code set in Hygraph.
	 * i.e. Hygraph defaults to en but some apps might use en-US instead.
	 * {en: 'en-US}
	 */
	@property({ type: Object, converter: jsonConverter })
	hygraphLocaleMapping = {} as HygraphLocaleMapping;

	getMappedHygraphLocale(locale: string | Locale): string {
		if (this.hygraphLocaleMapping && typeof this.hygraphLocaleMapping[locale] !== "undefined") {
			return this.hygraphLocaleMapping[locale];
		}

		return locale;
	}

	private async updatePropertyValues(locale: string): Promise<void> {
		const snakeCaseLocale = locale.replace(/-/g, "_");

		const source = this.allPageData?.[snakeCaseLocale];
		if (source) {
			Object.assign(this, source);
		} else if (this.allPageData?.en) {
			//default to en
			Object.assign(this, this.allPageData?.en);
		}
	}

	@query("#mobile-drawer")
	drawer!: HTMLDivElement;

	@query("#global-header")
	header!: HTMLHeadElement;

	@state()
	isMobile: boolean = false;
	_isMobile = "(max-width: 1279.9px)";
	private _handleIsMobile(event: CustomEvent<LitMediaQueryEvent>): void {
		this.isMobile = event?.detail?.value || false;

		// when the screen size falls below the mobile breakpoint,
		// hide the drawer temporarily to prevent the transition from being visible
		if (this.isMobile) {
			this.drawer.style.setProperty("display", "none");
			setTimeout(() => {
				this.drawer.style.setProperty("display", "");
			}, 0.4);
		}

		//going between mobile states could effect positioning
		this._adjustOverflow();
	}

	@state()
	isCondensedLarge: boolean = false;
	_condensedLarge = "(min-width: 1280px) and (max-width: 1439.9px)";
	private _handleCondensedQuery(event: CustomEvent<LitMediaQueryEvent>): void {
		this.isCondensedLarge = event?.detail?.value || false;
	}

	@state()
	isNotMobile: boolean = true;
	_isNotMobile = "(min-width: 1280px)";
	private _handleIsNotMobile(event: CustomEvent<LitMediaQueryEvent>): void {
		this.isNotMobile = event?.detail?.value || false;
		this.closeDrawer();
	}

	@property({ type: String })
	epicSID: string | void = getCookie("_epicSID");

	@state()
	flyoutOpen: boolean = false;

	@state()
	drawerOpen: boolean = false;

	@state()
	drawerInTransition: boolean = false;

	@state()
	submenuOpen: boolean = false;

	@property()
	largeCondensedLabel = "";

	@property({ type: Object })
	brandStrings = {} as NavBrandStringsFragment | undefined | null;

	@property({ type: Object })
	commonStrings = {} as CommonStringsFragment | undefined | null;

	@property({ type: Object })
	navigationFlyout = {} as NavigationFlyoutFragment | undefined | null;

	/**
	 * Set to clear the hygraph id field from being set as an attribute
	 */
	@property({ type: String, attribute: false })
	override id = "";

	/**
	 * Set by brand but can be overridden by attribute when running on a non-prod environment.
	 * This value is used in the hrefTemplate string replacement for {domain}
	 */
	@property()
	domain = "";

	/**
	 * Set by brand but can be overridden by attribute to customize the propertyLogo.
	 */
	@property({ type: Object, converter: jsonConverter })
	propertyLogo = {} as NavPropertyLogoFragment | undefined | null;

	/**
	 * Set by brand but can be overridden by attribute to customize the mainLinks.
	 */
	@property({ type: Array, converter: jsonConverter })
	mainLinks = new Array<NavMainLinkFragment>();

	/**
	 * Set by brand but can be overridden by attribute to customize the accountLinks.
	 */
	@property({ type: Array, converter: jsonConverter })
	accountLinks = new Array<NavLinkFragment>();

	/**
	 * An optional but available override to prepend the accountLinks with additional links.
	 * i.e. An app wants to place a theme toggle or do something that is dependent on entitlement
	 */
	@property({ type: Array, converter: jsonConverter })
	customAccountLinks = new Array<NavCustomAccountLink>();

	/**
	 * Set by brand but can be overridden by attribute to customize the localeOptions.
	 */
	@property({ type: Array, converter: jsonConverter })
	localeOptions = new Array<MappedLocaleOptionFragment>();

	/**
	 * Set by consumers to omit specific lang codes in their application.
	 * This can be used if a particular consumer doesn't want all of the locale options
	 */
	@property({ type: Array, converter: jsonConverter })
	blackListLangCodes = new Array<string>();

	/**
	 * Set by brand but can be overridden by attribute to customize the signInLink.
	 */
	@property({ type: Object, converter: jsonConverter })
	signInLink = {} as NavLinkFragment | undefined | null;

	/**
	 * Set by brand but can be overridden by attribute to customize the signOutLink.
	 */
	@property({ type: Object, converter: jsonConverter })
	signOutLink = {} as NavLinkFragment | undefined | null;

	/**
	 * An optional but available override to set which parent main link should show as active.
	 * i.e. A app could decide on a certain path that the first main link should show as active
	 */
	@property()
	forceActiveMainLinkKey = "";

	private _platformCtaButton = {} as NavPlatformAwareLinkFragment | undefined | null;

	set platformCtaButton(newLink: NavPlatformAwareLinkFragment) {
		const oldValue = this._platformCtaButton;
		this._platformCtaButton = {
			...newLink,
		};
		this.requestUpdate("platformCtaButton", oldValue);
	}

	@property({ type: Object })
	get platformCtaButton(): NavPlatformAwareLinkFragment | undefined | null {
		return this._platformCtaButton;
	}

	@state()
	activeMainLinkIndex = -1;

	@state()
	moreOpened = false;

	@state()
	localeMenuOpen = false;

	@state()
	accountMenuOpen = false;

	@state()
	searchOpen = false;

	/**
	 * Set by attribute to toggle between logged in and out account menus.
	 */
	@property({ type: Boolean, converter: booleanConverter })
	isLoggedIn = false;

	/**
	 * Set by attribute to show the user's displayName where applicable
	 */
	@property()
	displayName = "";

	/**
	 * Set by attribute to disable the search features
	 */
	@property({ type: Boolean, converter: booleanConverter })
	disableSearch = false;

	/**
	 * Set by attribute to disable the locale features
	 */
	@property({ type: Boolean, converter: booleanConverter })
	disableLocale = false;

	/**
	 * Set by attribute to disable the epic user features
	 */
	@property({ type: Boolean, converter: booleanConverter })
	disableUser = false;

	/**
	 * Set by attribute to disable the CTA button
	 */
	@property({ type: Boolean, converter: booleanConverter })
	disableCtaButton = false;

	/**
	 * Set by attribute to disable the CTA button only on < lg breakpoints
	 */
	@property({ type: Boolean, converter: booleanConverter })
	disableCtaButtonOnMobile = false;

	/**
	 * Set by attribute to allow the nav to calculate its distance from the top edge of the browser
	 * i.e. An app needs to render an alert above the nav. In order to render properly this attribute should be used.
	 */
	@property({ type: Number, converter: numberConverter })
	topOffsetPixels = 0;

	/**
	 * Set by attribute to update the URL when the language is selected.
	 * i.e. /features?lang=en-US
	 */
	@property()
	langUrlParam = "lang";

	/**
	 * Override for locale links. Supports {locale} and {domain} replacements
	 */
	@property()
	localeHrefTemplate = "";

	/**
	 * Set by attribute to override the signInLink href.
	 * Can be useful to include query params a particular consumer might need
	 */
	@property()
	signInLinkHref = "";

	/**
	 * Set by attribute to override the signInLink href.
	 * Can be useful to include query params a particular consumer might need
	 */
	@property()
	signOutLinkHref = "";

	/**
	 * Force the navigation to always show at the top of the page. Only applies when equal to "true".
	 * Purposefully left as string to keep the attribute set on the host tag
	 */
	@property()
	sticky = "";

	/**
	 * Append styles to specific account links by key
	 */
	@property({ type: Object, converter: jsonConverter })
	accountLinkOverrides = {} as AccountLinkOverrides;

	@property()
	drawerButtonLabel = "Menu";

	@property()
	skipNavContentId = "";

	@property()
	skipNavLabel = "Skip to main content";

	@property({ type: Number, converter: numberConverter })
	propertyLogoWidth = 0;

	private _focusTrap = new FocusTrapper();
	private _subFocusTrap = new FocusTrapper();

	public getMainLinks(): NavMainLinkFragment[] {
		return getMainLinks(this.mainLinks, this.domain, this.locale);
	}

	public closeDropdowns(): void {
		this.accountMenuOpen = false;
		this.flyoutOpen = false;
		this.localeMenuOpen = false;
		this.moreOpened = false;
	}

	public closeSearch(): void {
		this.searchOpen = false;
	}

	public closeMainLinkMenus(): void {
		this.activeMainLinkIndex = -1;
	}

	public closeDropdownsAndSearch(): void {
		this.closeDropdowns();
		this.closeSearch();
	}

	public closeMenusAndInput(): void {
		this.closeDropdownsAndSearch();
		this.closeMainLinkMenus();
	}

	public closeDrawer(): void {
		this.drawerOpen = false;
		this._adjustOverflow();
		this.dispatchEvent(
			new CustomEvent<NavDrawerToggleEvent>(CONSUMER_EVENTS.DRAWER_TOGGLE, {
				detail: { opened: false },
				bubbles: true,
				composed: true,
			})
		);
	}

	public closeAll(): void {
		this.closeDrawer();
		this.closeMenusAndInput();
	}

	public toggleDrawer(evt: PointerEvent): void {
		if (!this.drawerInTransition) {
			this.drawerOpen = !this.drawerOpen;
		}
		this.drawerInTransition = true;

		this._adjustOverflow();

		if (this.drawerOpen) {
			this.closeMenusAndInput();
			this._trapFocus(evt, TriggerSibling, Trigger);
		} else {
			this._untrapFocus();
		}

		this.dispatchEvent(
			new CustomEvent<NavDrawerToggleEvent>(CONSUMER_EVENTS.DRAWER_TOGGLE, {
				detail: { opened: this.drawerOpen },
				bubbles: true,
				composed: true,
			})
		);
	}

	public toggleFlyout(e: CustomEvent): void {
		const current = this.flyoutOpen;
		this.closeMenusAndInput();
		this.flyoutOpen = !current;

		if (!current) {
			const navFlyoutMenu = e.target as HTMLElement;
			if (navFlyoutMenu && navFlyoutMenu.shadowRoot) {
				const shadow = navFlyoutMenu.shadowRoot;
				const flyoutToggle = shadow.querySelector<HTMLElement>("#nav-flyout-toggle");
				const flyoutMenu = shadow.querySelector<HTMLElement>("#nav-flyout-menu");

				if (flyoutToggle && flyoutMenu) {
					this._trapFocus(
						e,
						() => flyoutMenu,
						() => flyoutToggle,
						() => this._untrapFocus()
					);
				}
			}
		} else {
			this._untrapFocus();
		}
	}

	public toggleSearch(e: CustomEvent<NavSearchActivateEvent>): void {
		this.closeMenusAndInput();
		if (e?.detail) {
			this.searchOpen = e.detail?.activated || false;
			if (this.drawerOpen) {
				if (this.searchOpen) {
					const composedPath = e.composedPath();
					if (composedPath.length > 0) {
						const searchBox = composedPath[0] as HTMLElement;
						this._trapSubFocus(
							e,
							(_trigger) => searchBox,
							() => searchBox,
							searchBox,
							() => {},
							(_evt) => {}
						);
					}
				} else {
					this._untrapSubFocus();
				}
			}
		}
	}

	_handleEscape(e: KeyboardEvent): void {
		if (e.key === "Escape") {
			if (
				this.accountMenuOpen ||
				this.activeMainLinkIndex > -1 ||
				this.flyoutOpen ||
				this.localeMenuOpen ||
				this.moreOpened ||
				this.searchOpen
			) {
				this.closeMenusAndInput();
			} else {
				this.closeDrawer();
			}
		}
	}

	_navLinkClick(e: PointerEvent, link: NavLinkFragment, disableCloseAll?: boolean): void {
		if (!disableCloseAll) this.closeAll();
		if (link) {
			if (link.hrefTemplate) {
				link.hrefTemplate = convertHrefTemplate({
					domain: this.domain,
					locale: this.getMappedHygraphLocale(this.locale),
					hrefTemplate: link.hrefTemplate,
				});
			}
			this.dispatchEvent(
				new CustomEvent<NavLinkClickEvent>(CONSUMER_EVENTS.NAV_LINK_CLICK, {
					detail: { originalEvent: e, link },
					bubbles: true,
					composed: true,
				})
			);
		}
	}

	_localeLinkClick(e: PointerEvent, link: LocaleOptionFragment): void {
		this.closeAll();
		if (link) {
			const mappedLangCode = this.getMappedHygraphLocale(link.langCode);
			this.dispatchEvent(
				new CustomEvent<NavLocaleClickEvent>(CONSUMER_EVENTS.LOCALE_LINK_CLICK, {
					detail: { originalEvent: e, link: { ...link, mappedLangCode } },
					bubbles: true,
					composed: true,
				})
			);
		}
	}
	_mainLogoClick(e: PointerEvent, link: NavPropertyLogoFragment | null | undefined): void {
		this.closeAll();
		if (link) {
			if (link.hrefTemplate) {
				link.hrefTemplate = convertHrefTemplate({
					domain: this.domain,
					locale: this.getMappedHygraphLocale(this.locale),
					hrefTemplate: link.hrefTemplate,
				});
			}
			this.dispatchEvent(
				new CustomEvent<NavPropertyLogoClickEvent>(CONSUMER_EVENTS.PROPERTY_LOGO_CLICK, {
					detail: { originalEvent: e, link },
					bubbles: true,
					composed: true,
				})
			);
		}
	}
	_mainAccountLinkClick(e: PointerEvent, link: NavLinkFragment | NavCustomAccountLink | null | undefined): void {
		this.closeAll();
		if (link) {
			if (link.hrefTemplate) {
				link.hrefTemplate = convertHrefTemplate({
					domain: this.domain,
					locale: this.getMappedHygraphLocale(this.locale),
					hrefTemplate: link.hrefTemplate,
				});
			}
			this.dispatchEvent(
				new CustomEvent<NavAccountLinkClickEvent>(CONSUMER_EVENTS.ACCOUNT_LINK_CLICK, {
					detail: { originalEvent: e, link },
					bubbles: true,
					composed: true,
				})
			);
		}
	}
	_mainCtaClick(e: PointerEvent, link: NavPlatformAwareLinkFragment | null | undefined): void {
		this.closeAll();
		if (link) {
			if (link.hrefTemplate) {
				link.hrefTemplate = convertHrefTemplate({
					domain: this.domain,
					locale: this.getMappedHygraphLocale(this.locale),
					hrefTemplate: link.hrefTemplate,
				});
			}
			this.dispatchEvent(
				new CustomEvent<NavCtaClickEvent>(CONSUMER_EVENTS.CTA_CLICK, {
					detail: { originalEvent: e, link },
					bubbles: true,
					composed: true,
				})
			);
		}
	}
	_mainLocaleMenuClick(evt: PointerEvent): void {
		const current = this.localeMenuOpen;
		this.closeMenusAndInput();
		this.localeMenuOpen = !current;

		if (this.localeMenuOpen) {
			if (this.drawerOpen) {
				this._trapSubFocus(
					evt,
					(trigger: HTMLElement) => trigger.nextElementSibling?.nextElementSibling?.nextElementSibling as HTMLElement,
					Trigger,
					evt.target as HTMLElement,
					() => {},
					(_evt: KeyboardEvent) => {
						this.closeMenusAndInput();
						this._untrapSubFocus();
					}
				);
			} else {
				this._trapFocus(
					evt,
					(trigger: HTMLElement) => trigger.nextElementSibling?.nextElementSibling?.nextElementSibling as HTMLElement,
					Trigger,
					() => {}
				);
			}
		} else {
			this._untrapFocus();
		}
	}
	_mainLocaleMenuMouseOver(_evt: PointerEvent): void {
		this.localeMenuOpen = true;
	}

	_mainLocaleMenuMouseLeave(_evt: PointerEvent): void {
		this.localeMenuOpen = false;
		this._untrapFocus();
	}

	_mainAccountMenuClick(evt: PointerEvent): void {
		const current = this.accountMenuOpen;
		this.closeMenusAndInput();
		this.accountMenuOpen = !current;
		if (this.accountMenuOpen) {
			if (this.drawerOpen) {
				this._trapSubFocus(
					evt,
					(trigger: HTMLElement) => trigger.nextElementSibling?.nextElementSibling?.nextElementSibling as HTMLElement,
					Trigger,
					evt.target as HTMLElement,
					() => {},
					(_evt: KeyboardEvent) => {
						this.closeMenusAndInput();
						this._untrapSubFocus();
					}
				);
			} else {
				this._trapFocus(
					evt,
					(trigger: HTMLElement) => trigger.nextElementSibling?.nextElementSibling?.nextElementSibling as HTMLElement,
					Trigger,
					() => {}
				);
			}
		} else {
			this._untrapFocus();
		}
	}

	_mainAccountMenuMouseOver(_evt: PointerEvent): void {
		this.accountMenuOpen = true;
	}

	_mainAccountMenuMouseLeave(_evt: PointerEvent): void {
		this.accountMenuOpen = false;
		this._untrapFocus();
	}

	onDrawerAnimationEnd(_evt: TransitionEvent): void {
		if (this.drawerOpen) {
			this.header.setAttribute("data-mobile-drawer-has-opened", "true");
			this.header.setAttribute("data-mobile-drawer-has-closed", "false");
		} else {
			this.header.setAttribute("data-mobile-drawer-has-opened", "false");
			this.header.setAttribute("data-mobile-drawer-has-closed", "true");
		}

		this.drawerInTransition = false;
	}

	_backClick(): void {
		this.closeMenusAndInput();
	}

	_trapFocus(
		e: PointerEvent | KeyboardEvent | CustomEvent,
		provideTrapContainer: TrapContainerProvider,
		provideOriginalFocus: OriginalFocusProvider,
		onDeactivate?: () => void,
		onEscapeDeactivates?: (_evt: KeyboardEvent) => void
	): void {
		this._trapFocusIn(
			e,
			this._focusTrap,
			provideTrapContainer,
			provideOriginalFocus,
			this,
			onDeactivate,
			onEscapeDeactivates
		);
	}

	_untrapFocus(): void {
		this._untrapFocusIn(this._focusTrap);
	}

	_trapSubFocus(
		e: PointerEvent | KeyboardEvent | CustomEvent,
		provideTrapContainer: TrapContainerProvider,
		provideOriginalFocus: OriginalFocusProvider,
		fallbackFocus: HTMLElement,
		onDeactivate?: () => void,
		onEscapeDeactivates?: (_evt: KeyboardEvent) => void
	): void {
		this._trapFocusIn(
			e,
			this._subFocusTrap,
			provideTrapContainer,
			provideOriginalFocus,
			fallbackFocus,
			onDeactivate,
			onEscapeDeactivates
		);
	}

	_untrapSubFocus(): void {
		this._untrapFocusIn(this._subFocusTrap);
	}

	get _isSubFocusTrapped(): boolean {
		return this._subFocusTrap.active;
	}

	private _trapFocusIn(
		e: PointerEvent | KeyboardEvent | CustomEvent,
		focusTrap: FocusTrapper,
		provideTrapContainer: TrapContainerProvider,
		provideOriginalFocus: OriginalFocusProvider,
		fallbackFocus: HTMLElement,
		onDeactivate?: () => void,
		onEscapeDeactivates?: (_evt: KeyboardEvent) => void
	): void {
		const linkElem = e.target as HTMLElement;
		if (linkElem) {
			const subnavMenu = provideTrapContainer(linkElem);
			if (subnavMenu) {
				const originalFocus = provideOriginalFocus(linkElem);
				focusTrap.trapFocusIn(subnavMenu, {
					returnFocusTo: originalFocus,
					fallbackFocus: fallbackFocus,
					onDeactivate: onDeactivate ?? this.closeDropdowns.bind(this),
					onEscapeDeactivates: onEscapeDeactivates ?? this._handleEscape.bind(this),
				});
			}
		}
	}

	private _untrapFocusIn(focusTrap: FocusTrapper): void {
		focusTrap.untrapFocus();
	}

	override render(): TemplateResult {
		//if no localeOptions passed then make disableLocale true
		if ((!this.localeOptions || !this.localeOptions.length) && this.disableLocale === false) {
			this.disableLocale = true;
		}

		const isSubDrawerOpen = this.drawerOpen && this.activeMainLinkIndex > -1;

		const validLogo = Boolean(this.propertyLogo?.logo && this.propertyLogo?.logo?.url);
		const validIconLogo = Boolean(this.propertyLogo?.iconOnlyLogo && this.propertyLogo?.iconOnlyLogo?.url);
		const validPropertyLogo = validLogo || validIconLogo;
		const logoUrl = this.propertyLogo?.logo?.url || this.propertyLogo?.iconOnlyLogo?.url || "";

		toggleBodyClass(this.drawerOpen);

		if (validPropertyLogo && this.propertyLogoWidth === 0) {
			console.error("`propertyLogoWidth` not set, but is required to render the logo. Layout shift will occur!");
		}

		const queryParams = this.epicSID ? { trackingId: this.epicSID } : undefined;

		const ctaButton = {
			...this.platformCtaButton,
			defaultHref: convertHrefTemplate({
				hrefTemplate: getPlatformAwareHref(this.platformCtaButton, this.domain, queryParams),
				locale: this.getMappedHygraphLocale(this.locale),
				domain: this.domain,
			}),
		} as NavPlatformAwareLinkFragment;

		//detect known RTL locales and automatically set the correct dir
		if ((this.dir === "" || this.dir === DIR.LTR) && isLangRtl(this.locale)) {
			this.dir = DIR.RTL;
			this.setAttribute("dir", DIR.RTL);
			this._adjustOverflow(true);
		} else if (this.dir === DIR.RTL && !isLangRtl(this.locale)) {
			this.dir = DIR.LTR;
			this.setAttribute("dir", DIR.LTR);
			this._adjustOverflow(true);
		}

		return html`
			${validPropertyLogo ? html`<link rel="preload" fetchpriority="high" as="image" href="${logoUrl}" />` : ""}
			${this.skipNavContentId
				? html`<epic-wf-cta-button
						class="skip-nav"
						href="#${this.skipNavContentId}"
						id="skip-nav"
						label=${this.commonStrings?.skipNavLabel || this.skipNavLabel}
						target="_self"
				  ></epic-wf-cta-button>`
				: null}

			<header
				class="global-header ${this.dir === DIR.RTL ? DIR.RTL : ""}"
				data-dropdown-open=${this.accountMenuOpen || this.localeMenuOpen}
				data-flyout-open=${this.flyoutOpen}
				data-mobile-cta-hidden=${this.disableCtaButtonOnMobile}
				data-mobile-drawer-open=${this.drawerOpen}
				data-mobile-drawer-has-opened="false"
				data-mobile-drawer-has-closed="true"
				data-mobile-subdrawer-open=${isSubDrawerOpen}
				data-search-open=${this.searchOpen}
				id="global-header"
				style=${this.topOffsetPixels > 0 ? `--top-offset: ${this.topOffsetPixels}px` : ""}
			>
				${flyoutTemplate({ disabled: !validPropertyLogo && this.drawerOpen, nav: this, validPropertyLogo })}

				<nav aria-label="${this.brandStrings?.componentLabel || ""}" class="global-header__nav">
					${validPropertyLogo
						? html`
								<epic-wf-property-logo
									@click=${(e: PointerEvent) => {
										this._mainLogoClick(e, this.propertyLogo);
									}}
									.logo=${this.propertyLogo?.logo || ({} as LogoFragment)}
									.iconOnlyLogo=${this.propertyLogo?.iconOnlyLogo || ({} as LogoFragment)}
									logoAlt=${this.propertyLogo?.logoAlt || ""}
									hrefTemplate=${this.propertyLogo?.hrefTemplate || ""}
									locale=${this.getMappedHygraphLocale(this.propertyLogo?.locale || "")}
									width=${this.propertyLogoWidth}
									domain=${this.domain || ""}
								></epic-wf-property-logo>
						  `
						: null}

					<button
						@click=${this.toggleDrawer}
						aria-controls="mobile-drawer"
						aria-expanded=${this.drawerOpen}
						aria-label=${this.drawerButtonLabel}
						class="menu-toggle"
						id="mobile-drawer-toggle"
					>
						${this.drawerOpen ? unsafeSVG(xMark) : unsafeSVG(linesHorizontal)}
					</button>
					<div @transitionend=${this.onDrawerAnimationEnd} class="global-header__drawer" id="mobile-drawer">
						<div class="main-nav">
							<ul class="main-nav__list">
								${mainLinksTemplate(this)}
							</ul>
						</div>

						<div class="toolbar">
							${toolsTemplate(this)}

							<div class="toolbar__back-wrapper">
								<button
									@click=${this._backClick}
									aria-label="${this.commonStrings?.backButtonAccessibleLabel || ""}"
									class="back-button"
								>
									<span aria-hidden="true" class="icon-wrapper">
										${this.dir === DIR.RTL ? unsafeSVG(chevronRightIcon) : unsafeSVG(chevronLeftIcon)}
									</span>
									<span class="label">${this.commonStrings?.backButtonLabel || ""}</span>
								</button>
							</div>
						</div>

						${when(
							!this.disableCtaButton && ctaButton?.label,
							() => html`
								<div class="main-cta">
									<epic-wf-cta-button
										@click=${(e: PointerEvent) => {
											this._mainCtaClick(e, ctaButton);
										}}
										domain=${this.domain}
										href=${ctaButton?.defaultHref || ""}
										label=${ctaButton?.label || ""}
										locale=${this.getMappedHygraphLocale(this.locale)}
									></epic-wf-cta-button>
								</div>
							`
						)}
					</div>
				</nav>
				<lit-media-query .query="${this._isMobile}" @changed="${this._handleIsMobile}"></lit-media-query>
				<lit-media-query .query="${this._condensedLarge}" @changed="${this._handleCondensedQuery}"></lit-media-query>
				<lit-media-query .query="${this._isNotMobile}" @changed="${this._handleIsNotMobile}"></lit-media-query>
			</header>
		`;
	}
}

declare global {
	interface HTMLElementTagNameMap {
		"epic-wf-navigation": Navigation;
	}
}
