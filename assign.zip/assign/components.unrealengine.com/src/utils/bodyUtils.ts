/**
 * Append style tag to the body to prevent scrolling when the drawer is open
 */
export const appendStyleTag = (): void => {
	if (document) {
		const styleEl = document.createElement("style");
		// @TODO: use "100dvh" and remove the @supports query when iOS 15 support is dropped
		styleEl.innerHTML = `
			.wf-nav-open {
				height: 100vh;
				overflow: hidden;
				position: fixed;
				width: 100vw;
			}

			@supports (height: 100dvh) {
				.wf-nav-open {
					height: 100dvh;
				}
			}
		`;
		document.body.appendChild(styleEl);
	}
};

export const toggleBodyClass = (drawerOpen: boolean): void => {
	if (drawerOpen === true) {
		document.body.classList.add("wf-nav-open");
	} else {
		document.body.classList.remove("wf-nav-open");
	}
};
