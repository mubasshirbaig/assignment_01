const RTL_LANG_CODES = ["ar", "ar-ar", "ar-AR"];

export const isLangRtl = (locale: string): boolean => {
	if (!locale || typeof locale !== "string") return false;
	return RTL_LANG_CODES.includes(locale);
};
