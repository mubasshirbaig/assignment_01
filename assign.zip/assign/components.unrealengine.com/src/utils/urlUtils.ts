export const getCurrentUrl = (domain: string): URL | null => {
	try {
		if (window && window.location && window.location.href) {
			return new URL(window.location.href);
		}
		return new URL(domain);
	} catch (e) {
		console.warn("getCurrentUrl() Failed to parse current URL", e);
		return null;
	}
};

export const getUrlQuery = (url: URL, filterParam?: string[]): string[] => {
	if (url?.search) {
		// Remove the first character which is a question mark
		const queryStr = url.search.substring(1);
		return queryStr.split("&").filter((nameValuePair) => {
			const pair = nameValuePair.split("=");

			// pair[0] is the name
			const notFiltered = filterParam ? !filterParam.includes(pair[0]) : true;
			return pair[0] !== "lang" && notFiltered;
		});
	}
	return [];
};

export const buildSearchQuery = (currentUrl: URL | null, extraParams: string[], paramFilters?: string[]): string => {
	const query = [...extraParams];
	if (currentUrl) {
		query.push(...getUrlQuery(currentUrl, paramFilters));
	}
	return query.length > 0 ? `?${query.join("&")}` : "";
};
