import { NavPlatformAwareLinkFragment } from "@wf-components/hygraph-content";
import os from "platform-detect/os.mjs";

export const getPlatformAwareHref = (
	link?: NavPlatformAwareLinkFragment | null,
	domain?: string,
	queryParams?: { [key: string]: string }
): string => {
	if (link?.hrefTemplate) {
		return link.hrefTemplate;
	}

	let href = link?.defaultHref || "";
	if (os.android && link?.androidHref) {
		href = link.androidHref;
	} else if (os.ios && link?.iosHref) {
		href = link.iosHref;
	} else if (os.windows && link?.windowsHref) {
		href = link.windowsHref;
	} else if (os.macos && link?.macHref) {
		href = link.macHref;
	}

	if (queryParams && href) {
		const url = new URL(href, domain || location.origin);
		Object.entries(queryParams).map((value) => url.searchParams.append(...value));
		href = url.toString();
	}
	return href || "";
};
