import * as focusTrap from "focus-trap";

export type CanFocusTrapNotifier = (container: HTMLElement, notify: () => void) => void;

export type TrapContainerProvider = (trigger: HTMLElement) => HTMLElement;

export type OriginalFocusProvider = (trigger: HTMLElement) => HTMLElement | null | undefined;

export function TriggerSibling(trigger: HTMLElement): HTMLElement {
	return trigger.nextElementSibling as HTMLElement;
}

export function ShadowMainLink(trigger: HTMLElement): HTMLElement | null | undefined {
	return trigger.shadowRoot?.querySelector<HTMLElement>(".main-link");
}

export function Trigger(trigger: HTMLElement): HTMLElement | null | undefined {
	return trigger;
}

export type FocusTrapperOptions = {
	returnFocusTo?: HTMLElement | null;
	fallbackFocus: HTMLElement;
	onDeactivate: () => void;
	onEscapeDeactivates: (_evt: KeyboardEvent) => void;
};

export class FocusTrapper {
	static waitForDisplay(container: HTMLElement | SVGElement, notify: () => void): void {
		const display = container.style.getPropertyValue("display");
		if (display !== "none") {
			notify();
		} else {
			const observer = new ResizeObserver((entries: ResizeObserverEntry[], observer) => {
				for (const entry of entries) {
					if (entry.target === container) {
						if (container.style.display !== "none") {
							notify();
							observer.disconnect();
						}
					}
				}
			});
			observer.observe(container);
		}
	}

	private _globalFocusTrap: focusTrap.FocusTrap | undefined;
	private _returnFocusTo: HTMLElement | null | undefined;
	private _onDeactivate?: () => void;
	private _onEscapeDeactivates?: (_evt: KeyboardEvent) => void;

	trapFocusIn(container: HTMLElement, options: FocusTrapperOptions): void {
		if (!container) {
			console.debug("Focus trpping empty container");
			return;
		}

		const { returnFocusTo, fallbackFocus, onDeactivate, onEscapeDeactivates } = options;

		this._returnFocusTo = returnFocusTo;
		this._onDeactivate = onDeactivate;
		this._onEscapeDeactivates = onEscapeDeactivates;
		if (this._globalFocusTrap) {
			FocusTrapper.waitForDisplay(container, () => {
				if (this._globalFocusTrap) {
					this._globalFocusTrap.updateContainerElements(container);
					this._globalFocusTrap.activate();
				}
			});
		} else {
			const options: focusTrap.Options = {
				onDeactivate: () => {
					if (this._onDeactivate) {
						this._onDeactivate();
					}
				},
				clickOutsideDeactivates: true,
				fallbackFocus: () => fallbackFocus,
				tabbableOptions: {
					getShadowRoot: true,
				},
				escapeDeactivates: (evt: KeyboardEvent) => {
					if (this._onEscapeDeactivates) {
						this._onEscapeDeactivates(evt);
					}
					return true;
				},
				isKeyForward: (event) => event.key === "ArrowDown" || event.key === "Tab",
				isKeyBackward: (event) => event.key === "ArrowUp" || (event.shiftKey && event.key === "Tab"),
			};

			options.setReturnFocus = (_) => (this._returnFocusTo ? this._returnFocusTo : false);

			options.checkCanFocusTrap = (_containers: Array<HTMLElement | SVGElement>) => {
				return new Promise<void>((resolve) => {
					FocusTrapper.waitForDisplay(_containers[0], resolve);
				});
			};

			try {
				this._globalFocusTrap = focusTrap.createFocusTrap(container, options);
				this._globalFocusTrap.activate();
			} catch (e) {
				console.debug(e);
			}
		}
	}

	untrapFocus(): void {
		if (this._globalFocusTrap) {
			this._globalFocusTrap.deactivate();
		}
	}

	get active(): boolean {
		return this._globalFocusTrap ? this._globalFocusTrap.active : false;
	}
}
