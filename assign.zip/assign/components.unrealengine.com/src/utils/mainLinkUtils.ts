import { NavMainLinkFragment } from "@wf-components/hygraph-content";
import { convertHrefTemplate } from "@wf-components/navigation-consumer";

export const getMainLinks = (
	mainLinks: NavMainLinkFragment[],
	domain: string,
	locale: string
): NavMainLinkFragment[] => {
	const updatedMainLinks = mainLinks.map((link) => {
		const href = convertHrefTemplate({
			hrefTemplate: link.hrefTemplate,
			domain,
			locale,
		});
		if (link.menu) {
			if (link.menu.__typename === "NavSimpleMenu") {
				link.menu.links = link.menu.links.map((menuLink) => {
					return {
						...menuLink,
						hrefTemplate: convertHrefTemplate({
							hrefTemplate: menuLink.hrefTemplate,
							domain,
							locale,
						}),
					};
				});
			} else if (link.menu.__typename === "NavSubnavMenu") {
				link.menu.links = link.menu.links.map((menuLink) => {
					return {
						...menuLink,
						hrefTemplate: convertHrefTemplate({
							hrefTemplate: menuLink.hrefTemplate,
							domain,
							locale,
						}),
					};
				});
				link.menu.descLinks = link.menu.descLinks.map((menuLink) => {
					return {
						...menuLink,
						hrefTemplate: convertHrefTemplate({
							hrefTemplate: menuLink.hrefTemplate,
							domain,
							locale,
						}),
					};
				});
				link.menu.cardLinks = link.menu.cardLinks.map((menuLink) => {
					return {
						...menuLink,
						hrefTemplate: convertHrefTemplate({
							hrefTemplate: menuLink.hrefTemplate,
							domain,
							locale,
						}),
					};
				});
			}
		}
		return {
			...link,
			hrefTemplate: href,
		};
	});
	return updatedMainLinks;
};
