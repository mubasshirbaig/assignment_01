import detectElementOverflow from "detect-element-overflow";

const simpleMenuIds = ["nav-account-friendly-box", "nav-account-menu", "nav-locale-friendly-box", "nav-locale-menu"];

interface NavState {
	isMobile: boolean;
	drawerOpen: boolean;
	force?: boolean;
}

const OVERFLOW_ATTR = "data-overflow-adjusted";
const ADJUSTMENT = "--overflow-adjustment";

/**
 * Resets the simple menu overflow to original state by clearing the adjustments
 */
export const resetSimpleMenuOverflowAdjustment = (shadowRoot: ShadowRoot | null): void => {
	if (!shadowRoot) return;
	simpleMenuIds.forEach((id) => {
		const menuEl = shadowRoot.querySelector(`#${id}`) as HTMLElement;
		if (menuEl) {
			menuEl.setAttribute(OVERFLOW_ATTR, "false");
			menuEl.style.setProperty(ADJUSTMENT, "none");
		}
	});
};

export const runSimpleMenuOverflowAdjustment = (
	shadowRoot: ShadowRoot | null,
	{ isMobile, drawerOpen, force }: NavState
): void => {
	if (!shadowRoot) return;

	if (force) {
		resetSimpleMenuOverflowAdjustment(shadowRoot);
	}

	//wait for the attr and property change from reset
	setTimeout(() => {
		simpleMenuIds.forEach((id) => {
			const menuEl = shadowRoot.querySelector(`#${id}`) as HTMLElement;
			if (menuEl) {
				if (isMobile || drawerOpen) {
					menuEl.setAttribute(OVERFLOW_ATTR, "false");
					menuEl.style.setProperty(ADJUSTMENT, "none");
				} else {
					adjustViewportOverflow(menuEl);
					menuEl.setAttribute(OVERFLOW_ATTR, "true");
				}
			}
		});
	}, 0);
};

export function adjustViewportOverflow(child: HTMLElement, hgap: number = 16): void {
	const collisions = detectElementOverflow(child, document.body);

	let translatePixels = 0;
	if (collisions.overflowLeft > 0) {
		translatePixels = hgap + collisions.overflowLeft; //positive to move right
	} else if (collisions.overflowRight > 0) {
		translatePixels = (hgap + collisions.overflowRight) * -1; //negative to move left
	}

	const translateRem = `${translatePixels / 16}rem`;

	if (translatePixels) {
		child.style.setProperty(ADJUSTMENT, translateRem);
	}
}
