import {useSharedValue} from '@epic-core/hooks';
import {AppSharedKeys} from 'epic-ue-shared';
import {BannerCmsProps} from '../components/NavBannerBar';

export const useHeaderNavBanner = (): BannerCmsProps => {
    const [headerStore] = useSharedValue(AppSharedKeys.HeaderStore);
    const {navBanner} = headerStore;
    return navBanner || {};
};
