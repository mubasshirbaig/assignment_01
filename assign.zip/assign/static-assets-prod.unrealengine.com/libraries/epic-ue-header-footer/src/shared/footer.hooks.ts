import {useSharedValue} from '@epic-core/hooks';
import {EpicGamesFooterProps} from 'epic-games-footer/src/epic-games-footer.types';
import {AppSharedKeys} from 'epic-ue-shared';

export const useFooterStore = (): EpicGamesFooterProps => {
    const [footerStore] = useSharedValue(AppSharedKeys.FooterStore);
    const {config} = footerStore;
    return config || {};
};
