import {ContextMessage} from '@epic-mw/localization';

export default ContextMessage;
