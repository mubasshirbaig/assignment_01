import React from 'react';
import {default as MuiTextField, TextFieldProps} from '@material-ui/core/TextField';

export const TextField = React.forwardRef((props: TextFieldProps, ref: any) => (
    <MuiTextField ref={ref} {...props} />
));

TextField.displayName = 'TextField';
