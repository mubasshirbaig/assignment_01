import React from 'react';
import {default as MuiTextField, TextFieldProps} from '@material-ui/core/TextField';

export const TextFieldSelect = React.forwardRef((props: TextFieldProps, ref: any) => (
    <MuiTextField select ref={ref} {...props} />
));

TextFieldSelect.displayName = 'TextFieldSelect';
