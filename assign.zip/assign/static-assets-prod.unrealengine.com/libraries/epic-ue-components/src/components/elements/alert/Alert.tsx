import React from 'react';
import {default as MuiAlert, AlertProps} from '@material-ui/lab/Alert';

export const Alert = React.forwardRef((props: AlertProps, ref) => (
    <MuiAlert ref={ref} {...props} variant={props.variant || 'outlined'} />
));

Alert.displayName = 'Alert';
